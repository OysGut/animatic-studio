<!-- GENERERT FIL – ikke rediger. Kilde: docs/product/requirements.yaml. Kjør: python3 scripts/kb/build_docs.py -->
# Kravregister – Animatic Studio
Autoritativ kilde for krav-ID-er. Mandatkrav er utledet fra `MASTER_SPECIFICATION.md` (v14). Krav utenfor mandatet viser til en beslutning i `docs/decisions/DECISION_LOG.md`.

**ID-er er permanente. Aldri gjenbruk eller omnummerer. Nye krav får neste ledige nummer. Utgåtte krav beholdes med status Utgått.**

## Nøkkeltall
- Antall krav: **714**
- Prioritet: P0: 145, P1: 381, P2: 149, P3: 39
- Opprinnelse: mandat: 520, brukerbeslutning: 187, teknisk-anbefaling: 7
- Status: Verifisert: 631, Implementert – ikke verifisert: 21, Under arbeid: 3, Ikke startet: 59

## Prioritetsdefinisjoner
- **P0** Kritisk – ufravikelig prinsipp/systeminvariant. Gjelder fra første kodelinje som berører området, også når selve funksjonen bygges i en senere fase (feltet `phase`).
- **P1** Høy – nødvendig i fase 1–4, eller tverrgående prosesskrav (fase tom).
- **P2** Middels – fase 5–7.
- **P3** Senere – fase 8 eller betinget formulert («dersom», «kan hente inspirasjon»).

## Opprinnelse
- **mandat** – står i MASTER_SPECIFICATION v14.
- **brukerbeslutning** – vedtatt av Mars senere (se beslutningsloggen).
- **teknisk-anbefaling** – Claudes anbefaling for å oppfylle et vedtatt krav. Kan endres uten produktbeslutning, men endringen logges.

## Krav per kapittel

### Kapittel 1

#### REQ-0001 – Fullverdig filmproduksjonsmiljø fra manus til film
Animatic Studio skal være en profesjonell applikasjon for utvikling, planlegging, visualisering, produksjon, versjonering og sammenstilling av film, og skal gjøre det mulig å utvikle en film fra første manusutkast til ferdig sammenstilt materiale.

- **Kilde:** Kap. 1 (l. 7, 24) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P1 · **Fase:** –
- **Moduler:** CORE
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et nytt prosjekt, når brukeren importerer et manus, bygger scener, legger lyd og montering, så kan en ferdig sammenstilt film eksporteres fra samme prosjekt uten å forlate applikasjonen.
- **Tester:**
  - e2e: manus-til-eksport-arbeidsflyt i ett prosjekt
- **Implementering:** src/engine/import/browser.ts, src/core/screenplay/parse.ts, src/core/composition/render.ts, src/core/audio/index.ts, src/core/assembly/film.ts, src/engine/export/animatic.ts, src/app/assembly/ExportAnimaticDialog.tsx
- **Merknad:** Overordnet formål; konkretiseres i senere kapitler.

#### REQ-0002 – Produktets funksjonsomfang
Programmet skal kombinere: profesjonell manusbehandling; automatisk scenedeteksjon og produksjonsanalyse; globale biblioteker for karakterer, objekter og lokasjoner; en redigerbar, lagbasert 2D-sceneeditor; kameraanimasjon basert på tradisjonell multiplan-teknikk; tidslinje for bilde, lyd, dialog og bevegelser; automatisk generering av presise instruksjoner til ulike AI-modeller; integrasjon med eksterne bilde-, lyd- og videogenereringstjenester; en selvstendig animatic-motor som ikke er avhengig av AI; profesjonell versjons- og kontinuitetskontroll; renderingskø og bakgrunnsproduksjon; flerspråklig manus, dialog og filmeksport; avledede produksjoner, kortfilmer og spinoffer; presentasjonsmateriell, pitchplakater og karakterkart; ferdig sammenstilling og eksport av filmer.

- **Kilde:** Kap. 1 (l. 8-23) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** CORE, SCRIPT, LIBRARY, COMPOSE, CAMERA, TIMELINE, AUDIO, PROMPT, PROVIDER, VERSION, CONTINUITY, QUEUE, L10N, PRESENT, EXPORT
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Hvert av de 15 punktene kan spores til minst ett detaljkrav og en fase i utviklingsplanen.
- **Tester:**
  - manuell: sporbarhetsmatrise punkt → krav → fase
- **Implementering:** src/core/, src/app/, docs/development/IMPLEMENTATION_STATUS.md
- **Merknad:** Paraplykrav/omfangsliste; hvert punkt detaljeres i senere kapitler. Fasene fordeler punktene over fase 1–8.

#### REQ-0003 – Import av eksisterende filmmateriale
Eksisterende filmmateriale skal kunne importeres og inngå i produksjonen.

- **Kilde:** Kap. 1 (l. 24) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** TIMELINE, LIBRARY
- **Avhengigheter:** REQ-0098; REQ-0100
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en videofil med ferdig film, når den importeres, så kan den plasseres på filmtidslinjen og knyttes til en scene/manuspassasje.
- **Tester:**
  - import/eksport: import av videofil og plassering i montering
- **Implementering:** src/app/assembly/film-import.ts, src/app/assembly/LongFilmImportDialog.tsx, src/core/assembly/edit.ts
- **Merknad:** Jf. kap. 34 pkt. 15 (ferdig film skal kunne importeres og knyttes til manuspassasjer).

#### REQ-0004 – Fungerer fullt uten generativ AI
Programmet skal ikke bare være et grensesnitt mot AI-tjenester, men et fullverdig produksjonsmiljø som fungerer selv når brukeren ikke ønsker å bruke generativ AI.

- **Kilde:** Kap. 1 (l. 25) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** CORE, COMPOSE, TIMELINE, EXPORT · **Invarianter:** INV-11
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt at ingen AI-leverandør er konfigurert, så kan brukeren importere manus, bygge 2D-scener, spille av animatic og eksportere film og manus.
- **Tester:**
  - e2e: full arbeidsflyt med alle AI-adaptere deaktivert
- **Implementering:** src/engine/import/browser.ts, src/core/composition/render.ts, src/engine/compositor/canvas.ts, src/engine/export/animatic.ts, src/engine/export/screenplay-pdf.ts, src/engine/export/screenplay-docx.ts

#### REQ-0005 – Offisielt produktnavn er Animatic Studio
Produktets eneste offisielle navn er «Animatic Studio». «AI Animatic Studio» skal ikke brukes som produktnavn. Betegnelser som AI-generering, AI-modeller, AI-integrasjoner og AI-kvalitetskontroll kan brukes når funksjonaliteten beskrives, men skal ikke være del av selve produktnavnet.

- **Kilde:** Kap. 1.1 (l. 27-30) · **Opprinnelse:** mandat · **Type:** design · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Ingen brukerflate, vindustittel, metadata, eksport eller dokumentasjon bruker «AI Animatic Studio» som navn.
- **Tester:**
  - enhet: søk i kildekode/ressursfiler etter strengen «AI Animatic Studio» gir null treff
- **Implementering:** src/app/shell/AppHeader.tsx, src/app/auth/AuthScreen.tsx
- **Merknad:** Jf. kap. 34 pkt. 1.

#### REQ-0006 – Første versjon utvikles i Lovable
Den første versjonen skal utvikles med utgangspunkt i Lovable.

- **Kilde:** Kap. 1.2 (l. 32) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** PROCESS, CORE
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Første versjon kjører som Lovable-prosjekt (web), eventuelt med tilknyttede backend-tjenester.
- **Tester:**
  - manuell: verifiser at MVP er bygd og publisert via Lovable
- **Implementering:** package.json

#### REQ-0007 – Portabilitet til macOS og Windows
Løsningen skal arkitekteres slik at kjernefunksjonalitet, datamodell, genereringsmotor, mediebehandling og produksjonslogikk kan flyttes til eller gjenbrukes i senere desktop-versjoner for macOS og Windows.

- **Kilde:** Kap. 1.2 (l. 33-34) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** CORE, PROMPT, COMPOSE, TIMELINE
- **Avhengigheter:** REQ-0009
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Domene-, datamodell-, generering- og produksjonslogikk ligger i moduler uten avhengighet til nettleser-API-er eller Lovable-spesifikke biblioteker.
- **Tester:**
  - enhet: kjernemoduler kan kjøres/testes i et ikke-nettleser-miljø (f.eks. Node) uten DOM
- **Implementering:** src/core/, src/core/generation/, src/core/assembly/
- **Merknad:** Linje 33 og 34 er duplikater. Jf. kap. 34 pkt. 28.

#### REQ-0008 – Unngå unødvendige plattformbindinger
Løsningen skal unngå unødvendige plattformbindinger.

- **Kilde:** Kap. 1.2 (l. 35) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** CORE
- **Avhengigheter:** REQ-0007
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Hver plattformspesifikk avhengighet er isolert bak et grensesnitt og dokumentert med begrunnelse.
- **Tester:**
  - manuell: arkitekturgjennomgang av avhengighetsliste
- **Implementering:** docs/architecture/ARCHITECTURE.md, src/adapters/, src/adapters/browser/

#### REQ-0009 – Tydelig lagdeling av arkitekturen
Arkitekturen skal skille tydelig mellom: 1) domene- og datamodell, 2) brukergrensesnitt, 3) medie- og animasjonsmotor, 4) AI-integrasjoner, 5) renderingskø og jobborkestrering, 6) lagring og versjonering, 7) eksport og filbehandling.

- **Kilde:** Kap. 1.2 (l. 36-43) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** CORE, UI, COMPOSE, PROVIDER, QUEUE, VERSION, SECURITY, EXPORT
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Kodebasen har adskilte moduler for hvert av de sju lagene, og UI-laget aksesserer domenet kun via definerte grensesnitt.
- **Tester:**
  - enhet: avhengighetsregler (f.eks. lint/import-regler) hindrer at domenemodellen importerer UI- eller leverandørkode
- **Implementering:** src/core/, src/adapters/, src/app/
- **Merknad:** Jf. modulinndelingen i kap. 31.

#### REQ-0010 – Backend-tjenester for tunge medieoperasjoner
Det skal ikke antas at Lovable alene kan utføre alle tunge medieoperasjoner eller langvarige bakgrunnsjobber; nødvendige backend-tjenester eller separate komponenter skal foreslås der dette er teknisk riktig.

- **Kilde:** Kap. 1.2 (l. 44) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** QUEUE, CORE, PROCESS
- **Avhengigheter:** REQ-0009
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Arkitekturdokumentet angir for hver tung operasjon (rendering, transkoding, lange genereringsjobber) om den kjøres i nettleser, backend eller egen tjeneste, med begrunnelse.
- **Tester:**
  - manuell: arkitekturgjennomgang
- **Implementering:** docs/architecture/ARCHITECTURE.md

#### REQ-0011 – Overordnede designkvaliteter
Animatic Studio skal være profesjonelt, elegant, filmisk, oversiktlig, effektivt, ikke-destruktivt, modulært, pålitelig og brukerstyrt.

- **Kilde:** Kap. 1.3 (l. 46-55) · **Opprinnelse:** mandat · **Type:** design · **Prioritet:** P1 · **Fase:** –
- **Moduler:** UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Designprinsippene er dokumentert i designsystemet og brukes som kriterier i UX-gjennomganger.
- **Tester:**
  - manuell: heuristisk UX-evaluering mot de ni kvalitetene
- **Implementering:** docs/design/DESIGN_SYSTEM.md, docs/design/UX_PRINCIPLES.md
- **Merknad:** «Ikke-destruktivt» konkretiseres i kap. 2.2.

#### REQ-0012 – Sofistikert, gjerne mørk visuell utforming
Grensesnittet skal ha en sofistikert, moderne og gjerne mørk visuell utforming som passer en profesjonell filmproduksjon.

- **Kilde:** Kap. 1.3 (l. 56) · **Opprinnelse:** mandat · **Type:** design · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Standardtemaet er et mørkt tema egnet for filmproduksjon, definert som design-tokens.
- **Tester:**
  - visuell: skjermbildegjennomgang av hovedvisninger i standardtema
- **Implementering:** src/styles.css
- **Merknad:** Ingen automatisk test kontrollerer at standardtemaet er mørkt og definert som tokens.

#### REQ-0013 – Troverdig kreativt verktøy, ikke chatbot
Grensesnittet skal oppleves som et troverdig kreativt arbeidsverktøy, ikke som en generell chatbot eller en samling tilfeldige AI-funksjoner.

- **Kilde:** Kap. 1.3 (l. 57) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P1 · **Fase:** –
- **Moduler:** UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Hovedarbeidsflatene er manus, tidslinje, sceneeditor og bibliotek; AI-funksjoner er integrert i disse og ikke presentert som et chatgrensesnitt.
- **Tester:**
  - manuell: brukertest med filmarbeidere
- **Implementering:** src/app/shell/ProjectNav.tsx, src/app/library/GenerateImagePanel.tsx, src/app/assembly/GenerateSceneDialog.tsx
- **Merknad:** Kravet er en helhetsvurdering uten automatisk test.

#### REQ-0014 – Brukergrensesnitt på norsk
Brukergrensesnittet skal støtte norsk.

- **Kilde:** Kap. 1.3 (l. 58) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** UI, L10N
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Alle brukervendte tekster i grensesnittet finnes på norsk.
- **Tester:**
  - enhet: alle UI-strengnøkler har norsk oversettelse
- **Implementering:** src/components/ui/dialog.tsx, src/components/ui/sheet.tsx
- **Merknad:** Ingen automatisk test som leter etter engelsk tekst i grensesnittet.

#### REQ-0015 – Systeminstruksjoner og prompter på engelsk
Tekniske systeminstruksjoner og genereringsprompter til AI-modeller skal som hovedregel skrives på engelsk for presisjon og kompatibilitet.

- **Kilde:** Kap. 1.3 (l. 59) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 5
- **Moduler:** PROMPT
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et norsk manus, når en genereringsprompt bygges, så er prompten på engelsk med mindre brukeren eksplisitt har valgt annet.
- **Tester:**
  - enhet: promptbygger produserer engelskspråklig tekst for norsk kildemateriale
- **Implementering:** src/adapters/ai/generate-image.functions.ts, src/core/generation/scene-prompt.ts#buildScenePrompt, src/core/generation/prompt-writer.ts, src/core/generation/image-prompt.ts
- **Merknad:** «Som hovedregel» – unntak tillatt. Jf. kap. 34 pkt. 12.

### Kapittel 2

#### REQ-0016 – Én felles strukturert prosjektmodell
Prinsippet om at manus og film er to visninger av den samme produksjonen har høyeste prioritet og skal styre alle senere tekniske valg. Manus, animatic, film, 2D-animasjon, lyd og aktiv filmtidslinje skal være koblet til én felles, strukturert prosjektmodell, og skal ikke utvikles som uavhengige dokumenter som forsøker å holde seg synkronisert i ettertid.

- **Kilde:** Kap. 2 (l. 62-66) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** CORE, SCRIPT, TIMELINE, COMPOSE, AUDIO · **Invarianter:** INV-01
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Manusvisning og filmtidslinje leser scenerekkefølge og aktivstatus fra samme datastruktur (sceneforekomster), ikke fra separate kopier.
  - Hver ADR og teknisk DEC dokumenterer at valget er forenlig med INV-01.
- **Tester:**
  - enhet: datamodellen har én kilde for scenerekkefølge per produksjon
  - integrasjon: endring via manus-API er umiddelbart synlig via tidslinje-API uten synkroniseringsjobb
- **Implementering:** src/core/model.ts, src/core/views.ts
- **Merknad:** Høyeste prioritet i mandatet. Linje 64 og 65 er duplikater. Jf. kap. 34 pkt. 2.

#### REQ-0017 – Flytting i manus flytter i film
Når en scene flyttes i manuset, skal den også flyttes i filmens aktive rekkefølge.

- **Kilde:** Kap. 2 (l. 67) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 2
- **Moduler:** SCRIPT, TIMELINE, CORE · **Invarianter:** INV-01, INV-03
- **Avhengigheter:** REQ-0016
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt scenene A, B, C, når B flyttes etter C i manuset, så er filmens aktive rekkefølge A, C, B.
- **Tester:**
  - integrasjon: flytt i manus → verifiser tidslinjerekkefølge
- **Implementering:** src/core/commands/apply.ts#MoveOccurrence, src/core/views.ts, src/app/script/SceneNavigator.tsx

#### REQ-0018 – Flytting i tidslinje flytter i manus
Når en scene flyttes i filmens overordnede tidslinje, skal manuset vise tilsvarende rekkefølge.

- **Kilde:** Kap. 2 (l. 68) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 4
- **Moduler:** TIMELINE, SCRIPT, CORE · **Invarianter:** INV-01, INV-03
- **Avhengigheter:** REQ-0016
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt scenene A, B, C, når C flyttes først i tidslinjen, så viser manuset C, A, B.
- **Tester:**
  - integrasjon: flytt i tidslinje → verifiser manusrekkefølge
- **Implementering:** src/app/assembly/AssemblyWorkspace.tsx, src/core/assembly/film.ts

#### REQ-0019 – Deaktivering utelater overalt
Når en scene eller delsekvens deaktiveres, skal den utelates fra både aktiv manusvisning, filmavspilling, spilletidsberegning og eksport.

- **Kilde:** Kap. 2 (l. 69) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 2
- **Moduler:** CORE, SCRIPT, TIMELINE, EXPORT · **Invarianter:** INV-01, INV-14
- **Avhengigheter:** REQ-0016
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en deaktivert scene, så vises den ikke i aktiv manusvisning, spilles ikke av, inngår ikke i total spilletid og inngår ikke i eksport (med mindre eksportvalg eksplisitt inkluderer den, jf. REQ-0085).
- **Tester:**
  - integrasjon: deaktiver scene og verifiser alle fire konsumenter
- **Implementering:** src/core/views.ts, src/core/screenplay/numbering.ts, src/app/script/SceneNavigator.tsx

#### REQ-0020 – Skjult materiale slettes ikke
Skjult materiale skal ikke slettes, men kunne gjenaktiveres senere.

- **Kilde:** Kap. 2 (l. 70) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P0 · **Fase:** 2
- **Moduler:** CORE · **Invarianter:** INV-14
- **Avhengigheter:** REQ-0019
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en deaktivert scene med tilknyttet materiale, når den gjenaktiveres, så er alt innhold og materiale uendret tilbake.
- **Tester:**
  - dataintegritet: deaktiver/gjenaktiver rundtur bevarer alle relasjoner
- **Implementering:** src/core/commands/apply.ts#SetOccurrenceActive

#### REQ-0021 – Skille UI-skjuling og produksjonsdeaktivering
Programmet skal skille mellom midlertidig skjuling av et grensesnittelement og produksjonsmessig deaktivering av en scene. Bare produksjonsmessig deaktivering skal endre filmens aktive innhold.

- **Kilde:** Kap. 2 (l. 71-74) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P0 · **Fase:** 2
- **Moduler:** CORE, UI · **Invarianter:** INV-14
- **Avhengigheter:** REQ-0019
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt at brukeren skjuler/kollapser en scene i visningen, så endres ikke filmens aktive innhold eller spilletid.
  - Gitt at brukeren deaktiverer scenen produksjonsmessig, så endres aktivt innhold.
- **Tester:**
  - enhet: visningstilstand og produksjonstilstand er separate felt
- **Implementering:** src/core/screenplay/filter.ts#filterPages, src/core/commands/apply.ts#SetOccurrenceActive, src/app/script/SceneNavigator.tsx

#### REQ-0022 – Skille strukturell og innholdsmessig synkronisering
Systemet skal skille mellom strukturell synkronisering (scener, delsekvenser, rekkefølge, synlighet og aktiv filmmontering stemmer alltid overens) og innholdsmessig synkronisering (eksisterende animatic eller film er produsert fra en bestemt versjon av manus og ressurser).

- **Kilde:** Kap. 2.1 (l. 76-78) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** CORE, VERSION · **Invarianter:** INV-01, INV-07
- **Status:** Implementert – ikke verifisert
- **Akseptansekriterier:**
  - Hvert produsert materiale lagrer referanse til manusversjon og ressursversjoner det er produsert fra, adskilt fra strukturell plassering.
- **Tester:**
  - enhet: datamodell har separate felt for struktur og kildeversjon
- **Implementering:** src/core/views.ts#outdatedTakes, src/core/library/content-sync.ts, src/core/commands/apply.ts (AddTake, AcceptScriptChanges, SetProducedFrom)

#### REQ-0023 – Strukturell synkronisering er automatisk
Strukturell synkronisering skal opprettholdes automatisk.

- **Kilde:** Kap. 2.1 (l. 79) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** CORE · **Invarianter:** INV-01
- **Avhengigheter:** REQ-0016
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Ingen brukerhandling er nødvendig for at manus og film skal ha samme struktur etter en strukturendring.
- **Tester:**
  - integrasjon: tilfeldige strukturoperasjoner (property-based) → manus- og filmstruktur er alltid like
- **Implementering:** src/core/views.ts, src/core/commands/apply.ts

#### REQ-0024 – Produsert materiale endres ikke ved manusendring
Hvis manusinnhold endres etter at film er produsert, skal eksisterende materiale ikke endres automatisk.

- **Kilde:** Kap. 2.1 (l. 80) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** VERSION, CORE · **Invarianter:** INV-07
- **Avhengigheter:** REQ-0022
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en scene med produsert film, når dialogen endres, så er filmklippet og dets metadata byte-identisk uendret.
- **Tester:**
  - dataintegritet: hash av produsert materiale før/etter manusendring
- **Implementering:** src/core/commands/apply.ts, db/migrations/0001_core.sql#protect_takes

#### REQ-0025 – Flagging av innhold ute av synk
Når manusinnhold endres etter at film er produsert, skal eksisterende materiale flagges som potensielt ute av synkronisering.

- **Kilde:** Kap. 2.1 (l. 80) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 2
- **Moduler:** VERSION, CORE · **Invarianter:** INV-07
- **Avhengigheter:** REQ-0022
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en scene med produsert materiale, når manusinnholdet endres, så får materialet status «potensielt ute av synk» synlig i oversikt og tidslinje.
- **Tester:**
  - integrasjon: manusendring → avviksflagg opprettes
- **Implementering:** src/core/assembly/discrepancy.ts#discrepancies, src/core/views.ts#outdatedTakes, src/core/assembly/status.ts#productionStatus, src/app/projects/DurationOverview.tsx
- **Merknad:** Jf. kap. 34 pkt. 7. Fullstendig avviksdeteksjon er fase 6, men grunnflagget bør finnes tidlig.

#### REQ-0026 – Brukeren bestemmer ved avvik
Ved innholdsavvik skal brukeren bestemme hva som skal skje med eksisterende materiale.

- **Kilde:** Kap. 2.1 (l. 81) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P0 · **Fase:** 6
- **Moduler:** VERSION, UI · **Invarianter:** INV-08
- **Avhengigheter:** REQ-0025
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et flagget avvik, så kan brukeren velge å godkjenne avviket, oppdatere materialet eller angre endringen.
- **Tester:**
  - e2e: håndter avvik med hvert av de tre valgene
- **Implementering:** src/core/assembly/discrepancy.ts, src/core/commands/apply.ts (AcceptScriptChanges, SetProducedFrom), db/migrations/0014_ai_control.sql (compositions.produced_from, takes.accepted_from), src/app/assembly/ScriptChanges.tsx, src/app/assembly/FilmTimeline.tsx (merker), src/app/script/ScriptPageView.tsx (merker), src/app/scene-editor/SceneEditorWorkspace.tsx (varsel)
- **Merknad:** Valgene er hentet fra kap. 34 pkt. 8.

#### REQ-0027 – Ingen automatisk sletting av film
En manusendring, ressursendring, omnummerering eller endring av stil skal aldri automatisk slette eksisterende film.

- **Kilde:** Kap. 2.2 (l. 83-84) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** VERSION, CORE · **Invarianter:** INV-07, INV-13
- **Status:** Verifisert
- **Akseptansekriterier:**
  - For hver av de fire endringstypene: eksisterende filmklipp finnes fortsatt etter endringen.
- **Tester:**
  - dataintegritet: parametrisert test over endringstypene
- **Implementering:** src/core/commands/apply.ts, db/migrations/0001_core.sql#protect_takes

#### REQ-0028 – Ingen automatisk overskriving av godkjente ressurser
En manusendring, ressursendring, omnummerering eller endring av stil skal aldri automatisk overskrive godkjente ressurser.

- **Kilde:** Kap. 2.2 (l. 83, 85) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** VERSION, LIBRARY · **Invarianter:** INV-13
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Godkjente ressursversjoner er uforanderlige; endring skaper alltid en ny versjon.
- **Tester:**
  - dataintegritet: forsøk på å skrive til godkjent ressursversjon avvises
- **Implementering:** src/core/commands/apply.ts, src/core/library/reupload.ts, db/migrations/0004_library_notes.sql

#### REQ-0029 – Ingen automatisk betalt AI-generering
En manusendring, ressursendring, omnummerering eller endring av stil skal aldri automatisk bestille en betalt AI-generering.

- **Kilde:** Kap. 2.2 (l. 83, 86) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** QUEUE, QUALITYCOST, PROVIDER · **Invarianter:** INV-12
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Ingen genereringsjobb mot betalt leverandør opprettes uten en eksplisitt brukerinitiert bestilling/godkjenning.
- **Tester:**
  - integrasjon: endringshendelser utløser ingen kall mot leverandøradaptere (mock)
- **Implementering:** src/adapters/ai/generate-image.functions.ts, src/adapters/ai/sound.functions.ts, src/adapters/ai/video.functions.ts, src/adapters/ai/write-prompt.functions.ts, src/adapters/ai/ai-gate.server.ts

#### REQ-0030 – Ingen automatisk bytte av aktiv sceneversjon
En manusendring, ressursendring, omnummerering eller endring av stil skal aldri automatisk erstatte aktiv sceneversjon.

- **Kilde:** Kap. 2.2 (l. 83, 87) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** VERSION, TIMELINE · **Invarianter:** INV-07
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Aktiv sceneversjon-ID er uendret etter hver av de fire endringstypene.
- **Tester:**
  - enhet: aktiv versjon endres kun via eksplisitt brukerkommando
- **Implementering:** src/core/commands/apply.ts, src/core/screenplay/numbering.ts
- **Merknad:** Mangler test for at ressursendring og stilendring ikke endrer aktiv sceneversjon.

#### REQ-0031 – Ingen automatisk endring av annen produksjon
En manusendring, ressursendring, omnummerering eller endring av stil skal aldri automatisk endre en annen produksjon.

- **Kilde:** Kap. 2.2 (l. 83, 88) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** CORE · **Invarianter:** INV-04
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt hovedfilm og spinoff som deler en scene, når scenen endres i spinoffen, så er hovedfilmens sceneforekomst/variant uendret.
- **Tester:**
  - dataintegritet: endring i produksjon X gir ingen diff i produksjon Y
- **Implementering:** src/core/commands/apply.ts#assertCanEditVariant, src/core/invariants.ts

#### REQ-0032 – Historiske manusversjoner bevares
En manusendring, ressursendring, omnummerering eller endring av stil skal aldri automatisk ødelegge en historisk manusversjon.

- **Kilde:** Kap. 2.2 (l. 83, 89) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** VERSION, SCRIPT
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Historiske manusversjoner er uforanderlige snapshots som kan åpnes og eksporteres identisk etter senere endringer.
- **Tester:**
  - dataintegritet: hash av historisk versjon er uendret etter senere redigering
- **Implementering:** db/migrations/0003_script_versions.sql, src/core/screenplay/versions.ts

#### REQ-0033 – Vesentlige oppdateringer sporbare og reverserbare
All vesentlig oppdatering skal være sporbar, reverserbar og brukerinitiert.

- **Kilde:** Kap. 2.2 (l. 90) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** VERSION, CORE · **Invarianter:** INV-08
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Hver vesentlig oppdatering logges med hvem/når/hva, kan reverseres, og er initiert av en brukerhandling.
- **Tester:**
  - integrasjon: endringslogg og reversering for hver oppdateringstype
- **Implementering:** db/migrations/0001_core.sql#change_log, src/core/commands/apply.ts, db/migrations/0001_core.sql, src/adapters/storage/commands.functions.ts
- **Merknad:** Jf. kap. 34 pkt. 27. «Vesentlig» er ikke definert – se OPEN_QUESTIONS B («Vesentlig oppdatering» = alle kommandoer i change_log, ADR-0005).

### Kapittel 3

#### REQ-0034 – Permanent intern scene-ID
Hver scene skal ha en permanent intern identifikator som ikke endres når scenen flyttes, omdøpes, får endret sceneoverskrift, får nytt scenenummer, skjules, gjenbrukes i en spinoff, inngår i en ny manusversjon eller får nytt produsert materiale.

- **Kilde:** Kap. 3.1 (l. 94-102) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** CORE · **Invarianter:** INV-02, INV-03
- **Status:** Verifisert
- **Akseptansekriterier:**
  - For hver av de åtte operasjonene er scenens interne ID uendret etter operasjonen.
- **Tester:**
  - enhet: parametrisert test over de åtte operasjonene
- **Implementering:** src/core/ids.ts, src/core/model.ts
- **Merknad:** Jf. kap. 34 pkt. 3.

#### REQ-0035 – Scenenumre og versjon som egne attributter
Systemet skal for en scene kunne holde intern scene-ID (f.eks. scn_7f42a9), opprinnelig scenenummer (f.eks. 42), gjeldende eksportnummer (f.eks. 45) og aktiv produksjonsversjon (f.eks. render_183) som separate attributter.

- **Kilde:** Kap. 3.1 (l. 103-108) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** CORE, VERSION · **Invarianter:** INV-02
- **Avhengigheter:** REQ-0034
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En scene kan ha opprinnelig nummer 42 og eksportnummer 45 samtidig, uten at ID endres.
- **Tester:**
  - enhet: datamodell-skjema inneholder de fire feltene adskilt
- **Implementering:** src/core/model.ts#SceneOccurrence, src/core/screenplay/numbering.ts#exportNumbering
- **Merknad:** Utledet fra eksempelet. Linje 107 og 108 er duplikater.

#### REQ-0036 – Relasjoner bruker scene-ID, aldri scenenummer
Den interne sceneidentiteten skal brukes i alle relasjoner, aldri scenenummeret som vises i manuset.

- **Kilde:** Kap. 3.1 (l. 109) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** CORE · **Invarianter:** INV-02
- **Avhengigheter:** REQ-0034
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Ingen fremmednøkkel/relasjon i datamodellen refererer til scenenummer.
- **Tester:**
  - enhet: skjemaanalyse – alle scenereferanser peker på scene-ID
  - integrasjon: omnummerering bryter ingen relasjoner
- **Implementering:** src/core/model.ts, db/migrations/0001_core.sql

#### REQ-0037 – Stabile identifikatorer for alle domeneobjekter
Separate, stabile identifikatorer skal finnes for: prosjekt, produksjon, manusversjon, manusscene, manusblokk, replikk, produksjonsdelsekvens, sceneforekomst i en bestemt produksjon, karakter, karakterens utseendetilstand, visuell stilvariant, objekt eller rekvisitt, lokasjon eller miljø, lydressurs, medieressurs, genereringsjobb, genereringsprompt, sceneversjon, filmmontering, plakat og eksportversjon.

- **Kilde:** Kap. 3.2 (l. 111-132) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** CORE · **Invarianter:** INV-02
- **Status:** Under arbeid
- **Akseptansekriterier:**
  - Hver av de 21 entitetstypene har et uforanderlig ID-felt.
- **Tester:**
  - enhet: skjemavalidering av ID-felt for alle 21 typer
- **Implementering:** src/core/ids.ts, db/migrations/0028_duration_exports.sql, src/core/export-records.ts, docs/architecture/DOMAIN_MODEL.md

#### REQ-0038 – ID-er uavhengige av navn, språk og plassering
Identifikatorene skal være uavhengige av navn, språk, plassering og synlige løpenumre.

- **Kilde:** Kap. 3.2 (l. 133) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** CORE · **Invarianter:** INV-02
- **Avhengigheter:** REQ-0037
- **Status:** Verifisert
- **Akseptansekriterier:**
  - ID-er genereres som opake verdier (f.eks. UUID/prefiks+tilfeldig) og endres ikke ved omdøping, oversettelse, flytting eller omnummerering.
- **Tester:**
  - enhet: ID-generator inneholder ingen avledning fra navn/posisjon
- **Implementering:** src/core/ids.ts

#### REQ-0039 – Skille scene, sceneforekomst og scenevariant
Datamodellen skal skille mellom scene (permanent identifisert narrativ enhet), sceneforekomst (hvordan en scene brukes i en bestemt produksjon, inkludert plassering, synlighet, tidsutdrag og aktiv versjon) og scenevariant (redigert eller alternativ utgave av scenen som kan være unik for én produksjon).

- **Kilde:** Kap. 3.3 (l. 135-140) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** CORE · **Invarianter:** INV-04
- **Avhengigheter:** REQ-0037
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Plassering, synlighet, tidsutdrag og aktiv versjon lagres på sceneforekomsten, ikke på scenen.
- **Tester:**
  - enhet: skjema har tre separate entiteter med riktige felt
- **Implementering:** src/core/model.ts, db/migrations/0001_core.sql
- **Merknad:** Linje 137/138 og 139/140 er duplikater.

#### REQ-0040 – Gjenbruk av scene uten delte redaksjonelle endringer
Samme scene skal kunne brukes i flere produksjoner uten at de automatisk deler alle redaksjonelle endringer.

- **Kilde:** Kap. 3.3 (l. 141) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** CORE · **Invarianter:** INV-04
- **Avhengigheter:** REQ-0039
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt scene S i produksjon P1 og P2, når S redigeres som variant i P2, så er S i P1 uendret.
- **Tester:**
  - dataintegritet: variantredigering isolert per produksjon
- **Implementering:** src/core/commands/apply.ts#ForkVariant

#### REQ-0041 – Transaksjonelle strukturoperasjoner
Operasjoner som påvirker flere deler av prosjektmodellen skal gjennomføres som konsistente endringer, særlig flytting av scener, aktivering og deaktivering, splitting og sammenslåing, endring av manusstruktur, overføring mellom produksjoner og endring av aktiv filmversjon.

- **Kilde:** Kap. 3.4 (l. 143-150) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** CORE · **Invarianter:** INV-01
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en feil midt i en av de seks operasjonene, så rulles hele operasjonen tilbake og modellen er i forrige konsistente tilstand.
- **Tester:**
  - integrasjon: feilinjeksjon under hver operasjonstype → ingen delvis tilstand
- **Implementering:** db/migrations/0001_core.sql#apply_changes, src/adapters/storage/commands.functions.ts

#### REQ-0042 – Angre/gjør om for strukturoperasjoner
De transaksjonelle strukturoperasjonene skal støtte angre og gjør om.

- **Kilde:** Kap. 3.4 (l. 151) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** CORE, UI · **Invarianter:** INV-08
- **Avhengigheter:** REQ-0041
- **Status:** Verifisert
- **Akseptansekriterier:**
  - For hver operasjonstype: utfør → angre gir identisk modell som før; gjør om gir identisk modell som etter.
- **Tester:**
  - enhet: undo/redo-rundtur for alle seks operasjonstyper
- **Implementering:** src/core/commands/apply.ts#inverse, src/core/commands/apply.ts, src/app/project/use-commands.ts
- **Merknad:** Gjør om er ikke testet systematisk for hver strukturoperasjon (bare angring).

#### REQ-0043 – Manus og film kan aldri divergere strukturelt
Systemet skal ikke kunne ende i en tilstand der manus og film har forskjellige aktive scenestrukturer.

- **Kilde:** Kap. 3.4 (l. 152) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** CORE · **Invarianter:** INV-01
- **Avhengigheter:** REQ-0016; REQ-0041
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En konsistenssjekk av aktiv manusstruktur mot aktiv filmstruktur lykkes etter enhver sekvens av operasjoner, inkludert angre/gjør om.
- **Tester:**
  - integrasjon: property-based test med tilfeldige operasjonssekvenser
- **Implementering:** src/core/views.ts, db/migrations/0001_core.sql

### Kapittel 4

#### REQ-0044 – Import av manusdokumenter
Programmet skal kunne importere eksisterende manusdokumenter, særlig DOCX og relevante profesjonelle manusformater.

- **Kilde:** Kap. 4.1 (l. 156) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt det engelske referansemanuset (DOCX), når det importeres, så opprettes en strukturert manusversjon.
  - Gitt det norske referansemanuset (PDF fra Final Draft 11), når det importeres, så opprettes en strukturert manusversjon.
- **Tester:**
  - import/eksport: import av referansemanus DOCX og PDF
- **Implementering:** src/engine/import/docx-lines.ts, src/app/script/ImportDialog.tsx, src/engine/import/browser.ts, src/engine/import/pdf-lines.ts
- **Merknad:** Referansen «DEL 2.docx» er erstattet av hele norsk manus (PDF, Final Draft 11, 106 s., US Letter) og hele engelsk manus (DOCX). PDF-import er dermed i praksis nødvendig; se DEC-0013 (PDF-import).

#### REQ-0045 – Referansemanus som formatreferanse
Ved utvikling skal et konkret referansemanus brukes som eksempel på forventet manusformat.

- **Kilde:** Kap. 4.1 (l. 157) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** PROCESS, SCRIPT
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Parser- og layouttester bruker referansemanusene som testfixtures.
- **Tester:**
  - manuell: testsuite inneholder referansemanus som fixtures
- **Implementering:** src/core/screenplay/paginate.ts, src/core/screenplay/parse.ts
- **Merknad:** Opprinnelig «DEL 2.docx»; erstattet (bekreftet 2026-10-08) av hele norsk manus (PDF, 96 nummererte scener med hull opp til 109 og minst én unummerert scene) og hele engelsk manus (DOCX).

#### REQ-0046 – Gjenkjenning av profesjonelle manuselementer
Import skal håndtere manus med nummererte scener, sceneoverskrifter med INT./EXT., lokasjon og tidspunkt, handlingsbeskrivelser, karakterbetegnelser, innrykket dialog, parentetiske instruksjoner, betegnelser som CONT'D og O.S., samt sidetall og profesjonell manuslayout – inkludert sceneoverskrifter med scenenummer på begge sider, f.eks. «31 EXT. VED MELKERAMPA - KVELD 31».

- **Kilde:** Kap. 4.1 (l. 158-172) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT
- **Avhengigheter:** REQ-0044
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt referansemanuset, så klassifiseres hver linje korrekt som sceneoverskrift, handling, karakter, dialog, parentetisk, overgang e.l., og CONT'D/O.S. tolkes som utvidelser og ikke som del av karakternavnet.
- **Tester:**
  - enhet: parser-fixtures for hvert elementtype
  - import/eksport: elementklassifisering mot fasit for referansemanus
- **Implementering:** src/core/screenplay/parse.ts
- **Merknad:** Opprinnelig beskrevet for «DEL 2.docx»; gjelder fortsatt for nye referansemanus.

#### REQ-0047 – Manusdeler som starter/slutter midt i scene
Programmet må håndtere manusdeler som starter eller slutter midt i en scene.

- **Kilde:** Kap. 4.1 (l. 177-178) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT
- **Avhengigheter:** REQ-0044
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et manusutdrag som begynner med fortsettelse av en scene, så importeres teksten uten tap og uten at det opprettes en fiktiv scene.
- **Tester:**
  - import/eksport: fixture som starter midt i scene og slutter midt i scene
- **Implementering:** src/core/screenplay/plan.ts, src/core/screenplay/parse.ts
- **Merknad:** Se også REQ-0060 (passasjer før første sceneoverskrift).

#### REQ-0048 – Uregelmessige scenenumre uten oppdiktede scener
Programmet må håndtere manglende eller uregelmessige scenenumre uten å finne opp nye scener.

- **Kilde:** Kap. 4.1 (l. 179) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT · **Invarianter:** INV-02
- **Avhengigheter:** REQ-0044
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt det norske referansemanuset med 96 nummererte scener med hull opp til 109 og minst én unummerert scene, så importeres nøyaktig de scenene som finnes (inkl. den unummererte), og numrene bevares som de står.
- **Tester:**
  - import/eksport: antall scener og originalnumre mot fasit
- **Implementering:** src/core/screenplay/parse.ts
- **Merknad:** Referansemanusets kjente egenskaper (hull opp til 109, unummerert scene) brukt i akseptanse.

#### REQ-0049 – Be om manglende referansefiler
Hvis referansemanuset ikke er tilgjengelig i Claude-prosjektet, skal det bes om at det legges ved som formatreferanse; det skal ikke antas at filen automatisk følger med prosjektmandatet.

- **Kilde:** Kap. 4.1 (l. 180) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Før parserarbeid starter er referansemanusene bekreftet tilgjengelige, eller brukeren er bedt om dem.
- **Tester:**
  - manuell: prosesssjekk
- **Merknad:** Opprinnelig om «DEL 2.docx»; gjelder nå de erstattende norske (PDF) og engelske (DOCX) manusene.

#### REQ-0050 – Originaltro profesjonell manusvisning
Manuset skal vises slik et profesjonelt filmmanus vises, og følgende skal bevares eller rekonstrueres korrekt: sideformat, marger, skrifttype og størrelse, linjeavstand, innrykk, dialogkolonner, sceneoverskrifter, scenenumre, sidetall, parentetiske instruksjoner, og linje- og sideskift etter gjeldende manusregler.

- **Kilde:** Kap. 4.2 (l. 182-194) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT, UI
- **Avhengigheter:** REQ-0044
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt det importerte norske referansemanuset (US Letter), så gir manusvisningen samme sideantall (106) og samme sideskift som originalen innenfor definert toleranse.
- **Tester:**
  - visuell: side-ved-side-sammenligning mot original-PDF
  - enhet: pagineringsmotor mot fasit
- **Implementering:** src/core/screenplay/script-pages.ts, src/app/script/ScriptPageView.tsx

#### REQ-0051 – Manusvisning er ikke notat/tabell/kort
Manusvisningen skal ikke erstattes av en vanlig notateditor, en tabell eller en kortvisning.

- **Kilde:** Kap. 4.2 (l. 195) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT, UI
- **Avhengigheter:** REQ-0050
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Hovedmanusvisningen er en paginert manusside-visning; eventuelle tabell-/kortvisninger er tilleggsvisninger.
- **Tester:**
  - manuell: UX-gjennomgang
- **Implementering:** src/app/script/ScriptPageView.tsx

#### REQ-0052 – Korrekt ombrytning og paginering ved redigering
Ved redigering skal tekst ombrytes og pagineres korrekt etter filmmanusregler.

- **Kilde:** Kap. 4.2 (l. 196) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT
- **Avhengigheter:** REQ-0050
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en replikk som forlenges over sideskift, så brytes den med (MORE)/(CONT'D) etter manusregler og etterfølgende sider repagineres.
- **Tester:**
  - enhet: pagineringsregler (dialogbrudd, sceneoverskrift ikke nederst på side o.l.)
- **Implementering:** src/core/screenplay/paginate.ts

#### REQ-0053 – Originaldokumentet bevares uendret
Originaldokumentet skal bevares uendret som historisk referanse.

- **Kilde:** Kap. 4.2 (l. 197) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT, VERSION, SECURITY
- **Avhengigheter:** REQ-0044
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Importert originalfil lagres med hash og kan lastes ned byte-identisk etter vilkårlige redigeringer.
- **Tester:**
  - dataintegritet: hash av originalfil før/etter redigering
- **Implementering:** db/migrations/0002_import_profiles.sql, src/app/script/ImportDialog.tsx

#### REQ-0054 – Analyse ødelegger ikke visuell gjengivelse
Intern analyse og strukturering av manuset skal ikke ødelegge den visuelle gjengivelsen.

- **Kilde:** Kap. 4.2 (l. 198) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT
- **Avhengigheter:** REQ-0050
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et importert manus, når scenedeteksjon/strukturering kjøres, så er visningen uendret i layout.
- **Tester:**
  - visuell: regresjonstest av manusvisning før/etter analyse
- **Implementering:** src/core/screenplay/parse.ts

#### REQ-0055 – Automatisk tolkning av manusstruktur ved import
Når et manus importeres, skal systemet automatisk identifisere scener, lese scenenumre, identifisere sceneoverskrifter, registrere lokasjoner, registrere tidspunkt og identifisere dialog, handling og karakterer.

- **Kilde:** Kap. 4.3 (l. 200-206) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT, LIBRARY
- **Avhengigheter:** REQ-0044
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt referansemanuset, så har hver scene registrert nummer, overskrift, lokasjon og tidspunkt, og karakterlisten samsvarer med fasit.
- **Tester:**
  - import/eksport: deteksjonspresisjon mot fasit
- **Implementering:** src/core/screenplay/parse.ts
- **Merknad:** Punkt 1–6 i listen.

#### REQ-0056 – Permanente scene-ID-er opprettes ved import
Ved manusimport skal systemet automatisk opprette permanente sceneidentiteter.

- **Kilde:** Kap. 4.3 (l. 207) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT, CORE · **Invarianter:** INV-02
- **Avhengigheter:** REQ-0034; REQ-0055
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Hver detektert scene har en intern ID uavhengig av scenenummeret.
- **Tester:**
  - enhet: importer oppretter ID per scene
- **Implementering:** src/core/screenplay/plan.ts, src/core/commands/apply.ts#ImportScreenplay
- **Merknad:** Punkt 7.

#### REQ-0057 – Strukturert manuskopi ved import
Ved manusimport skal systemet automatisk opprette en strukturert manuskopi.

- **Kilde:** Kap. 4.3 (l. 208) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT
- **Avhengigheter:** REQ-0053; REQ-0055
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Etter import finnes både uendret original og en strukturert (blokkbasert) manusversjon.
- **Tester:**
  - enhet: import gir to adskilte representasjoner
- **Implementering:** db/migrations/0002_import_profiles.sql, src/core/screenplay/plan.ts
- **Merknad:** Punkt 8.

#### REQ-0058 – Markering av usikre tolkninger
Ved manusimport skal systemet markere usikre tolkninger.

- **Kilde:** Kap. 4.3 (l. 209) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT, UI
- **Avhengigheter:** REQ-0055
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en tvetydig linje (f.eks. sceneoverskrift uten INT./EXT.), så markeres tolkningen som usikker og vises i en gjennomgangsliste.
- **Tester:**
  - enhet: tvetydige fixtures gir usikkerhetsflagg
- **Implementering:** src/app/script/Inspector.tsx, src/app/script/ScriptPageView.tsx, src/core/screenplay/parse.ts
- **Merknad:** Punkt 9.

#### REQ-0059 – Manuell korrigering av scenedeteksjon
Brukeren skal kunne korrigere feilaktig scenedeteksjon manuelt.

- **Kilde:** Kap. 4.3 (l. 210) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT, UI · **Invarianter:** INV-03
- **Avhengigheter:** REQ-0055
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan endre elementtype på en linje, slå sammen feilaktig delte scener og dele feilaktig sammenslåtte scener etter import.
- **Tester:**
  - e2e: korriger deteksjonsfeil
- **Implementering:** src/core/commands/apply.ts#SetBlockKind,EditSceneHeading,SetUncertainty,SplitScene,MergeScenes, src/app/script/Inspector.tsx

#### REQ-0060 – Passasjer før første sceneoverskrift
Manuspassasjer før første sceneoverskrift skal bevares og kunne kobles til en tidligere scene.

- **Kilde:** Kap. 4.3 (l. 211) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT
- **Avhengigheter:** REQ-0047
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt tekst før første sceneoverskrift, så bevares den som egen blokk og kan kobles til en eksisterende scene.
- **Tester:**
  - import/eksport: fixture med innledende scenefortsettelse
- **Implementering:** src/core/screenplay/plan.ts, src/app/script/ImportDialog.tsx

#### REQ-0061 – Opprette scener
Brukeren skal kunne opprette scener.

- **Kilde:** Kap. 4.4 (l. 213-214) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT, CORE · **Invarianter:** INV-01
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Ny scene får permanent ID og vises i både manus og filmstruktur.
- **Tester:**
  - integrasjon: opprett scene
- **Implementering:** src/app/script/Inspector.tsx, src/core/commands/apply.ts#CreateScene

#### REQ-0062 – Flytte scener
Brukeren skal kunne flytte scener.

- **Kilde:** Kap. 4.4 (l. 215) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT, CORE · **Invarianter:** INV-01, INV-03
- **Avhengigheter:** REQ-0017
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Flyttet scene beholder ID og rekkefølgen oppdateres i manus og film.
- **Tester:**
  - integrasjon: flytt scene
- **Implementering:** src/core/commands/apply.ts#MoveOccurrence, src/app/script/SceneNavigator.tsx

#### REQ-0063 – Skjule eller deaktivere scener
Brukeren skal kunne skjule eller deaktivere scener.

- **Kilde:** Kap. 4.4 (l. 216) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT, CORE · **Invarianter:** INV-14
- **Avhengigheter:** REQ-0019; REQ-0021
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Deaktivert scene utelates fra aktivt innhold men er ikke slettet.
- **Tester:**
  - integrasjon: deaktiver scene
- **Implementering:** src/core/commands/apply.ts#SetOccurrenceActive, src/app/script/SceneNavigator.tsx
- **Merknad:** «Skjule eller deaktivere» – se DEC-0015 (skjul vs. deaktiver) og REQ-0021.

#### REQ-0064 – Gjenaktivere scener
Brukeren skal kunne aktivere skjulte eller deaktiverte scener igjen.

- **Kilde:** Kap. 4.4 (l. 217) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT, CORE · **Invarianter:** INV-14
- **Avhengigheter:** REQ-0020
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gjenaktivert scene vises igjen på sin plass med alt materiale.
- **Tester:**
  - integrasjon: gjenaktiver scene
- **Implementering:** src/core/commands/apply.ts#SetOccurrenceActive, src/app/script/SceneNavigator.tsx

#### REQ-0065 – Redigere dialog
Brukeren skal kunne redigere dialog.

- **Kilde:** Kap. 4.4 (l. 218) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT · **Invarianter:** INV-07
- **Avhengigheter:** REQ-0052
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Endret replikk beholder replikk-ID og lagres i ny manustilstand.
- **Tester:**
  - enhet: rediger replikk
- **Implementering:** src/core/commands/apply.ts#EditBlockText, src/app/script/Inspector.tsx

#### REQ-0066 – Redigere handling
Brukeren skal kunne redigere handling.

- **Kilde:** Kap. 4.4 (l. 219) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT · **Invarianter:** INV-07
- **Avhengigheter:** REQ-0052
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Endret handlingsblokk beholder blokk-ID.
- **Tester:**
  - enhet: rediger handlingsblokk
- **Implementering:** src/core/commands/apply.ts#EditBlockText,InsertBlock,RemoveBlock, src/app/script/Inspector.tsx

#### REQ-0067 – Splitte scener
Brukeren skal kunne splitte scener.

- **Kilde:** Kap. 4.4 (l. 220) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT, CORE · **Invarianter:** INV-03
- **Avhengigheter:** REQ-0041
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Narrativ splitting gir to manusscener; den opprinnelige beholder sin ID og den nye får ny ID; operasjonen kan angres.
- **Tester:**
  - integrasjon: splitt scene og angre
- **Implementering:** src/core/commands/apply.ts#SplitScene
- **Merknad:** Hvilken del som beholder opprinnelig ID er ikke spesifisert – se DEC-0015 (narrativ splitting).

#### REQ-0068 – Slå sammen scener
Brukeren skal kunne slå sammen scener.

- **Kilde:** Kap. 4.4 (l. 221) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT, CORE · **Invarianter:** INV-03
- **Avhengigheter:** REQ-0041
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Sammenslåing gir én scene; tilknyttet materiale fra begge bevares; operasjonen kan angres.
- **Tester:**
  - integrasjon: slå sammen og angre
- **Implementering:** src/core/commands/apply.ts#MergeScenes

#### REQ-0069 – Sammenligne manusversjoner
Brukeren skal kunne sammenligne manusversjoner.

- **Kilde:** Kap. 4.4 (l. 222) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT, VERSION
- **Avhengigheter:** REQ-0078
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan velge to manusversjoner og se forskjellene.
- **Tester:**
  - e2e: velg to versjoner og vis diff
- **Implementering:** src/core/screenplay/versions.ts#diffSnapshots, src/app/script/VersionsDialog.tsx
- **Merknad:** Detaljert i 5.1 (REQ-0078).

#### REQ-0070 – Angre og gjøre om i manus
Brukeren skal kunne angre og gjøre om endringer i manuset.

- **Kilde:** Kap. 4.4 (l. 223) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT, CORE · **Invarianter:** INV-08
- **Avhengigheter:** REQ-0042
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Alle manusredigeringer og sceneoperasjoner kan angres og gjøres om.
- **Tester:**
  - enhet: undo/redo-stakk for manusoperasjoner
- **Implementering:** src/app/project/use-commands.ts, src/core/commands/apply.ts

#### REQ-0071 – Narrativ splitting vs. produksjonsteknisk oppdeling
En narrativ splitting som skaper to selvstendige manusscener skal behandles annerledes enn en produksjonsteknisk oppdeling for videogenerering.

- **Kilde:** Kap. 4.4 (l. 224) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** CORE, SCRIPT, TIMELINE · **Invarianter:** INV-10
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Datamodellen har adskilte begreper for manusscene og produksjonsdelsekvens/segment.
- **Tester:**
  - enhet: produksjonssegment opprettes uten ny manusscene
- **Implementering:** src/core/commands/apply.ts#SplitScene
- **Merknad:** Jf. kap. 34 pkt. 14.

#### REQ-0072 – Produksjonsoppdeling endrer ikke scenenummerering
Produksjonsteknisk oppdeling skal ikke endre manusets scenenummerering.

- **Kilde:** Kap. 4.4 (l. 225) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** CORE, SCRIPT · **Invarianter:** INV-10
- **Avhengigheter:** REQ-0071
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en scene delt i tre produksjonssegmenter, så er manusets scenenumre og sceneantall uendret.
- **Tester:**
  - integrasjon: segmentering → manusnummerering uendret
- **Implementering:** src/core/commands/apply.ts#CreateSegments

#### REQ-0073 – Søk og filtrering i manus
Manuset skal kunne søkes og filtreres etter karakter, objekt eller rekvisitt, lokasjon, scene, dialoginnhold, produksjonsstatus, synkroniseringsavvik og andre relevante metadata.

- **Kilde:** Kap. 4.5 (l. 227-235) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT, UI
- **Avhengigheter:** REQ-0055
- **Status:** Verifisert
- **Akseptansekriterier:**
  - For hvert filterkriterium gir filtrering kun scener/passasjer som matcher.
- **Tester:**
  - enhet: filterlogikk per kriterium
  - e2e: fritekstsøk i dialog
- **Implementering:** src/core/screenplay/filter.ts, src/app/script/SceneNavigator.tsx, src/core/assembly/status.ts#matchingScenes
- **Merknad:** Filter på synkroniseringsavvik forutsetter REQ-0025.

#### REQ-0074 – Vis bare scener med valgt karakter
Brukeren skal kunne velge en karakter og få vist bare scener der denne karakteren opptrer.

- **Kilde:** Kap. 4.5 (l. 236) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT, LIBRARY, UI
- **Avhengigheter:** REQ-0073
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt karakteren Maja, så vises nøyaktig scenene der Maja opptrer (inkl. via aliaser).
- **Tester:**
  - integrasjon: karakterfilter mot fasit
- **Implementering:** src/core/screenplay/filter.ts#sceneHasCharacter, src/core/screenplay/filter.ts#matchingOccurrences, src/app/script/ScriptWorkspace.tsx

#### REQ-0075 – Filtrering er ikke deaktivering
Filtrering av manusvisningen skal ikke være det samme som å deaktivere scener i produksjonen, og skal ikke endre produksjonens aktive innhold.

- **Kilde:** Kap. 4.5 (l. 237) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 2
- **Moduler:** SCRIPT, CORE · **Invarianter:** INV-14
- **Avhengigheter:** REQ-0021
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et aktivt filter, så er filmens aktive innhold og spilletid uendret.
- **Tester:**
  - integrasjon: filter påvirker ikke aktiv struktur
- **Implementering:** src/core/screenplay/filter.ts

### Kapittel 5

#### REQ-0076 – Mange manusversjoner med full historikk
Animatic Studio skal støtte mange manusversjoner med full historikk.

- **Kilde:** Kap. 5.1 (l. 241) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** VERSION, SCRIPT
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan opprette, liste og åpne et vilkårlig antall manusversjoner.
- **Tester:**
  - integrasjon: opprett og åpne flere versjoner
- **Implementering:** db/migrations/0003_script_versions.sql, src/app/script/VersionsDialog.tsx

#### REQ-0077 – Innhold i hver manusversjon
Hver manusversjon skal bevare manusinnhold, scenerekkefølge, synlighet, scenenummerering, relasjoner til tidligere versjoner og koblinger til produsert materiale.

- **Kilde:** Kap. 5.1 (l. 242-248) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** VERSION, SCRIPT
- **Avhengigheter:** REQ-0076
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gjenåpning av en eldre versjon gjenskaper innhold, rekkefølge, synlighet, nummerering, foreldreversjon og materialkoblinger slik de var.
- **Tester:**
  - dataintegritet: snapshot-rundtur for alle seks elementer
- **Implementering:** src/core/screenplay/versions.ts, src/core/screenplay/versions.ts#snapshotFromState, db/migrations/0003_script_versions.sql, src/app/script/VersionsDialog.tsx, src/core/screenplay/restore-version.ts

#### REQ-0078 – Versjonssammenligning med endringstyper
Systemet skal kunne sammenligne manusversjoner og identifisere nye scener, fjernede eller skjulte scener, flyttede scener, endret dialog, endret handling, endrede sceneoverskrifter og endringer i karakterer og objekter.

- **Kilde:** Kap. 5.1 (l. 249-256) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** VERSION, SCRIPT · **Invarianter:** INV-03
- **Avhengigheter:** REQ-0077
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt to versjoner med kjente endringer av hver type, så rapporteres hver endring med korrekt type.
- **Tester:**
  - enhet: diff-motor med fixtures per endringstype
- **Implementering:** src/core/screenplay/versions.ts#diffSnapshots, src/core/screenplay/versions.ts, src/app/script/VersionsDialog.tsx
- **Merknad:** «Sammenligning av versjoner» er plassert i fase 6; enkel sammenligning (REQ-0069) kan komme tidligere.

#### REQ-0079 – Omnummerert scene er ikke ny scene
En scene som bare har fått nytt nummer, skal ikke feilaktig behandles som en ny scene.

- **Kilde:** Kap. 5.1 (l. 257) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 2
- **Moduler:** VERSION, CORE · **Invarianter:** INV-02, INV-03
- **Avhengigheter:** REQ-0034
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en scene omnummerert fra 42 til 45, så rapporterer sammenligningen den som omnummerert/flyttet, ikke som ny + fjernet.
- **Tester:**
  - enhet: diff basert på scene-ID
- **Implementering:** src/core/screenplay/versions.ts#diffSnapshots

#### REQ-0080 – Valg av nummereringsmetode ved hver eksport
Ved hver manuseksport skal brukeren kunne velge nummereringsmetode.

- **Kilde:** Kap. 5.2 (l. 259) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 2
- **Moduler:** EXPORT, SCRIPT, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Eksportdialogen krever/tilbyr valg av nummereringsmetode hver gang.
- **Tester:**
  - e2e: eksportdialog viser nummereringsvalg
- **Implementering:** src/app/script/ExportDialog.tsx
- **Merknad:** Jf. kap. 34 pkt. 4.

#### REQ-0081 – Fortløpende nummerering
Nummereringsvalgene skal omfatte fortløpende nummerering, der alle aktive scener nummereres på nytt.

- **Kilde:** Kap. 5.2 (l. 261-262) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** EXPORT, SCRIPT · **Invarianter:** INV-02
- **Avhengigheter:** REQ-0080
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt 5 aktive scener, så nummereres de 1–5 i eksporten.
- **Tester:**
  - enhet: nummereringsalgoritme fortløpende
- **Implementering:** src/core/screenplay/numbering.ts
- **Merknad:** Linje 261 og 262 er duplikater.

#### REQ-0082 – Bevar produksjonsnummerering med mellomnumre
Nummereringsvalgene skal omfatte bevaring av produksjonsnummerering, der etablerte scenenumre beholdes og nye scener kan få mellomnumre som 42A og 42B.

- **Kilde:** Kap. 5.2 (l. 263-264) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** EXPORT, SCRIPT · **Invarianter:** INV-02
- **Avhengigheter:** REQ-0080
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt to nye scener mellom 42 og 43, så eksporteres de som 42A og 42B, og øvrige numre er uendret.
- **Tester:**
  - enhet: nummereringsalgoritme med mellomnumre, inkl. kanttilfeller (42A→42AA e.l.)
- **Implementering:** src/core/screenplay/numbering.ts
- **Merknad:** Linje 263 og 264 er duplikater.

#### REQ-0083 – Bevar valgt historisk nummerering
Nummereringsvalgene skal omfatte bevaring av valgt historisk nummerering, der nummereringen fra en bestemt tidligere manusversjon brukes der det er hensiktsmessig.

- **Kilde:** Kap. 5.2 (l. 265) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** EXPORT, SCRIPT, VERSION · **Invarianter:** INV-02
- **Avhengigheter:** REQ-0080; REQ-0077
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt valgt historisk versjon V, så får scener som finnes i V samme nummer som i V.
- **Tester:**
  - enhet: nummerering basert på historisk versjon
- **Implementering:** src/core/screenplay/numbering.ts, src/app/script/ExportDialog.tsx
- **Merknad:** «Der det er hensiktsmessig» er udefinert – se OPEN_QUESTIONS B (historisk nummerering).

#### REQ-0084 – Valg om å inkludere skjulte scener i eksport
Brukeren skal kunne velge om skjulte eller deaktiverte scener skal inkluderes i manuseksporten.

- **Kilde:** Kap. 5.2 (l. 266) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** EXPORT · **Invarianter:** INV-14
- **Avhengigheter:** REQ-0080
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Med valget av utelates deaktiverte scener; med valget på inkluderes de (med tydelig markering).
- **Tester:**
  - import/eksport: eksport med og uten deaktiverte scener
- **Implementering:** src/app/script/ExportDialog.tsx, src/core/screenplay/numbering.ts
- **Merknad:** Hvordan inkluderte deaktiverte scener markeres og nummereres er ikke spesifisert.

#### REQ-0085 – Eksportvalg endrer ikke interne ID-er
Eksportvalg skal ikke endre prosjektets interne sceneidentiteter.

- **Kilde:** Kap. 5.2 (l. 267) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 2
- **Moduler:** EXPORT, CORE · **Invarianter:** INV-02
- **Avhengigheter:** REQ-0080
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Etter eksport med hvilken som helst nummereringsmetode er alle scene-ID-er og relasjoner uendret.
- **Tester:**
  - dataintegritet: ID-sett før/etter eksport
- **Implementering:** src/core/screenplay/numbering.ts
- **Merknad:** Jf. kap. 34 pkt. 4.

#### REQ-0086 – Forhåndsvisning av nummerering før eksport
Programmet skal vise en forhåndsvisning av nummereringen før eksport.

- **Kilde:** Kap. 5.2 (l. 268) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** EXPORT, UI
- **Avhengigheter:** REQ-0080
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Eksportdialogen viser liste over scener med resulterende numre før brukeren bekrefter.
- **Tester:**
  - e2e: forhåndsvisning oppdateres ved bytte av metode
- **Implementering:** src/app/script/ExportDialog.tsx

#### REQ-0087 – Manuseksport til DOCX
Programmet skal kunne eksportere korrekt formatert manus til DOCX (prioritert format).

- **Kilde:** Kap. 5.3 (l. 270-272) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** EXPORT, SCRIPT
- **Avhengigheter:** REQ-0050
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Eksportert DOCX åpnes i Word med korrekt manuslayout.
- **Tester:**
  - import/eksport: DOCX-eksport og reimport-rundtur
- **Implementering:** src/engine/export/screenplay-docx.ts

#### REQ-0088 – Manuseksport til PDF
Programmet skal kunne eksportere korrekt formatert manus til PDF (prioritert format).

- **Kilde:** Kap. 5.3 (l. 270, 273) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** EXPORT, SCRIPT
- **Avhengigheter:** REQ-0050
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Eksportert PDF har samme paginering som manusvisningen.
- **Tester:**
  - visuell: PDF mot manusvisning
- **Implementering:** src/engine/export/screenplay-pdf.ts

#### REQ-0089 – Andre profesjonelle manusformater
Programmet skal kunne eksportere til andre relevante profesjonelle manusformater dersom implementeringen støtter dem pålitelig.

- **Kilde:** Kap. 5.3 (l. 274) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** EXPORT
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Hvert ekstra format (f.eks. FDX, Fountain) har rundtur-test før det tilbys.
- **Tester:**
  - import/eksport: rundtur per format
- **Implementering:** src/core/screenplay/fountain.ts, src/engine/import/browser.ts, src/app/script/ImportDialog.tsx, src/app/script/ExportDialog.tsx
- **Merknad:** Betinget krav («dersom … pålitelig»).

#### REQ-0090 – Eksport bevarer layout, rekkefølge og nummerering
Eksportert manus skal opprettholde korrekt layout, sceneorden og nummerering.

- **Kilde:** Kap. 5.3 (l. 275) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** EXPORT
- **Avhengigheter:** REQ-0087; REQ-0088
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Eksportert scenerekkefølge og numre samsvarer med forhåndsvisningen og aktiv struktur.
- **Tester:**
  - import/eksport: verifiser rekkefølge og numre i eksportfil
- **Implementering:** src/engine/export/screenplay-pdf.ts, src/engine/export/screenplay-docx.ts

#### REQ-0091 – Manuseksport krever ikke AI
Manuseksport skal ikke kreve AI-generering.

- **Kilde:** Kap. 5.3 (l. 276) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 2
- **Moduler:** EXPORT · **Invarianter:** INV-11
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Eksport fungerer uten nettverkstilgang til AI-leverandører.
- **Tester:**
  - integrasjon: eksport med AI-adaptere deaktivert
- **Implementering:** src/engine/export/screenplay-pdf.ts, src/engine/export/screenplay-docx.ts

### Kapittel 6

#### REQ-0092 – Manus som aktivt navigasjonsverktøy
Manuset skal ikke bare være en tekstlig beskrivelse av filmen, men et aktivt navigasjonsverktøy.

- **Kilde:** Kap. 6 (l. 279) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** SCRIPT, TIMELINE, UI · **Invarianter:** INV-01
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Fra manuset kan brukeren navigere til tilsvarende sted i film/tidslinje (jf. REQ-0097).
- **Tester:**
  - e2e: navigasjon fra manus
- **Implementering:** src/app/script/Inspector.tsx, src/app/assembly/AssemblyWorkspace.tsx, src/routes/prosjekt.$projectId.montering.tsx
- **Merknad:** Paraply for 6.1–6.4.

#### REQ-0093 – Manusblokker koblet til tidsintervaller
Hver replikk og handlingsbeskrivelse skal kunne kobles til ett eller flere tidsintervaller.

- **Kilde:** Kap. 6.1 (l. 281) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** SCRIPT, TIMELINE
- **Avhengigheter:** REQ-0105
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan knytte en replikk til to adskilte intervaller, og begge vises.
- **Tester:**
  - enhet: manusblokk ↔ intervaller (1:n)
- **Implementering:** src/core/commands/apply.ts, src/core/assembly/film.ts, src/app/assembly/ClipPanel.tsx, db/migrations/0012_clip_parts_time_links.sql

#### REQ-0094 – Tidskoblinger med permanente ID-er
Koblinger mellom manusblokker og tidsintervaller skal lagres med permanente identifikatorer.

- **Kilde:** Kap. 6.1 (l. 282) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** CORE, TIMELINE · **Invarianter:** INV-02
- **Avhengigheter:** REQ-0037
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Koblingen refererer til blokk-ID og klipp-/hendelses-ID, ikke posisjon eller tekst.
- **Tester:**
  - dataintegritet: kobling overlever omnummerering og flytting
- **Implementering:** src/core/model.ts, db/migrations/0012_clip_parts_time_links.sql

#### REQ-0095 – Replikk-koblingstyper
En replikk skal kunne knyttes til et dialogopptak, et bestemt tidspunkt, en hendelse i 2D-scenen og ett eller flere filmklipp.

- **Kilde:** Kap. 6.1 (l. 283-287) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** SCRIPT, AUDIO, COMPOSE, TIMELINE
- **Avhengigheter:** REQ-0093
- **Status:** Verifisert
- **Akseptansekriterier:**
  - For hver av de fire koblingstypene kan en replikk kobles og koblingen vises.
- **Tester:**
  - integrasjon: koblingstyper per replikk
- **Implementering:** src/app/assembly/ClipPanel.tsx, src/app/scene-editor/LayerEvents.tsx, src/core/assembly/block-links.ts, src/app/script/BlockLinksSection.tsx

#### REQ-0096 – Handling koblet til flere visuelle hendelser
En handlingsbeskrivelse skal kunne knyttes til flere visuelle hendelser.

- **Kilde:** Kap. 6.1 (l. 288) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** SCRIPT, COMPOSE, TIMELINE
- **Avhengigheter:** REQ-0093
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En handlingsblokk kan ha flere tilknyttede visuelle hendelser.
- **Tester:**
  - enhet: handlingsblokk ↔ hendelser (1:n)
- **Implementering:** src/app/scene-editor/LayerEvents.tsx, src/core/assembly/film.ts, db/migrations/0013_transitions_monochrome.sql

#### REQ-0097 – Klikk på replikk flytter avspillingshodet
Når brukeren klikker på en replikk, skal avspillingshodet kunne flyttes til tilsvarende tidspunkt i filmen.

- **Kilde:** Kap. 6.2 (l. 290) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** SCRIPT, TIMELINE, UI · **Invarianter:** INV-01
- **Avhengigheter:** REQ-0093
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en koblet replikk, når den klikkes, så står avspillingshodet på koblingens starttidspunkt (bilderiktig).
- **Tester:**
  - e2e: klikk replikk → avspillingshode
- **Implementering:** src/core/assembly/film.ts, src/app/assembly/ClipPanel.tsx

#### REQ-0098 – Avspillingshode markerer manuspassasje
Når brukeren flytter avspillingshodet, skal programmet kunne markere den aktuelle manuspassasjen.

- **Kilde:** Kap. 6.2 (l. 291) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** SCRIPT, TIMELINE, UI · **Invarianter:** INV-01
- **Avhengigheter:** REQ-0093
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt avspillingshode innenfor en koblet replikks intervall, så er replikken markert i manuset.
- **Tester:**
  - e2e: scrubbing → markering
- **Implementering:** src/app/assembly/ClipPanel.tsx, src/app/assembly/ClipPanel.tsx

#### REQ-0099 – Toveis navigasjon for alle materialtyper
Toveis navigasjon skal fungere for planlagte animatics, redigerbare 2D-scener, AI-generert video, importert ferdig film og sammensatte scener med flere klipp.

- **Kilde:** Kap. 6.2 (l. 292-297) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** TIMELINE, SCRIPT, COMPOSE
- **Avhengigheter:** REQ-0097; REQ-0098
- **Status:** Verifisert
- **Akseptansekriterier:**
  - For hver av de fem materialtypene fungerer både klikk-til-tid og tid-til-markering.
- **Tester:**
  - e2e: parametrisert over materialtyper
- **Implementering:** src/core/assembly/film.ts, src/app/assembly/ClipPanel.tsx, src/app/script/Inspector.tsx, src/app/assembly/AssemblyWorkspace.tsx
- **Merknad:** AI-generert video-delen forutsetter fase 5. Jf. kap. 34 pkt. 15.

#### REQ-0100 – Manus og film side ved side
Manus og film skal kunne vises side ved side.

- **Kilde:** Kap. 6.2 (l. 298) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** UI, SCRIPT, TIMELINE
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Et arbeidsoppsett viser manus og filmavspiller samtidig.
- **Tester:**
  - visuell: side-ved-side-layout
- **Implementering:** src/app/assembly/ClipPanel.tsx, src/app/assembly/ClipPanel.tsx, src/routes/prosjekt.$projectId.manus.tsx

#### REQ-0101 – Automatisk rulling av/på
Automatisk rulling av manuset under avspilling skal kunne slås av og på.

- **Kilde:** Kap. 6.2 (l. 299) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** UI, SCRIPT
- **Avhengigheter:** REQ-0098
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Med autorulling på følger manuset avspillingen; med av står manuset stille mens markeringen fortsatt oppdateres.
- **Tester:**
  - e2e: veksle autorulling
- **Implementering:** src/app/assembly/ClipPanel.tsx, src/app/assembly/AssemblyWorkspace.tsx
- **Merknad:** Ingen automatisk test av at manuset står stille med av mens markeringen oppdateres.

#### REQ-0102 – Teknisk metadata forstyrrer ikke manuslayout
Manuset skal fremdeles se ut som et profesjonelt filmmanus; tidskoder, produksjonsmarkeringer og annen teknisk metadata skal normalt ikke forstyrre manuslayouten.

- **Kilde:** Kap. 6.3 (l. 301-302) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** SCRIPT, UI
- **Avhengigheter:** REQ-0050
- **Status:** Verifisert
- **Akseptansekriterier:**
  - I ordinær manusvisning vises ingen tidskoder eller produksjonsmarkeringer, og pagineringen er uendret.
- **Tester:**
  - visuell: ordinær visning med og uten koblinger er identisk
- **Implementering:** src/app/script/ScriptWorkspace.tsx, src/core/screenplay/script-pages.ts, src/app/script/ScriptPageView.tsx, src/app/script/StoryTimeSection.tsx

#### REQ-0103 – Teknisk metadata i egne moduser/paneler
Tidskoder, produksjonsmarkeringer og teknisk metadata skal kunne vises i egne arbeidsmoduser og paneler.

- **Kilde:** Kap. 6.3 (l. 303) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** UI
- **Avhengigheter:** REQ-0102
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan slå på en produksjonsmodus/panel som viser tidskoder og markeringer.
- **Tester:**
  - e2e: bytt arbeidsmodus
- **Implementering:** src/core/assembly/technical.ts, src/app/assembly/TechnicalSection.tsx

#### REQ-0104 – Teknisk metadata ikke i eksportert manus
Tidskoder, produksjonsmarkeringer og teknisk metadata skal ikke automatisk inngå i eksportert manus.

- **Kilde:** Kap. 6.3 (l. 304) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** EXPORT
- **Avhengigheter:** REQ-0087
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Standard manuseksport inneholder ingen tidskoder/produksjonsmarkeringer.
- **Tester:**
  - import/eksport: søk etter tidskoder i eksportfil gir null treff
- **Implementering:** src/core/screenplay/numbering.ts#exportPaginationInput, src/engine/export/screenplay-pdf.ts, src/engine/export/screenplay-docx.ts
- **Merknad:** Ingen test eksporterer et prosjekt med produsert materiale og tidskoblinger og sjekker at de ikke kommer med.

#### REQ-0105 – Flernivå tidsmodell
Systemet skal kunne håndtere lokal tid innenfor en scene, tid innenfor en delsekvens, tid innenfor et kildeklipp og absolutt tid i den samlede filmen.

- **Kilde:** Kap. 6.4 (l. 306-310) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** TIMELINE, CORE
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Et tidspunkt kan konverteres korrekt mellom alle fire tidsrom.
- **Tester:**
  - enhet: konverteringsfunksjoner mellom tidsrom
- **Implementering:** src/core/time.ts, src/core/views.ts, src/core/assembly/film.ts, src/core/generation/scene-prompt.ts, src/core/assembly/time-levels.ts, src/app/assembly/TechnicalSection.tsx
- **Merknad:** Ingen samlet test av konvertering mellom alle fire tidsrom, særlig delsekvenstid.

#### REQ-0106 – Bildepresis tidsmodell
Tidsmodellen skal være presis i forhold til prosjektets bildefrekvens.

- **Kilde:** Kap. 6.4 (l. 311) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** TIMELINE
- **Avhengigheter:** REQ-0105
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Tid lagres i heltallige rammer/rasjonelle tall; ingen avrundingsdrift etter gjentatte konverteringer (inkl. 23.976/29.97).
- **Tester:**
  - enhet: rundtur-konvertering uten drift
- **Implementering:** src/core/time.ts
- **Merknad:** Mangler test for at gjentatte konverteringer ikke gir avrundingsdrift (inkl. 29.97).

#### REQ-0107 – Tidskoblinger bevares ved flytting
Når en scene flyttes, skal dens interne tidskoblinger bevares mens den samlede filmens tidskoder beregnes på nytt.

- **Kilde:** Kap. 6.4 (l. 312) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** TIMELINE, CORE · **Invarianter:** INV-01, INV-03
- **Avhengigheter:** REQ-0105
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en scene med koblinger, når den flyttes, så er lokale tider uendret og absolutte tider oppdatert.
- **Tester:**
  - integrasjon: flytt scene → lokale vs. absolutte tider
- **Implementering:** src/core/assembly/film.ts

### Kapittel 7

#### REQ-0108 – Estimering av spilletid etter import
Etter manusimport skal programmet kunne estimere spilletid per scene og for hele filmen.

- **Kilde:** Kap. 7.1 (l. 316) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT, TIMELINE
- **Avhengigheter:** REQ-0055
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Etter import har hver scene og filmen totalt et estimat.
- **Tester:**
  - enhet: estimator på referansemanus
- **Implementering:** src/core/screenplay/duration.ts#estimateProduction, src/app/projects/DurationOverview.tsx

#### REQ-0109 – Grunnlag for varighetsestimater
Estimatene kan baseres på dialogmengde, handlingsbeskrivelser, pauser, montasjer, beskrevet fysisk handling og andre relevante produksjonsantakelser.

- **Kilde:** Kap. 7.1 (l. 317-323) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT
- **Avhengigheter:** REQ-0108
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Estimatoren tar hensyn til minst dialogmengde og handlingsbeskrivelser, og antakelsene er dokumentert/justerbare.
- **Tester:**
  - enhet: estimat endres når dialog/handling endres
- **Implementering:** src/core/screenplay/duration.ts
- **Merknad:** «Kan» – listen er mulige faktorer, ikke absolutte krav.

#### REQ-0110 – Usikre estimater presenteres som usikre
Estimatene må presenteres som usikre når grunnlaget er usikkert.

- **Kilde:** Kap. 7.1 (l. 324) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** UI
- **Avhengigheter:** REQ-0108
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Scener med lite grunnlag (f.eks. montasje uten dialog) vises med usikkerhetsmarkering eller intervall.
- **Tester:**
  - enhet: usikkerhetsgrad beregnes
- **Implementering:** src/core/screenplay/duration.ts, src/app/projects/DurationOverview.tsx, src/app/projects/DurationOverview.tsx
- **Merknad:** Usikkerheten er lik for alle scener; ingen egen vurdering av grunnlaget per scene.

#### REQ-0111 – Brukeren kan korrigere estimater
Brukeren skal kunne korrigere varighetsestimatene.

- **Kilde:** Kap. 7.1 (l. 325) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** TIMELINE, UI
- **Avhengigheter:** REQ-0108
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan overstyre et estimat; totalen oppdateres.
- **Tester:**
  - e2e: overstyr estimat
- **Implementering:** src/core/commands/apply.ts#SetPlannedDuration, src/app/projects/DurationOverview.tsx, src/core/assembly/film.ts#filmClips

#### REQ-0112 – Gradvis mer presis varighet
Etter hvert som produksjonen utvikles, skal estimert varighet erstattes av mer presise tall.

- **Kilde:** Kap. 7.2 (l. 327) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 4
- **Moduler:** TIMELINE
- **Avhengigheter:** REQ-0113
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en scene med 2D-animatic, så brukes animatic-varigheten i totalen i stedet for estimatet.
- **Tester:**
  - enhet: prioritetsrekkefølge for varighetskilder
- **Implementering:** src/core/assembly/status.ts#productionStatus, src/core/assembly/film.ts#filmClips
- **Merknad:** P0 fordi kap. 34 pkt. 16 krever kontinuerlig beregning av estimert og faktisk spilletid.

#### REQ-0113 – Skille mellom varighetstyper
Systemet skal skille mellom estimert varighet, brukerplanlagt varighet, varighet i 2D-animatic, varighet fra AI-generert materiale og faktisk varighet fra importert eller ferdig film.

- **Kilde:** Kap. 7.2 (l. 328-333) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** TIMELINE, CORE
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Hver scene kan lagre alle fem varighetstypene separat.
- **Tester:**
  - enhet: skjema for varighetstyper
- **Implementering:** src/core/assembly/status.ts#productionStatus
- **Merknad:** AI-video som kilde er ikke testet (ingen AI-video kan lages ennå).

#### REQ-0114 – Ingen dobbelttelling av scener
En scene skal ikke dobbeltelles i varighetsberegning selv om flere versjoner finnes.

- **Kilde:** Kap. 7.2 (l. 334) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** TIMELINE
- **Avhengigheter:** REQ-0113
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en scene med tre produksjonsversjoner, så teller kun aktiv versjon i totalen.
- **Tester:**
  - enhet: totalberegning med flere versjoner
- **Implementering:** src/core/assembly/status.ts#productionStatus, src/core/assembly/film.ts#activeFilmTake
- **Merknad:** Testfixturen har bare én take per scene; mangler test med flere produksjonsversjoner av samme scene.

#### REQ-0115 – Skjulte scener utelates fra totalvarighet
Skjulte scener skal utelates fra aktiv totalvarighet.

- **Kilde:** Kap. 7.2 (l. 335) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 2
- **Moduler:** TIMELINE · **Invarianter:** INV-14
- **Avhengigheter:** REQ-0019
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Deaktivering av en scene reduserer totalvarigheten tilsvarende; gjenaktivering legger den til.
- **Tester:**
  - enhet: total med deaktiverte scener
- **Implementering:** src/core/screenplay/duration.ts
- **Merknad:** Gjentar kap. 2 (spilletidsberegning).

#### REQ-0116 – Varighet på egen prosjektoversikt
Varighetsinformasjon skal hovedsakelig vises på en egen prosjektoversikt.

- **Kilde:** Kap. 7.3 (l. 337) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P0 · **Fase:** 2
- **Moduler:** UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Det finnes en egen prosjektoversiktsside med varighetsinformasjon.
- **Tester:**
  - e2e: naviger til prosjektoversikt
- **Implementering:** src/app/projects/DurationOverview.tsx
- **Merknad:** Jf. kap. 34 pkt. 17.

#### REQ-0117 – Ingen varighetstall i ordinær manusvisning
Den ordinære manusvisningen skal ikke fylles med varighetstall ved hver scene.

- **Kilde:** Kap. 7.3 (l. 338) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P0 · **Fase:** 2
- **Moduler:** UI, SCRIPT
- **Avhengigheter:** REQ-0102
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Ordinær manusvisning viser ingen varighetstall per scene.
- **Tester:**
  - visuell: manusvisning uten varighetstall
- **Implementering:** src/app/script/ScriptPageView.tsx
- **Merknad:** Jf. kap. 34 pkt. 17.

#### REQ-0118 – Innhold i prosjektoversikten
Prosjektoversikten skal vise estimert total spilletid, bekreftet spilletid, gjenstående estimert spilletid, antall scener, varighet per scene, andel av filmen som er ferdig, andel som fortsatt er estimert, produksjonsstatus og scener med uavklarte avvik.

- **Kilde:** Kap. 7.3 (l. 339-348) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** UI, TIMELINE
- **Avhengigheter:** REQ-0116; REQ-0113
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Alle ni elementene vises og summerer konsistent (bekreftet + gjenstående = total).
- **Tester:**
  - enhet: aggregeringsfunksjoner
  - visuell: oversiktsside
- **Implementering:** src/core/assembly/status.ts#productionStatus, src/app/projects/DurationOverview.tsx
- **Merknad:** «Scener med uavklarte avvik» forutsetter REQ-0025.

#### REQ-0119 – Navigasjon fra oversikt til scene
Brukeren skal kunne navigere direkte fra prosjektoversikten til en scene.

- **Kilde:** Kap. 7.3 (l. 349) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** UI
- **Avhengigheter:** REQ-0118
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Klikk på en scene i oversikten åpner scenen i manus/scenevisning.
- **Tester:**
  - e2e: klikk-navigasjon
- **Implementering:** src/app/projects/DurationOverview.tsx
- **Merknad:** Ingen automatisk test klikker fra oversikten til scenen.

#### REQ-0120 – Historiske varighetsprognoser
Systemet skal kunne bevare tidligere estimater og vise hvordan forventet filmlengde endres gjennom produksjonen.

- **Kilde:** Kap. 7.4 (l. 351) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** TIMELINE, VERSION, UI
- **Avhengigheter:** REQ-0108
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Det finnes en graf/liste over forventet filmlengde over tid basert på lagrede estimater.
- **Tester:**
  - enhet: lagring av estimat-snapshots
- **Implementering:** src/core/screenplay/duration.ts#snapshotDuration, src/app/projects/DurationHistory.tsx, db/migrations/0028_duration_exports.sql, src/core/screenplay/duration-snapshot.ts
- **Merknad:** Bygger på manusversjonene; 2D-scenenes og planens lengde på tidspunktet lagres ikke.

### Kapittel 8

#### REQ-0121 – Sentralt ressursbibliotek
Animatic Studio skal ha et sentralt bibliotek for alle ressurser som brukes i produksjonen, som omfatter karakterer, objekter, rekvisitter, dyr, lokasjoner, miljøer, bakgrunner, bilder, lydfiler, genererte ressurser og visuelle stilprofiler.

- **Kilde:** Kap. 8 (l. 354-366) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** LIBRARY
- **Status:** Implementert – ikke verifisert
- **Akseptansekriterier:**
  - Hver av de 11 ressurstypene kan opprettes og vises i biblioteket.
- **Tester:**
  - integrasjon: CRUD per ressurstype
- **Implementering:** src/core/model.ts#Asset, src/core/commands/apply.ts#CreateAssets, src/core/library/index.ts, src/app/library/LibraryWorkspace.tsx, src/app/library/AssetDetail.tsx, db/migrations/0004_library_notes.sql, src/core/library/provenance.ts, src/core/library/style-profiles.ts, src/app/library/StyleProfilesPanel.tsx

#### REQ-0122 – Ressurser gjenbrukes på tvers av scener og produksjoner
Ressurser skal kunne brukes i mange scener og flere produksjoner.

- **Kilde:** Kap. 8.1 (l. 368) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** LIBRARY, CORE · **Invarianter:** INV-13
- **Avhengigheter:** REQ-0121
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Samme ressurs-ID refereres fra scener i to produksjoner.
- **Tester:**
  - integrasjon: ressursreferanse på tvers av produksjoner
- **Implementering:** src/core/model.ts#Asset, src/core/production/index.ts
- **Merknad:** Ingen test sjekker eksplisitt at samme ressurs-ID refereres fra scener i to produksjoner.

#### REQ-0123 – Ingen kopier per scene
Det skal ikke være nødvendig å opprette nye kopier av samme karakter eller objekt for hver scene.

- **Kilde:** Kap. 8.1 (l. 369) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** LIBRARY
- **Avhengigheter:** REQ-0122
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Å legge en karakter til en scene skaper en referanse, ikke en kopi.
- **Tester:**
  - enhet: scene–ressurs-relasjon er referanse
- **Implementering:** src/core/commands/apply.ts#AddLayers, src/core/model.ts#CompositionLayer

#### REQ-0124 – Metadata, kategorier, søk og organisering
Biblioteket skal støtte metadata, kategorier, søk, filtrering og hensiktsmessig organisering.

- **Kilde:** Kap. 8.1 (l. 370) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** LIBRARY, UI
- **Avhengigheter:** REQ-0121
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan tagge/kategorisere ressurser og søke/filtrere på dem.
- **Tester:**
  - e2e: søk og filter i bibliotek
- **Implementering:** src/app/library/LibraryWorkspace.tsx, src/core/library/index.ts

#### REQ-0125 – Permanente ressurs-ID-er
Karakterer og andre ressurser skal ha permanente identifikatorer.

- **Kilde:** Kap. 8.2 (l. 372) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** LIBRARY, CORE · **Invarianter:** INV-02
- **Avhengigheter:** REQ-0037
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Omdøping av en ressurs endrer ikke ID-en eller bryter referanser.
- **Tester:**
  - dataintegritet: omdøping bevarer referanser
- **Implementering:** src/core/model.ts#Asset, db/migrations/0004_library_notes.sql
- **Merknad:** Jf. kap. 34 pkt. 3.

#### REQ-0126 – Navnekontroll med alternative navn
Systemet skal støtte foretrukket navn, alternative navn, kallenavn, tidligere navn og språkspesifikke betegnelser for ressurser.

- **Kilde:** Kap. 8.2 (l. 373-378) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** LIBRARY, L10N
- **Avhengigheter:** REQ-0125
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En karakter kan lagre alle fem navnetypene, og søk på alias finner karakteren.
- **Tester:**
  - enhet: aliasoppslag
- **Implementering:** src/core/commands/apply.ts#normalizeAssetFields, src/app/library/AssetDetail.tsx

#### REQ-0127 – Kontekstuell kobling av betegnelser
Ulike betegnelser (f.eks. «Laurits» og «onkel») skal kunne kobles til samme karakter der konteksten tilsier det.

- **Kilde:** Kap. 8.2 (l. 379) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** LIBRARY, SCRIPT, CONTINUITY
- **Avhengigheter:** REQ-0126
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt manuspassasjer der «onkel» refererer til Laurits, så kan disse forekomstene kobles til Laurits uten at alle «onkel»-forekomster nødvendigvis gjør det.
- **Tester:**
  - integrasjon: kontekstuell aliaskobling
- **Implementering:** src/core/library/index.ts, src/app/library/ContextNamesSection.tsx, db/migrations/0026_masks_voices_styles.sql
- **Merknad:** Kontekstavhengig kobling er mer enn enkel alias; se OPEN_QUESTIONS B (kontekstavhengig alias).

#### REQ-0128 – Usikre koblinger foreslås
Usikre koblinger mellom navn og ressurser skal foreslås, ikke gjennomføres ukritisk.

- **Kilde:** Kap. 8.2 (l. 380) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** LIBRARY, UI · **Invarianter:** INV-08
- **Avhengigheter:** REQ-0127
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Usikre koblinger vises som forslag som brukeren må godta før de brukes.
- **Tester:**
  - enhet: forslag har status «foreslått» til godkjent
- **Implementering:** src/core/library/index.ts#librarySuggestions, src/app/library/SuggestionsDialog.tsx

#### REQ-0129 – Deteksjon av stavefeil og inkonsistente navn
Programmet skal kunne identifisere mulige stavefeil og inkonsistente karakternavn, lokasjonsnavn og rekvisittbetegnelser.

- **Kilde:** Kap. 8.2 (l. 381) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** LIBRARY, SCRIPT
- **Avhengigheter:** REQ-0126
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt «Maja» og «Maia» i manuset, så foreslås de som mulig samme karakter.
- **Tester:**
  - enhet: likhetsdeteksjon på navn
- **Implementering:** src/core/continuity/analysis.ts, src/app/continuity/ContinuityAnalysisPanel.tsx

#### REQ-0130 – Konsekvensanalyse ved ressursendring
Hvis en global ressurs endres, skal programmet identifisere scener som kan være påvirket.

- **Kilde:** Kap. 8.3 (l. 383) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** VERSION, LIBRARY
- **Avhengigheter:** REQ-0131
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Ved endring av ressurs R listes alle scener (alle produksjoner) som bruker R.
- **Tester:**
  - integrasjon: endring → liste over berørte scener
- **Implementering:** src/core/library/impact.ts, src/app/library/ApproveImpactDialog.tsx

#### REQ-0131 – Finne scener der en ressurs er brukt
Systemet skal kunne finne scener der en bestemt ressurs er brukt (f.eks. når en vase erstattes av en tekanne).

- **Kilde:** Kap. 8.3 (l. 384) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** LIBRARY, CORE
- **Avhengigheter:** REQ-0122
- **Status:** Verifisert
- **Akseptansekriterier:**
  - For en gitt ressurs vises en «brukt i»-liste med scener.
- **Tester:**
  - enhet: omvendt oppslag ressurs → scener
- **Implementering:** src/core/library/index.ts#assetUsage, src/app/library/AssetDetail.tsx

#### REQ-0132 – Berørte scener flagges for gjennomgang
Scener berørt av en ressursendring skal flagges for gjennomgang.

- **Kilde:** Kap. 8.3 (l. 385) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** VERSION, UI · **Invarianter:** INV-07
- **Avhengigheter:** REQ-0130
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Berørte scener får status «til gjennomgang» synlig i oversikten.
- **Tester:**
  - integrasjon: ressursendring → flagg
- **Implementering:** src/core/library/impact.ts, src/app/library/ApproveImpactDialog.tsx, src/app/scene-editor/LayerInspector.tsx, src/core/continuity/analysis.ts, src/app/continuity/ContinuityAnalysisPanel.tsx

#### REQ-0133 – Ingen automatisk regenerering ved ressursendring
Ingen ferdige scener skal regenereres automatisk når en global ressurs endres.

- **Kilde:** Kap. 8.3 (l. 386) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** VERSION, QUEUE · **Invarianter:** INV-07, INV-12
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Ressursendring oppretter ingen renderjobber.
- **Tester:**
  - integrasjon: ressursendring → renderkø uendret
- **Implementering:** src/app/assembly/AiUpdateSection.tsx

#### REQ-0134 – Brukeren velger scener som skal oppdateres
Brukeren skal kunne velge hvilke scener som skal oppdateres etter en ressursendring.

- **Kilde:** Kap. 8.3 (l. 387) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 6
- **Moduler:** VERSION, UI · **Invarianter:** INV-08
- **Avhengigheter:** REQ-0132
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Fra listen over berørte scener kan brukeren velge et delsett for oppdatering; øvrige forblir uendret.
- **Tester:**
  - e2e: selektiv oppdatering
- **Implementering:** src/core/library/impact.ts, src/app/library/ApproveImpactDialog.tsx, src/core/library/worklist.ts
- **Merknad:** P0 fordi det uttrykker INV-08; selve funksjonen leveres i fase 6.

### Kapittel 9

#### REQ-0135 – Én karakter, flere visuelle varianter
En karakter skal ha én permanent identitet, men kunne ha flere visuelle varianter, som kan omfatte originale referansebilder, illustrerte varianter, filmrealistiske varianter, animatic-varianter, plakatvarianter, ulike antrekk, ulike alderstrinn, ulike frisyrer og midlertidige fysiske tilstander.

- **Kilde:** Kap. 9.1 (l. 391-401) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** LIBRARY
- **Avhengigheter:** REQ-0125
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En karakter kan ha varianter av hver av de ni typene under samme karakter-ID.
- **Tester:**
  - enhet: karakter med flere varianter
- **Implementering:** src/core/model.ts#AssetVariant, src/app/library/AssetDetail.tsx

#### REQ-0136 – Varianter versjoneres og godkjennes separat
Hver visuell variant skal kunne versjoneres og godkjennes separat.

- **Kilde:** Kap. 9.1 (l. 402) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** LIBRARY, VERSION · **Invarianter:** INV-13
- **Avhengigheter:** REQ-0135
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Godkjenning av én variant påvirker ikke status på andre; nye versjoner bevarer tidligere.
- **Tester:**
  - enhet: variantversjonering og godkjenningsstatus
- **Implementering:** src/core/commands/apply.ts#ApproveAssetVersion, db/migrations/0004_library_notes.sql

#### REQ-0137 – AI-basert stilharmonisering
Når bilder fra forskjellige kilder brukes sammen, skal programmet kunne tilby AI-basert stilharmonisering.

- **Kilde:** Kap. 9.2 (l. 404) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** PROMPT, PROVIDER, LIBRARY · **Invarianter:** INV-12
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Brukeren kan velge flere bilder og starte stilharmonisering (med kostnadsgodkjenning).
- **Tester:**
  - integrasjon: harmonisering via mock-adapter
- **Merknad:** Stilharmonisering er i fase 8.

#### REQ-0138 – Harmoniseringsdimensjoner
Karakterbilder skal kunne tilpasses en felles tegnestil, fargepalett, lyssetting, tekstur, detaljgrad og atmosfære.

- **Kilde:** Kap. 9.2 (l. 405-411) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** PROMPT, LIBRARY
- **Avhengigheter:** REQ-0137
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Harmoniseringsprompten inkluderer målverdier for alle seks dimensjonene.
- **Tester:**
  - enhet: promptbygger for harmonisering

#### REQ-0139 – Bevar gjenkjennelig identitet
Stilharmoniseringen skal bevare karakterens gjenkjennelige identitet så langt som mulig.

- **Kilde:** Kap. 9.2 (l. 412) · **Opprinnelse:** mandat · **Type:** ikke-funksjonell · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** PROMPT
- **Avhengigheter:** REQ-0137
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Harmoniseringsprompt inkluderer identitetsbevarende instruksjoner og referansebilder.
- **Tester:**
  - manuell: vurdering av gjenkjennelighet
- **Merknad:** «Så langt som mulig» – ikke absolutt.

#### REQ-0140 – Sammenligne original og harmonisert
Brukeren skal kunne sammenligne original og harmonisert variant før godkjenning.

- **Kilde:** Kap. 9.2 (l. 413) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** UI, LIBRARY · **Invarianter:** INV-08
- **Avhengigheter:** REQ-0137
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Side-ved-side/før-etter-visning finnes før godkjenningsknappen.
- **Tester:**
  - e2e: sammenligning før godkjenning

#### REQ-0141 – Harmonisert bilde brukt lokalt
Et harmonisert karakterbilde skal kunne brukes bare i den aktuelle plakaten eller scenen.

- **Kilde:** Kap. 9.3 (l. 415-416) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** LIBRARY, PRESENT
- **Avhengigheter:** REQ-0137
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Bildet kan brukes lokalt uten å bli synlig i det globale biblioteket.
- **Tester:**
  - integrasjon: lokal bruk

#### REQ-0142 – Harmonisert bilde som alternativ variant
Et harmonisert karakterbilde skal kunne lagres som en alternativ variant.

- **Kilde:** Kap. 9.3 (l. 417) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** LIBRARY · **Invarianter:** INV-13
- **Avhengigheter:** REQ-0135
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Bildet lagres som ny variant under karakteren uten å erstatte eksisterende.
- **Tester:**
  - enhet: lagre som variant

#### REQ-0143 – Publisering til globalt karakterbibliotek
Et harmonisert karakterbilde skal kunne godkjennes og publiseres til det globale karakterbiblioteket.

- **Kilde:** Kap. 9.3 (l. 418) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** LIBRARY, VERSION · **Invarianter:** INV-13
- **Avhengigheter:** REQ-0142
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Etter godkjenning er varianten tilgjengelig i det globale biblioteket.
- **Tester:**
  - integrasjon: godkjenn og publiser
- **Merknad:** Jf. kap. 34 pkt. 25, men plassert i fase 8 – se OPEN_QUESTIONS B (kontinuitetsprinsipper før harmonisering).

#### REQ-0144 – Foretrukket referanse per stilprofil
Et harmonisert karakterbilde skal kunne merkes som foretrukket referanse for en bestemt stilprofil.

- **Kilde:** Kap. 9.3 (l. 419) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** LIBRARY
- **Avhengigheter:** REQ-0147
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - For en karakter og stilprofil kan nøyaktig én variant være foretrukket referanse.
- **Tester:**
  - enhet: foretrukket-referanse per (karakter, stilprofil)

#### REQ-0145 – Publisering er eksplisitt brukerhandling
Publisering av en variant til det globale biblioteket skal være en eksplisitt brukerhandling.

- **Kilde:** Kap. 9.3 (l. 420) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 8
- **Moduler:** LIBRARY · **Invarianter:** INV-13
- **Avhengigheter:** REQ-0143
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Ingen kodevei publiserer en variant uten eksplisitt brukerkommando.
- **Tester:**
  - integrasjon: ingen automatisk publisering
- **Merknad:** Jf. kap. 34 pkt. 25. P0 som prinsipp, selv om funksjonen er fase 8.

#### REQ-0146 – Scener bytter ikke automatisk variant
Eksisterende scener skal ikke automatisk bytte til en nylig publisert variant.

- **Kilde:** Kap. 9.3 (l. 421) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 3
- **Moduler:** LIBRARY, VERSION · **Invarianter:** INV-07, INV-13
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Etter publisering av ny variant refererer eksisterende scener fortsatt til sin tidligere variant/versjon.
- **Tester:**
  - dataintegritet: scenereferanser uendret etter publisering
- **Implementering:** src/core/commands/apply.ts#AddAssetVersion
- **Merknad:** Krever versjonslåste ressursreferanser fra fase 3.

#### REQ-0147 – Gjenbrukbare stilprofiler
Programmet skal støtte gjenbrukbare visuelle stilprofiler med referansebilder og beskrivelser av stil.

- **Kilde:** Kap. 9.4 (l. 423) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** LIBRARY, PROMPT
- **Avhengigheter:** REQ-0121
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En stilprofil kan opprettes med referansebilder og tekstbeskrivelse og gjenbrukes.
- **Tester:**
  - integrasjon: CRUD stilprofil
- **Implementering:** src/core/generation/style.ts, db/migrations/0021_style_profiles.sql, src/app/projects/StyleGuideSection.tsx
- **Merknad:** Stilprofiler inngår i biblioteket (REQ-0121); fullt utnyttet ved generering i fase 5.

#### REQ-0148 – Stilprofil brukt på tvers av ressurstyper
En stilprofil skal kunne brukes på tvers av karakterer, miljøer, objekter, plakater, 2D-animatics og AI-generert video.

- **Kilde:** Kap. 9.4 (l. 424-430) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** LIBRARY, PROMPT, COMPOSE, PRESENT
- **Avhengigheter:** REQ-0147
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Samme stilprofil kan knyttes til hver av de seks typene.
- **Tester:**
  - integrasjon: stilprofil-tilknytning per type
- **Implementering:** src/core/generation/style.ts, src/app/projects/StyleGuideSection.tsx

#### REQ-0149 – Skille identitet, tilstand og stil
Systemet må skille mellom hvem karakteren er (identitet), hvordan karakteren ser ut i historien (utseendetilstand) og hvilken visuell stil karakteren fremstilles i (stilvariant/stilprofil).

- **Kilde:** Kap. 9.4 (l. 431) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** LIBRARY, CONTINUITY, CORE · **Invarianter:** INV-09
- **Avhengigheter:** REQ-0037
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Datamodellen har tre adskilte dimensjoner: karakter-ID, utseendetilstand og stilvariant, som kan kombineres fritt.
- **Tester:**
  - enhet: skjema for karakter × tilstand × stil
- **Implementering:** src/core/model.ts#Asset, src/core/model.ts#AssetVariant
- **Merknad:** Grunnleggende datamodellvalg; bør defineres i fase 1.

### Kapittel 10

#### REQ-0150 – Tidsstyrte utseendeendringer
Karakterer skal kunne endre utseende underveis i fortellingen, og systemet må forstå når forandringen skjer og hvilke referanser som gjelder før og etter.

- **Kilde:** Kap. 10 (l. 434-436) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 6
- **Moduler:** CONTINUITY · **Invarianter:** INV-09
- **Avhengigheter:** REQ-0149
- **Status:** Verifisert
- **Akseptansekriterier:**
  - For en karakter med registrert endring kan systemet for enhver scene svare hvilken referanse som gjelder.
- **Tester:**
  - enhet: tilstandsoppslag per scene
- **Implementering:** src/core/continuity/index.ts, src/core/commands/apply.ts (AddContinuityEvents, UpdateContinuityEvents, SetContinuityEventsRemoved), db/migrations/0015_continuity.sql, src/app/library/ContinuityPanel.tsx
- **Merknad:** Beskrevet som sentral funksjon; jf. kap. 34 pkt. 18. Datamodellen må støtte dette fra fase 1.

#### REQ-0151 – Registrering av kontinuitetshendelse
Programmet skal kunne registrere en kontinuitetshendelse med karakter (f.eks. Maja), hendelse (f.eks. klipper håret), utseende før hendelsen (langt hår), utseende etter hendelsen (kort hår), scene og manuspassasje der forandringen skjer, og om forandringen er permanent eller midlertidig.

- **Kilde:** Kap. 10.1 (l. 438-446) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** CONTINUITY · **Invarianter:** INV-02
- **Avhengigheter:** REQ-0150
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Hendelsen Maja klipper håret kan lagres med alle seks feltene.
- **Tester:**
  - enhet: kontinuitetshendelse-skjema
- **Implementering:** src/core/continuity/index.ts, src/core/commands/apply.ts (AddContinuityEvents, UpdateContinuityEvents, SetContinuityEventsRemoved), db/migrations/0015_continuity.sql, src/app/library/ContinuityPanel.tsx

#### REQ-0152 – Riktig referanse etter fortellingens kronologi
Fra punktet i fortellingens kronologi der forandringen skjer, skal riktig referanse brukes, og programmet må ikke feilaktig generere scener før hendelsen med utseendet etter hendelsen (f.eks. kort hår før hårklippingen).

- **Kilde:** Kap. 10.1 (l. 447-448) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 6
- **Moduler:** CONTINUITY, PROMPT · **Invarianter:** INV-09
- **Avhengigheter:** REQ-0151
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt hårklipp i scene 40, når scene 20 genereres, så brukes langt-hår-referansen; når scene 50 genereres, brukes kort-hår-referansen.
- **Tester:**
  - integrasjon: referansevalg før/etter hendelse
- **Implementering:** src/core/continuity/index.ts, src/core/commands/apply.ts (AddContinuityEvents, UpdateContinuityEvents, SetContinuityEventsRemoved), db/migrations/0015_continuity.sql

#### REQ-0153 – Støttede kontinuitetstyper
Systemet skal blant annet støtte kontinuitetstypene hårklipp og frisyre, hårfarge, kostymeskifte, skader og bandasjer, arr, skitt, snø og vann, skjeggvekst, aldring, objekter karakteren bærer og andre fysiske forandringer.

- **Kilde:** Kap. 10.2 (l. 450-461) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** CONTINUITY
- **Avhengigheter:** REQ-0151
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Hver av de 11 typene kan registreres (inkl. en generell «annen fysisk forandring»).
- **Tester:**
  - enhet: kontinuitetstype-enum/utvidbar liste
- **Implementering:** src/core/continuity/index.ts, src/core/commands/apply.ts (AddContinuityEvents, UpdateContinuityEvents, SetContinuityEventsRemoved), db/migrations/0015_continuity.sql, src/app/library/ContinuityPanel.tsx

#### REQ-0154 – Permanente, midlertidige og sceneavhengige tilstander
Systemet skal skille mellom permanente endringer, midlertidige tilstander og sceneavhengige varianter.

- **Kilde:** Kap. 10.2 (l. 462) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** CONTINUITY · **Invarianter:** INV-09
- **Avhengigheter:** REQ-0151
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En midlertidig tilstand (f.eks. våt) gjelder kun i angitt intervall; en permanent gjelder fra hendelsen og fremover.
- **Tester:**
  - enhet: gyldighetsregler per tilstandstype
- **Implementering:** src/core/continuity/index.ts, src/core/commands/apply.ts (AddContinuityEvents, UpdateContinuityEvents, SetContinuityEventsRemoved), db/migrations/0015_continuity.sql, src/app/library/ContinuityPanel.tsx

#### REQ-0155 – Visuell kontinuitetstidslinje per karakter
Hver karakter skal kunne ha en visuell kontinuitetstidslinje.

- **Kilde:** Kap. 10.3 (l. 464) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** CONTINUITY, UI · **Invarianter:** INV-09
- **Avhengigheter:** REQ-0151
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En karaktervisning viser utseendetilstander langs fortellingstiden med hendelsene markert.
- **Tester:**
  - visuell: kontinuitetstidslinje
- **Implementering:** src/core/continuity/index.ts, src/core/commands/apply.ts (AddContinuityEvents, UpdateContinuityEvents, SetContinuityEventsRemoved), db/migrations/0015_continuity.sql, src/app/library/ContinuityPanel.tsx

#### REQ-0156 – Kontinuitetshendelser knyttet til stabile ID-er
Kontinuitetshendelser skal knyttes til stabile sceneidentiteter og ved behov bestemte manusblokker eller tidsintervaller; scenenummer alene skal ikke brukes som referanse.

- **Kilde:** Kap. 10.3 (l. 465-466) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P0 · **Fase:** 6
- **Moduler:** CONTINUITY, CORE · **Invarianter:** INV-02
- **Avhengigheter:** REQ-0034; REQ-0094
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Omnummerering eller flytting av scener endrer ikke hvilken scene/blokk en hendelse er knyttet til.
- **Tester:**
  - dataintegritet: hendelse overlever omnummerering
- **Implementering:** src/core/continuity/index.ts, src/core/commands/apply.ts (AddContinuityEvents, UpdateContinuityEvents, SetContinuityEventsRemoved), db/migrations/0015_continuity.sql

#### REQ-0157 – Forslag til kontinuitetshendelser fra manus
Systemet skal kunne analysere manus og foreslå relevante kontinuitetshendelser (f.eks. foreslå en hendelse når manus beskriver at Maja klipper håret).

- **Kilde:** Kap. 10.4 (l. 468-469) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** CONTINUITY, SCRIPT, PROMPT
- **Avhengigheter:** REQ-0151
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en manuspassasje om hårklipp, så opprettes et forslag til kontinuitetshendelse.
- **Tester:**
  - integrasjon: analyse av fixtures med kjente hendelser
- **Implementering:** src/core/continuity/index.ts, src/core/commands/apply.ts (AddContinuityEvents, UpdateContinuityEvents, SetContinuityEventsRemoved), db/migrations/0015_continuity.sql, src/app/library/ContinuityPanel.tsx
- **Merknad:** Kan være AI-basert; analyse skal i så fall ikke være eneste vei (manuell registrering).

#### REQ-0158 – Brukeren godkjenner foreslått tolkning
Brukeren skal godkjenne tolkningen før en foreslått kontinuitetshendelse tas i bruk.

- **Kilde:** Kap. 10.4 (l. 470) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** CONTINUITY, UI · **Invarianter:** INV-08
- **Avhengigheter:** REQ-0157
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Foreslåtte hendelser påvirker ikke referansevalg før de er godkjent.
- **Tester:**
  - enhet: forslag ignoreres i referansevalg til godkjent
- **Implementering:** src/core/continuity/index.ts, src/core/commands/apply.ts (AddContinuityEvents, UpdateContinuityEvents, SetContinuityEventsRemoved), db/migrations/0015_continuity.sql, src/app/library/ContinuityPanel.tsx

#### REQ-0159 – Automatisk valg av karaktertilstand ved generering
Når «Generer scene» aktiveres, skal systemet automatisk velge relevante karaktertilstander ut fra fortellingens kronologi.

- **Kilde:** Kap. 10.5 (l. 472) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** CONTINUITY, PROMPT · **Invarianter:** INV-09
- **Avhengigheter:** REQ-0152
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Genereringsprompten for en scene inneholder referansene til gjeldende tilstand for hver karakter i scenen.
- **Tester:**
  - integrasjon: promptinnhold per scene
- **Implementering:** src/core/continuity/index.ts, src/core/commands/apply.ts (AddContinuityEvents, UpdateContinuityEvents, SetContinuityEventsRemoved), db/migrations/0015_continuity.sql, src/core/generation/scene-prompt.ts (describeAsset), src/app/assembly/GenerateSceneDialog.tsx

#### REQ-0160 – Riktig tilstand uavhengig av produksjonsrekkefølge
Automatisk valg av karaktertilstand skal fungere selv om scenene produseres i tilfeldig rekkefølge.

- **Kilde:** Kap. 10.5 (l. 473) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** CONTINUITY · **Invarianter:** INV-09
- **Avhengigheter:** REQ-0159
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Generering av scener i rekkefølgen 50, 10, 30 gir samme tilstandsvalg som i rekkefølgen 10, 30, 50.
- **Tester:**
  - enhet: referansevalg er rekkefølgeuavhengig
- **Implementering:** src/core/continuity/index.ts, src/core/commands/apply.ts (AddContinuityEvents, UpdateContinuityEvents, SetContinuityEventsRemoved), db/migrations/0015_continuity.sql

#### REQ-0161 – Forslag om produksjonssegmenter ved endring midt i scene
Hvis en forandring skjer midt i en scene, skal systemet kunne foreslå å dele produksjonen i et segment før endringen og et segment etter endringen.

- **Kilde:** Kap. 10.6 (l. 475-477) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** CONTINUITY, TIMELINE · **Invarianter:** INV-10
- **Avhengigheter:** REQ-0071; REQ-0156
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt hendelse knyttet til en manusblokk midt i en scene, så foreslås to segmenter delt ved den blokken.
- **Tester:**
  - integrasjon: segmentforslag
- **Implementering:** src/core/continuity/index.ts, src/core/commands/apply.ts (AddContinuityEvents, UpdateContinuityEvents, SetContinuityEventsRemoved), db/migrations/0015_continuity.sql, src/core/generation/scene-prompt.ts (planSegments, continuityCuts), src/app/assembly/GenerateSceneDialog.tsx
- **Merknad:** Jf. kap. 34 pkt. 19.

#### REQ-0162 – Segmenter får riktig karakterreferanse
Hvert produksjonssegment skal få riktig karakterreferanse.

- **Kilde:** Kap. 10.6 (l. 478) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** CONTINUITY, PROMPT · **Invarianter:** INV-09
- **Avhengigheter:** REQ-0161
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Segment før bruker langt-hår-referanse, segment etter bruker kort-hår-referanse.
- **Tester:**
  - integrasjon: referanse per segment
- **Implementering:** src/core/continuity/index.ts, src/core/commands/apply.ts (AddContinuityEvents, UpdateContinuityEvents, SetContinuityEventsRemoved), db/migrations/0015_continuity.sql, src/core/generation/scene-prompt.ts (buildScenePrompt)

#### REQ-0163 – Segmentering bevarer manusscene og nummerering
Oppdeling i produksjonssegmenter ved kontinuitetsendring skal ikke opprette nye manusscener eller endre scenenummereringen; den eksisterende manusscenen skal beholde sin identitet.

- **Kilde:** Kap. 10.6 (l. 479-481) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 6
- **Moduler:** CORE, CONTINUITY, SCRIPT · **Invarianter:** INV-10, INV-03
- **Avhengigheter:** REQ-0072
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Etter segmentering er antall manusscener, scenenumre og scene-ID uendret.
- **Tester:**
  - dataintegritet: manusstruktur før/etter segmentering
- **Implementering:** src/core/continuity/index.ts, src/core/commands/apply.ts (AddContinuityEvents, UpdateContinuityEvents, SetContinuityEventsRemoved), db/migrations/0015_continuity.sql, src/core/generation/scene-prompt.ts
- **Merknad:** Linje 479 og 480 er duplikater. Jf. kap. 34 pkt. 19.

#### REQ-0164 – Støtte for ikke-lineær fortelling
Systemet må støtte flashbacks, flashforwards, drømmer, tidshopp og ikke-kronologisk sceneorden.

- **Kilde:** Kap. 10.7 (l. 483-488) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** CONTINUITY, CORE · **Invarianter:** INV-09
- **Avhengigheter:** REQ-0165
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En scene kan merkes som flashback/flashforward/drøm/tidshopp og gis en fortellingstid som avviker fra visningsrekkefølgen.
- **Tester:**
  - enhet: fortellingstid-attributt
- **Implementering:** src/core/screenplay/story.ts, src/app/script/StoryTimeSection.tsx, src/core/commands/apply.ts#validStoryTime
- **Merknad:** Feltet for fortellingstid bør finnes i datamodellen fra fase 1.

#### REQ-0165 – Kontinuitet følger fortellingstid
Kontinuitet skal følge fortellingens faktiske hendelsestid, ikke bare rekkefølgen scenene vises eller produseres i.

- **Kilde:** Kap. 10.7 (l. 489) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 6
- **Moduler:** CONTINUITY · **Invarianter:** INV-09
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en flashback-scene plassert etter hårklippet i visningsrekkefølge men før i fortellingstid, så brukes langt hår.
- **Tester:**
  - integrasjon: flashback-scenario
- **Implementering:** src/core/continuity/index.ts, src/core/commands/apply.ts (AddContinuityEvents, UpdateContinuityEvents, SetContinuityEventsRemoved), db/migrations/0015_continuity.sql

#### REQ-0166 – Spinoffer gjenbruker kontinuitet med lokale avvik
Spinoffer skal kunne gjenbruke hovedfilmens kontinuitetsinformasjon, men også ha egne lokale avvik.

- **Kilde:** Kap. 10.8 (l. 491) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** CONTINUITY, CORE · **Invarianter:** INV-04
- **Avhengigheter:** REQ-0151
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En spinoff arver hovedfilmens kontinuitetshendelser og kan overstyre/fjerne enkelte lokalt.
- **Tester:**
  - integrasjon: arv og lokal overstyring
- **Implementering:** src/core/continuity/index.ts (continuityFor), src/core/commands/apply.ts (SetContinuityEventDisabled, ContinuityEvent.productionId), db/migrations/0018_spinoff_continuity.sql, src/app/library/ContinuityPanel.tsx

#### REQ-0167 – Spinoff-kontinuitet endrer ikke hovedfilmen
En alternativ spinoff (f.eks. der Maja ikke klipper håret) skal kunne beholde sin egen kontinuitet uten å endre hovedfilmen.

- **Kilde:** Kap. 10.8 (l. 492) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 7
- **Moduler:** CONTINUITY, CORE · **Invarianter:** INV-04
- **Avhengigheter:** REQ-0166
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Fjerning av hårklipp-hendelsen i spinoffen gir ingen endring i hovedfilmens kontinuitet.
- **Tester:**
  - dataintegritet: hovedfilmens kontinuitet uendret etter spinoff-endring
- **Implementering:** src/core/continuity/index.ts (continuityFor), src/core/commands/apply.ts (SetContinuityEventDisabled, ContinuityEvent.productionId), db/migrations/0018_spinoff_continuity.sql, src/app/library/ContinuityPanel.tsx

### Kapittel 11

#### REQ-0168 – Sceneeditor som sentral arbeidsflate
Sceneeditoren skal være en av applikasjonens viktigste arbeidsflater.

- **Kilde:** Kap. 11 (l. 494-495) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** COMPOSE, UI
- **Avhengigheter:** Informasjonsarkitektur (kap. 30.2)
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et åpent prosjekt, når brukeren velger en scene, så kan sceneeditoren åpnes direkte fra hovednavigasjonen og fra manus/tidslinje.
- **Tester:**
  - manuell: UX-gjennomgang av navigasjon til sceneeditor fra manus, tidslinje og oversikt
- **Implementering:** src/app/shell/ProjectNav.tsx, src/app/assembly/ClipPanel.tsx, src/app/projects/DurationOverview.tsx, src/app/shell/current-scene.ts, src/app/script/Inspector.tsx, src/app/scene-editor/SceneEditorWorkspace.tsx
- **Merknad:** Ingen automatisk test av navigasjonen, og manusvisningen har ingen direkte lenke til sceneeditoren.

#### REQ-0169 – 2D-editor, ikke 3D
Sceneeditoren skal være en 2D-editor, ikke en full 3D-sceneeditor.

- **Kilde:** Kap. 11 (l. 496) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P0 · **Fase:** 3
- **Moduler:** COMPOSE
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Scenemodellen representerer elementer som 2D-lag med dybdeordning/dybdeverdi, uten 3D-geometri, 3D-kamera med fri rotasjon i rommet eller 3D-modellimport.
- **Tester:**
  - enhet: datamodell for komposisjon inneholder kun 2D-transformasjoner pluss lagdybde
  - manuell: arkitekturgjennomgang
- **Implementering:** src/core/model.ts#CompositionLayer, src/core/composition/render.ts#viewMatrix
- **Merknad:** Ingen arkitekturtest håndhever at det ikke innføres 3D-geometri eller 3D-kamera.

#### REQ-0170 – Multiplan- og lagbasert visuell modell
Den visuelle modellen i sceneeditoren skal være inspirert av tradisjonelle multiplan-animasjonsrigger og lagbasert arbeid i programmer som After Effects.

- **Kilde:** Kap. 11 (l. 497) · **Opprinnelse:** mandat · **Type:** design · **Prioritet:** P0 · **Fase:** 3
- **Moduler:** COMPOSE, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Editoren presenterer scenen som en stabel av plan/lag med dybdeforhold, og lagene kan redigeres hver for seg på samme måte som i en lagbasert komposisjonseditor.
- **Tester:**
  - manuell: designgjennomgang mot multiplan-prinsippet
  - visuell: skjermbilde av lagstabel og dybdevisning
- **Implementering:** src/app/scene-editor/SceneEditorWorkspace.tsx, src/app/scene-editor/LayersPanel.tsx, src/core/composition/render.ts
- **Merknad:** Ufravikelig prinsipp nr. 10 i kap. 34.

#### REQ-0171 – Plassere bildeelementer i scenen
Brukeren skal kunne plassere følgende elementtyper i 2D-scenen: bakgrunner, mellomgrunner, forgrunner, karakterer, objekter, visuelle effekter og andre bildeelementer.

- **Kilde:** Kap. 11.1 (l. 498-506) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** COMPOSE, LIBRARY
- **Avhengigheter:** Ressursbibliotek (kap. 8)
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en tom 2D-scene, når brukeren legger til hver av elementtypene bakgrunn, mellomgrunn, forgrunn, karakter, objekt, visuell effekt og annet bildeelement, så vises de i scenen og lagres i prosjektdataene.
- **Tester:**
  - e2e: legg til ett element av hver type og verifiser at de vises og persisteres etter omlasting
- **Implementering:** src/core/composition/*, src/core/commands/apply.ts#applyCommand (CreateComposition, AddLayers, UpdateLayers, MoveLayer, SetLayersRemoved), db/migrations/0007_compositions.sql, src/app/scene-editor/*, src/engine/compositor/canvas.ts

#### REQ-0172 – Lag med definert dybdeforhold
Elementene i 2D-scenen skal kunne organiseres i lag med definert dybdeforhold.

- **Kilde:** Kap. 11.1 (l. 507) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 3
- **Moduler:** COMPOSE
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt flere elementer, når brukeren tildeler dem til lag med ulike dybdeverdier, så tegnes de i riktig rekkefølge og dybdeverdien lagres per lag.
- **Tester:**
  - enhet: sortering/tegnerekkefølge etter dybdeverdi
  - visuell: referansebilde av overlappende lag
- **Implementering:** src/core/composition/*, src/core/commands/apply.ts#applyCommand (CreateComposition, AddLayers, UpdateLayers, MoveLayer, SetLayersRemoved), db/migrations/0007_compositions.sql, src/app/scene-editor/*, src/engine/compositor/canvas.ts
- **Merknad:** Ufravikelig prinsipp nr. 10 (lagbasert) i kap. 34.

#### REQ-0173 – Parallakse og kamerabevegelse gjennom lag
Systemet skal støtte parallakseffekter og kontrollert kamerabevegelse gjennom lagene.

- **Kilde:** Kap. 11.1 (l. 508) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** COMPOSE, CAMERA
- **Avhengigheter:** REQ-0172
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt lag med ulik dybde, når kameraet panorerer, så forflytter nærere lag seg mer på skjermen enn fjernere lag i samsvar med dybdeverdien.
- **Tester:**
  - enhet: beregnet skjermforskyvning per lag som funksjon av dybde og kamerabevegelse
  - visuell: avspilling av panorering over tre lag
- **Implementering:** src/core/composition/*, src/core/commands/apply.ts#applyCommand (CreateComposition, AddLayers, UpdateLayers, MoveLayer, SetLayersRemoved), db/migrations/0007_compositions.sql, src/app/scene-editor/*, src/engine/compositor/canvas.ts, src/core/composition/animate.ts, src/core/composition/render.ts#renderFrame, cameraAt, valueAt, src/app/scene-editor/Timeline.tsx, src/app/scene-editor/Stage.tsx, src/app/scene-editor/camera-overlay.ts, src/app/scene-editor/CameraPanel.tsx, src/app/scene-editor/use-playback.ts

#### REQ-0174 – Redigerbare transformasjoner per element
Hvert element i 2D-scenen skal kunne ha redigerbare egenskaper som posisjon, skalering, rotasjon, transparens, synlighet, gruppering og lagrekkefølge.

- **Kilde:** Kap. 11.2 (l. 509-517) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** COMPOSE
- **Status:** Verifisert
- **Akseptansekriterier:**
  - For et valgt element kan brukeren endre posisjon, skalering, rotasjon, transparens, synlighet, gruppering og lagrekkefølge, og endringene vises umiddelbart og lagres.
- **Tester:**
  - enhet: transformasjonsmatrise og opasitet per element
  - e2e: endre hver egenskap og verifiser persistens og visning
- **Implementering:** src/core/composition/*, src/core/commands/apply.ts#applyCommand (CreateComposition, AddLayers, UpdateLayers, MoveLayer, SetLayersRemoved), db/migrations/0007_compositions.sql, src/app/scene-editor/*, src/engine/compositor/canvas.ts, src/core/composition/group.ts, src/app/scene-editor/LayersPanel.tsx (Ny gruppe), src/app/scene-editor/layer-actions.ts
- **Merknad:** Gruppering finnes i datamodellen, men er ikke tilgjengelig i brukergrensesnittet ennå (kommer senere). Posisjon, skalering, rotasjon, transparens, synlighet og lagrekkefølge er verifisert.

#### REQ-0175 – Maskering og komposisjonsfunksjoner
Elementer i 2D-scenen skal kunne ha eventuelle maskerings- og komposisjonsfunksjoner som er hensiktsmessige.

- **Kilde:** Kap. 11.2 (l. 518) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P3 · **Fase:** 3
- **Moduler:** COMPOSE
- **Avhengigheter:** REQ-0174
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt at maskering er implementert, når brukeren legger en maske på et element, så begrenses elementets synlige område til masken uten at kildebildet endres.
- **Tester:**
  - visuell: maske på lag gir forventet utsnitt
  - dataintegritet: kildebilde uendret etter maskering
- **Implementering:** src/core/composition/fields.ts, src/engine/compositor/canvas.ts, src/app/scene-editor/LayerMaskSection.tsx, src/core/composition/animate.ts, src/app/scene-editor/Stage.tsx
- **Merknad:** Modalitet «eventuelle … som er hensiktsmessige» – omfang ikke definert; skilt ut fra REQ-0174 for å bevare modaliteten.

#### REQ-0176 – Keyframe-animasjon av elementer
Elementer i 2D-scenen skal kunne animeres med keyframes (nøkkelbilder).

- **Kilde:** Kap. 11.3 (l. 519-520) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** COMPOSE
- **Avhengigheter:** REQ-0174
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et element med to keyframes for posisjon på ulike tidspunkter, når scenen spilles av, så interpoleres posisjonen mellom dem.
- **Tester:**
  - enhet: interpolering mellom keyframes
  - e2e: sett keyframes og spill av
- **Implementering:** src/core/composition/*, src/core/commands/apply.ts#applyCommand (CreateComposition, AddLayers, UpdateLayers, MoveLayer, SetLayersRemoved), db/migrations/0007_compositions.sql, src/core/composition/animate.ts, src/core/composition/render.ts#renderFrame, cameraAt, valueAt, src/app/scene-editor/Timeline.tsx, src/app/scene-editor/Stage.tsx, src/app/scene-editor/camera-overlay.ts, src/app/scene-editor/CameraPanel.tsx, src/app/scene-editor/use-playback.ts

#### REQ-0177 – Tidsstyrte endringer og hastighetskurver
Systemet skal støtte tidsstyrte endringer og justerbare hastighetskurver for animerte elementer.

- **Kilde:** Kap. 11.3 (l. 521) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** COMPOSE
- **Avhengigheter:** REQ-0176
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en animasjon mellom to keyframes, når brukeren endrer hastighetskurven (f.eks. lineær til ease-in-out), så endres interpoleringen tilsvarende ved avspilling.
- **Tester:**
  - enhet: kurveevaluering for lineær og bézier-baserte hastighetskurver
  - visuell: sammenligning av bevegelse før og etter kurveendring
- **Implementering:** src/core/composition/*, src/core/commands/apply.ts#applyCommand (CreateComposition, AddLayers, UpdateLayers, MoveLayer, SetLayersRemoved), db/migrations/0007_compositions.sql, src/core/composition/animate.ts, src/core/composition/render.ts#renderFrame, cameraAt, valueAt, src/app/scene-editor/Timeline.tsx, src/app/scene-editor/Stage.tsx, src/app/scene-editor/camera-overlay.ts, src/app/scene-editor/CameraPanel.tsx, src/app/scene-editor/use-playback.ts

#### REQ-0178 – Enkel animatic uten generativ AI
Brukeren skal kunne produsere en enkel animatic med stillbilder, objekter og bevegelse uten å bruke generativ AI.

- **Kilde:** Kap. 11.3 (l. 522) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 3
- **Moduler:** COMPOSE, CAMERA · **Invarianter:** INV-11
- **Avhengigheter:** REQ-0176
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt at alle AI-leverandører er frakoblet, når brukeren bygger en scene med stillbilder, objekter og keyframe-bevegelse, så kan scenen spilles av fullt ut.
- **Tester:**
  - e2e: bygg og spill av animatic med AI-integrasjoner deaktivert og nettverkskall til AI-leverandører blokkert
- **Implementering:** src/core/composition/animate.ts, src/core/composition/render.ts#renderFrame, cameraAt, valueAt, src/app/scene-editor/Timeline.tsx, src/app/scene-editor/Stage.tsx, src/app/scene-editor/camera-overlay.ts, src/app/scene-editor/CameraPanel.tsx, src/app/scene-editor/use-playback.ts
- **Merknad:** Ufravikelig prinsipp nr. 9 i kap. 34.

#### REQ-0179 – 2D-scenen bevares som redigerbare data
Alle lag, objekter, bevegelser og kamerainnstillinger skal bevares som redigerbare prosjektdata.

- **Kilde:** Kap. 11.4 (l. 523-524) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** COMPOSE, CAMERA, CORE · **Invarianter:** INV-13
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en lagret scene, når prosjektet lukkes og åpnes igjen, så er alle lag, objekter, keyframes og kamerainnstillinger fortsatt redigerbare (ikke bakt inn i en ferdig fil).
- **Tester:**
  - dataintegritet: rundtur lagre/laste av komposisjon gir identisk datastruktur
  - e2e: rediger et lag etter omlasting
- **Implementering:** src/core/composition/*, src/core/commands/apply.ts#applyCommand (CreateComposition, AddLayers, UpdateLayers, MoveLayer, SetLayersRemoved), db/migrations/0007_compositions.sql, src/app/scene-editor/*, src/engine/compositor/canvas.ts

#### REQ-0180 – AI-video overskriver ikke 2D-scenen
En AI-generert videofil skal ikke erstatte eller overskrive den underliggende 2D-scenen.

- **Kilde:** Kap. 11.4 (l. 525) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 5
- **Moduler:** COMPOSE, VERSION, PROVIDER · **Invarianter:** INV-07, INV-11
- **Avhengigheter:** REQ-0179
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en 2D-scene, når en AI-generert video for scenen mottas og aktiveres, så finnes 2D-komposisjonen fortsatt uendret og kan redigeres og spilles av.
- **Tester:**
  - dataintegritet: hash av 2D-scenedata før og etter AI-generering er lik
  - integrasjon: aktivering av AI-video lager ny versjon ved siden av 2D-kilden
- **Implementering:** src/app/ai/video-jobs.ts, src/app/assembly/SceneVideoSection.tsx
- **Merknad:** Kobles til ufravikelig prinsipp nr. 27 i kap. 34.

### Kapittel 12

#### REQ-0181 – Kamera som redigerbart sceneelement
Kameraet skal være et sentralt, visuelt redigerbart element i 2D-scenen.

- **Kilde:** Kap. 12 (l. 527-528) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** CAMERA, COMPOSE
- **Status:** Verifisert
- **Akseptansekriterier:**
  - I sceneeditoren vises kameraet som et eget objekt som kan velges og flyttes/endres direkte i arbeidsflaten.
- **Tester:**
  - e2e: velg og flytt kamera i arbeidsflaten
- **Implementering:** src/app/scene-editor/camera-overlay.ts, src/app/scene-editor/CameraPanel.tsx, src/app/scene-editor/Stage.tsx

#### REQ-0182 – Kamerautsnitt fra filmformat og sideforhold
Kameraet skal ha et definert utsnitt basert på valgt filmformat og sideforhold.

- **Kilde:** Kap. 12.1 (l. 529-530) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** CAMERA
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt valgt sideforhold (f.eks. 2.39:1 eller 16:9), så har kamerautsnittet nøyaktig dette sideforholdet, og eksportert bilde tilsvarer utsnittet.
- **Tester:**
  - enhet: beregning av utsnittsdimensjoner per format
  - visuell: eksportert ramme samsvarer med kamerautsnitt
- **Implementering:** src/core/composition/*, src/core/commands/apply.ts#applyCommand (CreateComposition, AddLayers, UpdateLayers, MoveLayer, SetLayersRemoved), db/migrations/0007_compositions.sql, src/core/composition/animate.ts, src/core/composition/render.ts#renderFrame, cameraAt, valueAt, src/app/scene-editor/Timeline.tsx, src/app/scene-editor/Stage.tsx, src/app/scene-editor/camera-overlay.ts, src/app/scene-editor/CameraPanel.tsx, src/app/scene-editor/use-playback.ts

#### REQ-0183 – Støtte for ulike bildeformater
Brukeren skal kunne arbeide med ulike relevante bildeformater.

- **Kilde:** Kap. 12.1 (l. 531) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** CAMERA, CORE
- **Avhengigheter:** REQ-0182
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan velge mellom flere forhåndsdefinerte bildeformater/sideforhold (og evt. egendefinert), og valget lagres i prosjektet/produksjonen.
- **Tester:**
  - enhet: formatkatalog og validering
  - e2e: bytt format og verifiser kamerautsnitt
- **Implementering:** src/core/composition/* (COMPOSITION_FORMATS), src/app/scene-editor/*, src/engine/compositor/canvas.ts
- **Merknad:** Format velges per 2D-scene, ved opprettelse og i sceneinspektøren.

#### REQ-0184 – Vise kameraets start- og sluttramme
I editoren skal kameraets start- og sluttramme kunne vises som tydelige, tynne konturer.

- **Kilde:** Kap. 12.2 (l. 532-533) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** CAMERA, UI
- **Avhengigheter:** REQ-0182
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et kamera med bevegelse, så vises rammen ved start og rammen ved slutt samtidig som konturer i arbeidsflaten, og visningen kan slås på.
- **Tester:**
  - visuell: skjermbilde av editor med start- og sluttramme
- **Implementering:** src/core/composition/animate.ts, src/core/composition/render.ts#renderFrame, cameraAt, valueAt, src/app/scene-editor/Timeline.tsx, src/app/scene-editor/Stage.tsx, src/app/scene-editor/camera-overlay.ts, src/app/scene-editor/CameraPanel.tsx, src/app/scene-editor/use-playback.ts

#### REQ-0185 – Blå startramme, rød sluttramme
Kameraets startramme skal vises med blå kontur (kameraposisjon ved start) og sluttrammen med rød kontur (kameraposisjon ved slutt).

- **Kilde:** Kap. 12.2 (l. 534-536) · **Opprinnelse:** mandat · **Type:** design · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** CAMERA, UI
- **Avhengigheter:** REQ-0184
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Startrammen tegnes blå og sluttrammen rød i arbeidsflaten.
- **Tester:**
  - visuell: pikselsjekk av farge på start- og sluttramme
- **Implementering:** src/core/composition/animate.ts, src/core/composition/render.ts#renderFrame, cameraAt, valueAt, src/app/scene-editor/Timeline.tsx, src/app/scene-editor/Stage.tsx, src/app/scene-editor/camera-overlay.ts, src/app/scene-editor/CameraPanel.tsx, src/app/scene-editor/use-playback.ts
- **Merknad:** Formulert som «den ønskede visuelle konvensjonen».

#### REQ-0186 – Rammekonturer omtrent 1 piksel
Konturene for kameraets start- og sluttramme skal være omtrent 1 piksel tykke.

- **Kilde:** Kap. 12.2 (l. 537) · **Opprinnelse:** mandat · **Type:** design · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** CAMERA, UI
- **Avhengigheter:** REQ-0184
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Rammekonturene tegnes med ca. 1 piksels linjebredde uavhengig av zoomnivå i editoren.
- **Tester:**
  - visuell: mål linjebredde ved ulike zoomnivåer
- **Implementering:** src/core/composition/animate.ts, src/core/composition/render.ts#renderFrame, cameraAt, valueAt, src/app/scene-editor/Timeline.tsx, src/app/scene-editor/Stage.tsx, src/app/scene-editor/camera-overlay.ts, src/app/scene-editor/CameraPanel.tsx, src/app/scene-editor/use-playback.ts

#### REQ-0187 – Kamerarammer utelates fra eksport
Kameraets start- og sluttrammer er redigeringshjelpemidler og skal ikke inngå i eksportert film.

- **Kilde:** Kap. 12.2 (l. 538) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** CAMERA, EXPORT
- **Avhengigheter:** REQ-0184
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt at rammene er synlige i editoren, når scenen eksporteres eller forhåndsvises i avspillingsmodus, så finnes ingen blå/røde rammekonturer i bildet.
- **Tester:**
  - visuell: eksportert bilde inneholder ikke rammekonturer
  - integrasjon: renderer ignorerer redigeringshjelpemidler
- **Implementering:** src/core/composition/animate.ts, src/core/composition/render.ts#renderFrame, cameraAt, valueAt, src/app/scene-editor/Timeline.tsx, src/app/scene-editor/Stage.tsx, src/app/scene-editor/camera-overlay.ts, src/app/scene-editor/CameraPanel.tsx, src/app/scene-editor/use-playback.ts

#### REQ-0188 – Kamerabevegelse via redigerbare baner
Kamerabevegelse skal kunne styres med redigerbare baner.

- **Kilde:** Kap. 12.3 (l. 539-540) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** CAMERA
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et kamera, når brukeren definerer en bane med flere punkter, så følger kameraet banen ved avspilling, og banen kan endres i etterkant.
- **Tester:**
  - enhet: posisjon langs bane som funksjon av tid
  - e2e: tegn og endre bane
- **Implementering:** src/core/composition/animate.ts, src/core/composition/render.ts#renderFrame, cameraAt, valueAt, src/app/scene-editor/Timeline.tsx, src/app/scene-editor/Stage.tsx, src/app/scene-editor/camera-overlay.ts, src/app/scene-editor/CameraPanel.tsx, src/app/scene-editor/use-playback.ts

#### REQ-0189 – Rette, kurvede og Bézier-baner
Kamerabanene skal støtte rette baner, kurvede baner og Bézier-kurver med redigerbare håndtak og kontrollpunkter.

- **Kilde:** Kap. 12.3 (l. 541-545) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** CAMERA
- **Avhengigheter:** REQ-0188
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan lage en rett bane, en kurvet bane og en Bézier-bane, og flytte kontrollpunkter og håndtak slik at banen endres tilsvarende.
- **Tester:**
  - enhet: Bézier-evaluering og håndtaksoppdatering
  - visuell: bane tegnes i samsvar med kontrollpunkter
- **Implementering:** src/core/composition/animate.ts, src/core/composition/render.ts#renderFrame, cameraAt, valueAt, src/app/scene-editor/Timeline.tsx, src/app/scene-editor/Stage.tsx, src/app/scene-editor/camera-overlay.ts, src/app/scene-editor/CameraPanel.tsx, src/app/scene-editor/use-playback.ts

#### REQ-0190 – Direkte visuell manipulering av baner
Kamerabaner skal kunne manipuleres visuelt direkte i arbeidsflaten.

- **Kilde:** Kap. 12.3 (l. 546) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** CAMERA, UI
- **Avhengigheter:** REQ-0189
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan dra banepunkter og håndtak direkte på lerretet uten å bruke numeriske felt.
- **Tester:**
  - e2e: dra-og-slipp av banepunkt endrer banedata
- **Implementering:** src/core/composition/animate.ts, src/core/composition/render.ts#renderFrame, cameraAt, valueAt, src/app/scene-editor/Timeline.tsx, src/app/scene-editor/Stage.tsx, src/app/scene-editor/camera-overlay.ts, src/app/scene-editor/CameraPanel.tsx, src/app/scene-editor/use-playback.ts

#### REQ-0191 – Dobbeltklikk veksler rett/kurvet
Dobbeltklikk på et relevant banepunkt eller segment skal kunne brukes til å veksle mellom rett og kurvet bevegelse, dersom det lar seg implementere på en intuitiv og konsistent måte.

- **Kilde:** Kap. 12.3 (l. 547) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P3 · **Fase:** 3
- **Moduler:** CAMERA, UI
- **Avhengigheter:** REQ-0189
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt at funksjonen er implementert, når brukeren dobbeltklikker på et banesegment eller -punkt, så veksler segmentet mellom rett og kurvet, og handlingen kan angres.
- **Tester:**
  - e2e: dobbeltklikk veksler segmenttype
  - manuell: brukertest av intuitivitet
- **Implementering:** src/core/composition/animate.ts, src/core/composition/render.ts#renderFrame, cameraAt, valueAt, src/app/scene-editor/Timeline.tsx, src/app/scene-editor/Stage.tsx, src/app/scene-editor/camera-overlay.ts, src/app/scene-editor/CameraPanel.tsx, src/app/scene-editor/use-playback.ts
- **Merknad:** Betinget krav («dersom det lar seg implementere …»).

#### REQ-0192 – Kamerabevegelsestyper
Kameraet skal støtte blant annet panorering, zoom, tilt, rotasjon og posisjonsbevegelse.

- **Kilde:** Kap. 12.4 (l. 548-554) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** CAMERA
- **Avhengigheter:** REQ-0188
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Hver av bevegelsene panorering, zoom, tilt, rotasjon og posisjonsbevegelse kan animeres og gir forventet resultat ved avspilling.
- **Tester:**
  - enhet: kameratransformasjon for hver bevegelsestype
  - visuell: avspilling av hver bevegelsestype
- **Implementering:** src/core/composition/animate.ts, src/core/composition/render.ts#renderFrame, cameraAt, valueAt, src/app/scene-editor/Timeline.tsx, src/app/scene-editor/Stage.tsx, src/app/scene-editor/camera-overlay.ts, src/app/scene-editor/CameraPanel.tsx, src/app/scene-editor/use-playback.ts
- **Merknad:** «Tilt» i en 2D-editor er ikke definert (vertikal panorering vs. perspektivsimulering) – se OPEN_QUESTIONS B («Tilt» i 2D).

#### REQ-0193 – Flere kamerautsnitt og shots per scene
Kameraet skal støtte flere kamerautsnitt og shots i samme scene.

- **Kilde:** Kap. 12.4 (l. 555) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** CAMERA, TIMELINE · **Invarianter:** INV-10
- **Avhengigheter:** REQ-0182
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt én manusscene, når brukeren oppretter flere shots med ulike kamerautsnitt, så spilles de av i rekkefølge innen scenen, uten at det opprettes nye manusscener.
- **Tester:**
  - enhet: shot-liste per scene
  - e2e: opprett tre shots og spill av
- **Implementering:** src/core/composition/*, src/core/commands/apply.ts#applyCommand (CreateComposition, AddLayers, UpdateLayers, MoveLayer, SetLayersRemoved), db/migrations/0007_compositions.sql, src/core/composition/animate.ts, src/core/composition/render.ts#renderFrame, cameraAt, valueAt, src/app/scene-editor/Timeline.tsx, src/app/scene-editor/Stage.tsx, src/app/scene-editor/camera-overlay.ts, src/app/scene-editor/CameraPanel.tsx, src/app/scene-editor/use-playback.ts

#### REQ-0194 – Kamerabevegelse kombinert med elementanimasjon
Det skal være mulig å kombinere kamerabevegelse med separat animasjon av sceneelementer.

- **Kilde:** Kap. 12.4 (l. 556) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** CAMERA, COMPOSE
- **Avhengigheter:** REQ-0176; REQ-0188
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et element animert med keyframes og et kamera som beveger seg, så spilles begge animasjonene samtidig og uavhengig av hverandre.
- **Tester:**
  - visuell: samtidig kamera- og elementanimasjon
  - enhet: separate animasjonskanaler for kamera og elementer
- **Implementering:** src/core/composition/animate.ts, src/core/composition/render.ts#renderFrame, cameraAt, valueAt, src/app/scene-editor/Timeline.tsx, src/app/scene-editor/Stage.tsx, src/app/scene-editor/camera-overlay.ts, src/app/scene-editor/CameraPanel.tsx, src/app/scene-editor/use-playback.ts

#### REQ-0195 – Kamera synkronisert med scenetidslinje
Kamerabevegelsene skal være synkronisert med scenens tidslinje.

- **Kilde:** Kap. 12.5 (l. 557-558) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** CAMERA, TIMELINE
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Når avspillingshodet flyttes til et tidspunkt i scenen, så viser kameraet posisjonen som tilsvarer dette tidspunktet.
- **Tester:**
  - enhet: kameratilstand som funksjon av scenetid
  - e2e: skrubbing gir korrekt kameraposisjon
- **Implementering:** src/core/composition/animate.ts, src/core/composition/render.ts#renderFrame, cameraAt, valueAt, src/app/scene-editor/Timeline.tsx, src/app/scene-editor/Stage.tsx, src/app/scene-editor/camera-overlay.ts, src/app/scene-editor/CameraPanel.tsx, src/app/scene-editor/use-playback.ts

#### REQ-0196 – Kamera-keyframes, egenskapskanaler og easing
Kameraanimasjon skal støtte nøkkelbilder, separat animasjonsstyring for ulike egenskaper, hastighetskurver og easing.

- **Kilde:** Kap. 12.5 (l. 559-563) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** CAMERA
- **Avhengigheter:** REQ-0195
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan sette keyframes for f.eks. posisjon og zoom uavhengig av hverandre, og velge hastighetskurve/easing for hver.
- **Tester:**
  - enhet: separate keyframe-kanaler per kameraegenskap
  - enhet: easing-funksjoner
- **Implementering:** src/core/composition/*, src/core/commands/apply.ts#applyCommand (CreateComposition, AddLayers, UpdateLayers, MoveLayer, SetLayersRemoved), db/migrations/0007_compositions.sql, src/core/composition/animate.ts, src/core/composition/render.ts#renderFrame, cameraAt, valueAt, src/app/scene-editor/Timeline.tsx, src/app/scene-editor/Stage.tsx, src/app/scene-editor/camera-overlay.ts, src/app/scene-editor/CameraPanel.tsx, src/app/scene-editor/use-playback.ts

#### REQ-0197 – Visuell forhåndsvisning av kamerabevegelse
Systemet skal støtte visuell forhåndsvisning av kamerabevegelser.

- **Kilde:** Kap. 12.5 (l. 564) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** CAMERA, COMPOSE
- **Avhengigheter:** REQ-0195
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan spille av kamerabevegelsen i editoren og se resultatet gjennom kamerautsnittet.
- **Tester:**
  - e2e: forhåndsvisning av kamerabevegelse
- **Implementering:** src/core/composition/animate.ts, src/core/composition/render.ts#renderFrame, cameraAt, valueAt, src/app/scene-editor/Timeline.tsx, src/app/scene-editor/Stage.tsx, src/app/scene-editor/camera-overlay.ts, src/app/scene-editor/CameraPanel.tsx, src/app/scene-editor/use-playback.ts

#### REQ-0198 – Justere varighet på bevegelser
Brukeren skal kunne justere varigheten av kamerabevegelsene.

- **Kilde:** Kap. 12.5 (l. 565) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** CAMERA
- **Avhengigheter:** REQ-0195
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en kamerabevegelse på 4 s, når brukeren endrer varigheten til 6 s, så skaleres bevegelsen til 6 s ved avspilling.
- **Tester:**
  - enhet: tidsskalering av keyframes
- **Implementering:** src/core/composition/animate.ts, src/core/composition/render.ts#renderFrame, cameraAt, valueAt, src/app/scene-editor/Timeline.tsx, src/app/scene-editor/Stage.tsx, src/app/scene-editor/camera-overlay.ts, src/app/scene-editor/CameraPanel.tsx, src/app/scene-editor/use-playback.ts

### Kapittel 13

#### REQ-0199 – Strukturert lydsystem
Animatic Studio skal ha et strukturert lydsystem.

- **Kilde:** Kap. 13 (l. 567-568) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** AUDIO
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Lyd modelleres som egne ressurser og spor i prosjektmodellen, med typer, koblinger og versjoner (jf. 13.1–13.3).
- **Tester:**
  - manuell: arkitekturgjennomgang av lydmodell
- **Implementering:** src/core/audio/index.ts, src/app/assembly/AudioTracks.tsx

#### REQ-0200 – Skille mellom lydtyper
Systemet skal skille mellom lydtypene dialog, fortellerstemme, lydeffekter, atmosfære og bakgrunnslyd, og musikk.

- **Kilde:** Kap. 13.1 (l. 569-575) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** AUDIO
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Hver lydressurs har en av typene dialog, fortellerstemme, lydeffekt, atmosfære/bakgrunn eller musikk, og typen kan brukes til filtrering og sporplassering.
- **Tester:**
  - enhet: lydtype-enum og validering
- **Implementering:** src/core/audio/index.ts

#### REQ-0201 – Lyd på separate spor
Lydene skal kunne plasseres på separate spor.

- **Kilde:** Kap. 13.1 (l. 576) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** AUDIO, TIMELINE
- **Avhengigheter:** REQ-0200
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan plassere dialog, musikk og effekter på separate spor som kan justeres hver for seg.
- **Tester:**
  - e2e: plasser lyd på tre spor og spill av
- **Implementering:** src/app/assembly/AudioTracks.tsx

#### REQ-0202 – Laste opp lyd
Brukeren skal kunne laste opp lyd.

- **Kilde:** Kap. 13.2 (l. 577-578) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** AUDIO, LIBRARY
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan laste opp vanlige lydformater (f.eks. WAV, MP3), og filen blir en lydressurs i biblioteket.
- **Tester:**
  - import/eksport: opplasting av WAV og MP3
- **Implementering:** src/app/library/asset-audio.ts, src/app/assembly/AddAudioDialog.tsx

#### REQ-0203 – Generere lyd
Brukeren skal kunne generere lyd.

- **Kilde:** Kap. 13.2 (l. 578) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** AUDIO, PROVIDER · **Invarianter:** INV-12
- **Avhengigheter:** REQ-0269
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en tilkoblet lydleverandør, når brukeren ber om generering og godkjenner kostnad, så lagres resultatet som lydressurs med sporbarhet.
- **Tester:**
  - integrasjon: lydgenerering via adapter med mock-leverandør
- **Implementering:** src/adapters/ai/sound.functions.ts, src/app/library/GenerateSoundPanel.tsx, src/adapters/ai/speech.functions.ts, src/app/assembly/AiDialogueDialog.tsx, src/core/generation/speech.ts
- **Merknad:** Ikke presisert om «generere» betyr AI-generering (TTS, musikk, effekter) – antatt AI, derfor fase 5.

#### REQ-0204 – Koble lydfiler til produksjonsobjekter
Lydfiler skal kunne knyttes til karakterer, replikker, scener, delsekvenser, hendelser og produksjoner.

- **Kilde:** Kap. 13.2 (l. 579-585) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** AUDIO, CORE
- **Avhengigheter:** Permanente identiteter (kap. 3.2)
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En lydfil kan kobles til hver av objekttypene karakter, replikk, scene, delsekvens, hendelse og produksjon via deres permanente ID-er.
- **Tester:**
  - enhet: relasjonsmodell lyd–objekt
  - dataintegritet: koblinger overlever omnummerering av scener
- **Implementering:** src/core/commands/apply.ts, db/migrations/0009_audio.sql, src/core/library/sound-links.ts, src/app/library/SoundLinksSection.tsx, db/migrations/0025_ai_queue.sql

#### REQ-0205 – Organisere, søke, filtrere og versjonere lyd
Programmet skal støtte organisering, søk, filtrering og versjonering av lyd.

- **Kilde:** Kap. 13.2 (l. 586) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** AUDIO, LIBRARY, VERSION · **Invarianter:** INV-13
- **Avhengigheter:** REQ-0202
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan søke og filtrere lyd på navn, type og kobling, og en ny versjon av en lydressurs bevarer tidligere versjoner.
- **Tester:**
  - enhet: søk/filter på lydmetadata
  - dataintegritet: versjonering bevarer tidligere lydfil
- **Implementering:** src/app/library/AssetDetail.tsx, src/app/library/LibraryWorkspace.tsx, src/core/library/sound-links.ts

#### REQ-0206 – Dialoglyd synkronisert med manus
Dialoglyd skal kunne synkroniseres med manusblokker og visuelle hendelser.

- **Kilde:** Kap. 13.3 (l. 587-588) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** AUDIO, SCRIPT, TIMELINE
- **Avhengigheter:** Manusblokker med tidskoblinger (kap. 6.1)
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en replikk med tilknyttet dialogopptak, når opptaket plasseres på tidslinjen, så er replikken og opptaket koblet slik at klikk på replikken finner opptaket.
- **Tester:**
  - integrasjon: replikk–lyd–tidskobling
- **Implementering:** src/app/assembly/AudioClipPanel.tsx, src/core/assembly/film.ts#blockSpans, src/app/assembly/ClipPanel.tsx, src/app/assembly/AiDialogueDialog.tsx
- **Merknad:** Ingen automatisk test av at klikk på replikken finner opptaket.

#### REQ-0207 – Justere lydklipp
Brukeren skal kunne justere plassering, varighet, klipp og relevante lydinnstillinger.

- **Kilde:** Kap. 13.3 (l. 589) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** AUDIO, TIMELINE
- **Avhengigheter:** REQ-0201
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan flytte et lydklipp, trimme det, endre varighet og justere f.eks. volum/fade, ikke-destruktivt.
- **Tester:**
  - e2e: flytt, trim og volumendring
  - dataintegritet: kildelydfil uendret
- **Implementering:** src/app/assembly/AudioTracks.tsx, src/app/assembly/AudioClipPanel.tsx, src/engine/audio/mixer.ts
- **Merknad:** «Relevante lydinnstillinger» er ikke spesifisert.

#### REQ-0208 – Lyd i avspilling og eksport
Lyden skal være del av både lokal animatic-avspilling og endelig eksport.

- **Kilde:** Kap. 13.3 (l. 590) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** AUDIO, EXPORT · **Invarianter:** INV-11
- **Avhengigheter:** REQ-0201
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Lyd høres ved lokal avspilling og finnes i eksportert filmfil med korrekt timing.
- **Tester:**
  - import/eksport: eksportert fil har lydspor med korrekt offset
  - e2e: lokal avspilling med lyd
- **Implementering:** src/app/audio/use-audio-playback.ts, src/engine/export/animatic.ts

### Kapittel 14

#### REQ-0209 – Komplette animatics uten ekstern AI
Animatic Studio skal kunne produsere komplette animatics fra 2D-sceneeditoren uten at innholdet må sendes til en ekstern AI-modell.

- **Kilde:** Kap. 14 (l. 592-593) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 3
- **Moduler:** COMPOSE, TIMELINE, EXPORT · **Invarianter:** INV-11
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt at ingen AI-leverandør er konfigurert, så kan en komplett animatic bygges, spilles av og eksporteres.
- **Tester:**
  - e2e: full animatic-flyt med nettverk mot AI-leverandører blokkert
- **Implementering:** src/core/composition/render.ts, src/engine/compositor/film.ts, src/engine/export/animatic.ts, src/app/scene-editor/SceneEditorWorkspace.tsx
- **Merknad:** Ufravikelig prinsipp nr. 9 i kap. 34.

#### REQ-0210 – Direkte forhåndsvisning av animatic
Programmet skal kunne spille av lagbaserte komposisjoner, kamerabevegelser, objektanimasjon, karakterbevegelser, dialog, lydeffekter og musikk.

- **Kilde:** Kap. 14.1 (l. 594-602) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** COMPOSE, CAMERA, AUDIO · **Invarianter:** INV-11
- **Avhengigheter:** REQ-0176; REQ-0188; REQ-0201
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en scene med lag, kamerabevegelse, objekt- og karakteranimasjon, dialog, effekter og musikk, så spilles alt av synkront i forhåndsvisningen.
- **Tester:**
  - e2e: avspilling av sammensatt testscene
  - visuell: bilde/lyd-synk ved definerte tidspunkter
- **Implementering:** src/core/composition/animate.ts, src/core/composition/render.ts#renderFrame, cameraAt, valueAt, src/app/scene-editor/Timeline.tsx, src/app/scene-editor/Stage.tsx, src/app/scene-editor/camera-overlay.ts, src/app/scene-editor/CameraPanel.tsx, src/app/scene-editor/use-playback.ts
- **Merknad:** Lyddelene avhenger av fase 4. «Karakterbevegelser» er ikke nærmere definert (rigging/cut-out?). Avspilling av lag og kamera finnes (DEC-0036).

#### REQ-0211 – Rendre og eksportere 2D-animatics
Programmet skal kunne rendre og eksportere 2D-animatics ved hjelp av applikasjonens egen animasjons- og mediepipeline.

- **Kilde:** Kap. 14.2 (l. 603-604) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 4
- **Moduler:** EXPORT, COMPOSE, QUEUE · **Invarianter:** INV-11
- **Avhengigheter:** REQ-0210
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en 2D-animatic, når brukeren eksporterer, så produseres en videofil med bilde og lyd uten bruk av eksterne AI-tjenester.
- **Tester:**
  - import/eksport: eksportert video har forventet varighet, oppløsning og bildefrekvens
- **Implementering:** src/engine/export/animatic.ts, src/engine/export/animatic.ts
- **Merknad:** Ufravikelig prinsipp nr. 9 i kap. 34.

#### REQ-0212 – Renderer i klient, backend eller desktop
Rendering/eksport av 2D-animatics kan teknisk utføres i klienten, via egen backend-renderer eller i en fremtidig desktop-applikasjon.

- **Kilde:** Kap. 14.2 (l. 605) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** EXPORT, COMPOSE, QUEUE
- **Avhengigheter:** Portabilitet (kap. 1.2)
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Renderingslogikken er skilt fra UI og har et grensesnitt som kan kjøres både i nettleser og i en backend-tjeneste.
- **Tester:**
  - manuell: arkitekturgjennomgang av renderer-grensesnitt
  - integrasjon: samme testscene rendres likt i klient- og backend-modus (når begge finnes)
- **Implementering:** src/core/composition/render.ts, src/engine/compositor/canvas.ts, src/engine/compositor/film.ts, docs/decisions/adr/ADR-0008-rendering.md
- **Merknad:** Mandatet bruker «kan» – en åpning, ikke krav om alle tre. At arkitekturen ikke skal låse seg følger av kap. 1.2 (REQ-0506).

#### REQ-0213 – Eksport uten AI eller betalte API-kall
Rendering og eksport av 2D-animatics skal ikke kreve generativ AI eller betalte AI-API-kall.

- **Kilde:** Kap. 14.2 (l. 606) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 4
- **Moduler:** EXPORT, COMPOSE · **Invarianter:** INV-11, INV-12
- **Avhengigheter:** REQ-0211
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Eksport av en 2D-animatic gjennomføres uten noen kall til AI-leverandører og uten kostnadsregistrering.
- **Tester:**
  - integrasjon: overvåk utgående kall under eksport – ingen AI-API-kall
- **Implementering:** src/engine/export/animatic.ts

#### REQ-0214 – Hybrid filmmontering
Den samme filmmonteringen skal kunne kombinere redigerbare 2D-animatics, AI-genererte videoklipp, importert ferdig film, stillbilder med definert varighet og lyd fra ulike kilder.

- **Kilde:** Kap. 14.3 (l. 607-613) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** TIMELINE, EXPORT, AUDIO
- **Avhengigheter:** REQ-0216; REQ-0235
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en montering med én 2D-scene, ett AI-klipp, ett importert filmklipp og ett stillbilde med 3 s varighet pluss lyd fra flere kilder, så spilles og eksporteres alt som én film.
- **Tester:**
  - e2e: hybrid montering avspilling og eksport
  - import/eksport: varighet = sum av elementer
- **Implementering:** src/engine/compositor/film.ts, src/engine/export/animatic.ts, src/core/generation/video.ts, src/app/assembly/StillPickerDialog.tsx, src/core/assembly/edit.ts

#### REQ-0215 – AI som valgfritt produksjonslag
AI skal være et valgfritt produksjonslag over den underliggende animatic-strukturen.

- **Kilde:** Kap. 14.3 (l. 614) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** CORE, COMPOSE, PROVIDER · **Invarianter:** INV-11
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Datamodellen lar en scene eksistere og spilles av med kun animatic-data; AI-resultater lagres som tilleggsversjoner knyttet til scenen.
- **Tester:**
  - enhet: scene uten AI-versjoner er gyldig og avspillbar
  - manuell: arkitekturgjennomgang
- **Implementering:** src/core/model.ts#Take, src/core/assembly/film.ts#filmClips
- **Merknad:** Mangler test med en AI-take som tilleggsversjon.

### Kapittel 15

#### REQ-0216 – Overordnet filmtidslinje
Animatic Studio skal ha en egen overordnet filmtidslinje, adskilt fra detaljredigeringen av én enkelt 2D-scene, som er et arbeidssted for å sammenstille den aktive filmen.

- **Kilde:** Kap. 15 (l. 616-618) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** TIMELINE, UI · **Invarianter:** INV-01
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Filmtidslinjen er en egen visning som viser hele den aktive filmen, adskilt fra scenens detaljtidslinje i 2D-editoren.
- **Tester:**
  - e2e: åpne filmtidslinje og naviger til scene-editor og tilbake
- **Implementering:** src/app/assembly/AssemblyWorkspace.tsx, src/routes/prosjekt.$projectId.montering.tsx

#### REQ-0217 – Se aktive scener i rekkefølge
Brukeren skal kunne se alle aktive scener i riktig rekkefølge i filmtidslinjen.

- **Kilde:** Kap. 15.1 (l. 621) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** TIMELINE · **Invarianter:** INV-01
- **Avhengigheter:** REQ-0216
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt deaktiverte scener, så vises bare aktive scener, i samme rekkefølge som i aktiv manusvisning.
- **Tester:**
  - e2e: se aktive scener i rekkefølge i filmtidslinjen
- **Implementering:** src/core/assembly/film.ts

#### REQ-0218 – Navigere mellom scener
Brukeren skal kunne navigere mellom scener i filmtidslinjen.

- **Kilde:** Kap. 15.1 (l. 622) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** TIMELINE
- **Avhengigheter:** REQ-0216
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan hoppe til neste/forrige scene og til en valgt scene, og avspillingshodet flyttes dit.
- **Tester:**
  - e2e: navigere mellom scener i filmtidslinjen
- **Implementering:** src/app/assembly/AssemblyWorkspace.tsx

#### REQ-0219 – Se aktivt filmmateriale per scene
Brukeren skal kunne se aktivt filmmateriale for hver scene i filmtidslinjen.

- **Kilde:** Kap. 15.1 (l. 623) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** TIMELINE
- **Avhengigheter:** REQ-0216
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Hver scene i tidslinjen viser materialet som er valgt som aktiv filmversjon.
- **Tester:**
  - e2e: se aktivt filmmateriale per scene i filmtidslinjen
- **Implementering:** src/app/assembly/FilmTimeline.tsx, src/engine/compositor/film.ts, src/app/assembly/FilmTimeline.tsx

#### REQ-0220 – Trimme klipp
Brukeren skal kunne trimme klipp i filmtidslinjen.

- **Kilde:** Kap. 15.1 (l. 624) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** TIMELINE
- **Avhengigheter:** REQ-0216
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan forkorte et klipp i start eller slutt uten at kildemediet endres.
- **Tester:**
  - e2e: trimme klipp i filmtidslinjen
- **Implementering:** src/core/assembly/edit.ts, src/app/assembly/ClipParts.tsx, src/app/assembly/FilmTimeline.tsx

#### REQ-0221 – Splitte klipp
Brukeren skal kunne splitte klipp i filmtidslinjen.

- **Kilde:** Kap. 15.1 (l. 625) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** TIMELINE
- **Avhengigheter:** REQ-0216
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan dele et klipp i to på avspillingshodet; begge deler refererer samme kildemedie.
- **Tester:**
  - e2e: splitte klipp i filmtidslinjen
- **Implementering:** src/core/assembly/edit.ts, src/app/assembly/AssemblyWorkspace.tsx

#### REQ-0222 – Justere inn- og utpunkter
Brukeren skal kunne justere inn- og utpunkter for klipp.

- **Kilde:** Kap. 15.1 (l. 626) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** TIMELINE
- **Avhengigheter:** REQ-0216
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan sette inn- og utpunkt bildepresist i forhold til prosjektets bildefrekvens.
- **Tester:**
  - e2e: justere inn- og utpunkter i filmtidslinjen
- **Implementering:** src/app/assembly/ClipParts.tsx

#### REQ-0223 – Arbeide med overganger
Brukeren skal kunne arbeide med overganger mellom klipp i filmtidslinjen.

- **Kilde:** Kap. 15.1 (l. 627) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** TIMELINE
- **Avhengigheter:** REQ-0216
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan legge til, endre varighet på og fjerne en overgang (minst kutt og krysstoning) mellom to klipp.
- **Tester:**
  - e2e: arbeide med overganger i filmtidslinjen
- **Implementering:** src/core/assembly/film.ts, src/engine/compositor/film.ts, src/app/assembly/ClipPanel.tsx, src/app/assembly/TransitionEditor.tsx
- **Merknad:** «Minst kutt og krysstoning» i akseptansekriteriet er en foreslått minimumstolkning – ikke spesifisert i mandatet.

#### REQ-0224 – Justere timing
Brukeren skal kunne justere timing i filmtidslinjen.

- **Kilde:** Kap. 15.1 (l. 628) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** TIMELINE
- **Avhengigheter:** REQ-0216
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan endre plassering/varighet av klipp, og samlede tidskoder beregnes på nytt.
- **Tester:**
  - e2e: justere timing i filmtidslinjen
- **Implementering:** src/app/assembly/FilmTimeline.tsx, src/app/assembly/ClipPanel.tsx

#### REQ-0225 – Forhåndsvise hele filmen
Brukeren skal kunne forhåndsvise hele den samlede filmen.

- **Kilde:** Kap. 15.1 (l. 629) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** TIMELINE
- **Avhengigheter:** REQ-0216
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Avspilling fra start til slutt av aktiv film fungerer uten avbrudd mellom scener av ulik materialtype.
- **Tester:**
  - e2e: forhåndsvise hele filmen i filmtidslinjen
- **Implementering:** src/app/assembly/FilmViewer.tsx, src/engine/compositor/film.ts

#### REQ-0226 – Eksportere samlet film
Brukeren skal kunne eksportere den samlede filmen fra filmtidslinjen.

- **Kilde:** Kap. 15.1 (l. 630) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** TIMELINE, EXPORT
- **Avhengigheter:** REQ-0216
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Eksport av aktiv film gir én fil der rekkefølge og varighet samsvarer med tidslinjen.
- **Tester:**
  - e2e: eksportere samlet film i filmtidslinjen
- **Implementering:** src/app/assembly/ExportAnimaticDialog.tsx, src/engine/export/animatic.ts

#### REQ-0227 – Inspirasjon fra klippeprogrammer
Filmtidslinjens grensesnitt kan hente inspirasjon fra profesjonelle klippeprogrammer, men trenger ikke kopiere hele funksjonsbredden deres.

- **Kilde:** Kap. 15.1 (l. 631) · **Opprinnelse:** mandat · **Type:** design · **Prioritet:** P3 · **Fase:** 4
- **Moduler:** TIMELINE, UI
- **Avhengigheter:** REQ-0216
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Filmtidslinjen bruker kjente konvensjoner fra klippeprogrammer (spor, avspillingshode, trimhåndtak) uten krav om full funksjonsparitet.
- **Tester:**
  - manuell: heuristisk UX-gjennomgang
- **Implementering:** src/app/assembly/FilmTimeline.tsx, src/app/assembly/AssemblyWorkspace.tsx
- **Merknad:** Formulert som «kan hente inspirasjon» – derfor P3 som selvstendig krav.

#### REQ-0228 – Scenflytting i tidslinje speiles i manus
Flytting av en narrativ scene i filmtidslinjen skal gjenspeiles i manus.

- **Kilde:** Kap. 15.2 (l. 632-633) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 4
- **Moduler:** TIMELINE, SCRIPT, CORE · **Invarianter:** INV-01, INV-03
- **Avhengigheter:** Transaksjonell konsistens (kap. 3.4)
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt scene A før B, når brukeren flytter A etter B i filmtidslinjen, så viser manuset umiddelbart A etter B, og scenens ID er uendret.
- **Tester:**
  - integrasjon: flytting i tidslinje oppdaterer manusrekkefølge i samme transaksjon
  - dataintegritet: scene-ID uendret etter flytting
- **Implementering:** src/app/assembly/FilmTimeline.tsx, src/app/assembly/AssemblyWorkspace.tsx
- **Merknad:** Ufravikelig prinsipp nr. 2 i kap. 34.

#### REQ-0229 – Skille fire typer tidslinjeoperasjoner
Systemet skal skille mellom å flytte en hel narrativ scene, å trimme et bestemt medieklipp, å endre et utsnitt fra en scene og å deaktivere narrativt innhold.

- **Kilde:** Kap. 15.2 (l. 634-638) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P0 · **Fase:** 4
- **Moduler:** TIMELINE, CORE, SCRIPT · **Invarianter:** INV-01, INV-14
- **Avhengigheter:** REQ-0228
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Hver av de fire operasjonene har egen semantikk: bare flytting og deaktivering endrer manusstrukturen; trimming og utsnittsendring endrer kun medie-/forekomstdata.
- **Tester:**
  - enhet: operasjonstyper og deres effekt på manusmodellen
  - integrasjon: trimming endrer ikke manusrekkefølge eller synlighet
- **Implementering:** src/app/assembly/AssemblyWorkspace.tsx, src/core/commands/apply.ts, src/core/assembly/edit.ts
- **Merknad:** Mangler test for at utsnittsendring (klippdeler) ikke endrer manusstrukturen; «utsnitt» er fortsatt uavklart.

#### REQ-0230 – Trimming sletter ikke manus
Å trimme et klipp skal ikke automatisk slette manus.

- **Kilde:** Kap. 15.2 (l. 639) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 4
- **Moduler:** TIMELINE, SCRIPT · **Invarianter:** INV-14
- **Avhengigheter:** REQ-0229
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et klipp som dekker en hel manusscene, når klippet trimmes, så er manusteksten uendret.
- **Tester:**
  - dataintegritet: manusinnhold før/etter trimming er identisk
- **Implementering:** src/app/assembly/FilmTimeline.tsx

#### REQ-0231 – Avvik når manus ikke dekkes av film
Hvis en redigering gjør at en manuspassasje ikke lenger dekkes av aktiv film, skal dette kunne markeres som et avvik.

- **Kilde:** Kap. 15.2 (l. 640) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** TIMELINE, VERSION, SCRIPT
- **Avhengigheter:** REQ-0230; Manusblokker med tidskoblinger (kap. 6.1)
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en replikk koblet til et klipp, når klippet trimmes slik at replikken faller utenfor, så markeres replikken som avvik «ikke dekket av aktiv film».
- **Tester:**
  - integrasjon: dekningsberegning mellom manusblokker og aktive klipp
- **Implementering:** src/core/assembly/film.ts, src/app/assembly/ClipPanel.tsx
- **Merknad:** Kan alternativt høre til fase 6 (avviksdeteksjon).

#### REQ-0232 – Valg av aktivt produksjonsresultat
Hver scene skal ha et tydelig valg for hvilket produksjonsresultat som representerer scenen i den samlede filmen.

- **Kilde:** Kap. 15.3 (l. 641-642) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** TIMELINE, VERSION, CORE
- **Avhengigheter:** Sceneforekomst (kap. 3.3)
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Hver sceneforekomst har nøyaktig én aktiv versjon (eller eksplisitt ingen), og den vises tydelig i scenevisningen.
- **Tester:**
  - enhet: maks én aktiv versjon per sceneforekomst
- **Implementering:** src/app/assembly/ClipPanel.tsx, src/core/assembly/film.ts

#### REQ-0233 – Handlingen «Bruk denne»
Brukeren skal kunne velge en aktiv variant, for eksempel gjennom en handling som «Bruk denne».

- **Kilde:** Kap. 15.3 (l. 643-645) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** TIMELINE, VERSION, UI
- **Avhengigheter:** REQ-0232
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Når brukeren klikker «Bruk denne» på en variant, så blir den aktiv versjon i filmmonteringen, og handlingen kan angres.
- **Tester:**
  - e2e: bytt aktiv variant og verifiser i filmavspilling
- **Implementering:** src/app/assembly/ClipPanel.tsx
- **Merknad:** Linjen «Bruk denne» er duplisert (l. 644–645).

#### REQ-0234 – Andre varianter bevares
Når en aktiv variant velges, skal andre varianter bevares.

- **Kilde:** Kap. 15.3 (l. 646) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 4
- **Moduler:** VERSION · **Invarianter:** INV-07
- **Avhengigheter:** REQ-0233
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Etter bytte av aktiv variant finnes alle tidligere varianter fortsatt og kan gjenaktiveres.
- **Tester:**
  - dataintegritet: antall varianter uendret etter aktivering
- **Implementering:** src/core/commands/apply.ts
- **Merknad:** Ufravikelig prinsipp nr. 6 i kap. 34.

### Kapittel 16

#### REQ-0235 – Importere eksisterende ferdig film
Brukeren skal kunne importere film som allerede er produsert utenfor Animatic Studio.

- **Kilde:** Kap. 16 (l. 648-649) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 4
- **Moduler:** LIBRARY, TIMELINE
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan importere vanlige videoformater (f.eks. MP4/MOV), og filen blir en medieressurs i prosjektet.
- **Tester:**
  - import/eksport: import av MP4 og MOV
- **Implementering:** src/app/assembly/film-import.ts, src/app/assembly/ClipPanel.tsx, src/core/commands/apply.ts, src/core/assembly/film.ts
- **Merknad:** Ufravikelig prinsipp nr. 15 i kap. 34.

#### REQ-0236 – Koble importert klipp til manus
Et importert filmklipp skal kunne knyttes til en hel manusscene, en del av en manusscene, flere sammenhengende scener eller et bestemt tidsintervall.

- **Kilde:** Kap. 16.1 (l. 650-655) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P0 · **Fase:** 4
- **Moduler:** TIMELINE, SCRIPT, CORE · **Invarianter:** INV-02
- **Avhengigheter:** REQ-0235
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Et klipp kan kobles til hver av: én hel scene, en del av en scene, flere sammenhengende scener og et tidsintervall; koblingen bruker permanente ID-er.
- **Tester:**
  - enhet: koblingsmodell for alle fire varianter
  - dataintegritet: kobling overlever omnummerering
- **Implementering:** src/app/assembly/film-import.ts, src/app/assembly/ClipPanel.tsx, src/core/commands/apply.ts
- **Merknad:** Ufravikelig prinsipp nr. 15 i kap. 34.

#### REQ-0237 – Angi nøyaktig manusdekning
Brukeren skal kunne angi nøyaktig hvilken del av manuset et importert klipp dekker.

- **Kilde:** Kap. 16.1 (l. 656) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** TIMELINE, SCRIPT
- **Avhengigheter:** REQ-0236
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan markere start- og sluttpunkt i manuset (manusblokk) som klippet dekker, og markeringen lagres.
- **Tester:**
  - e2e: marker manusdekning for importert klipp
- **Implementering:** src/app/assembly/LongFilmImportDialog.tsx, src/core/assembly/discrepancy.ts, src/app/assembly/ClipPanel.tsx

#### REQ-0238 – Hente mediemetadata
Programmet skal kunne hente relevante metadata fra importert film, for eksempel varighet, oppløsning, bildefrekvens, lydspor og andre relevante tekniske egenskaper.

- **Kilde:** Kap. 16.2 (l. 657-663) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** LIBRARY, EXPORT
- **Avhengigheter:** REQ-0235
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Etter import vises varighet, oppløsning, bildefrekvens og antall/type lydspor korrekt for testfiler.
- **Tester:**
  - import/eksport: metadata for kjente testfiler samsvarer med ffprobe-referanse
- **Implementering:** src/app/assembly/film-import.ts, src/core/model.ts

#### REQ-0239 – Delvis ferdig scene med animatic-rest
Hvis bare en del av en scene er ferdig produsert, skal den ferdige delen kunne brukes sammen med animatic-materiale for resten.

- **Kilde:** Kap. 16.3 (l. 664-665) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** TIMELINE
- **Avhengigheter:** REQ-0236; REQ-0214
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en scene der første halvdel er importert film, så kan andre halvdel dekkes av 2D-animatic, og avspilling går sømløst mellom dem.
- **Tester:**
  - e2e: avspilling av delvis ferdig scene
- **Implementering:** src/engine/compositor/film.ts, src/core/assembly/film.ts, src/engine/compositor/film.ts, src/engine/export/film-video.ts

#### REQ-0240 – Montering fungerer ved ufullstendig produksjon
Den samlede filmmonteringen skal fungere også når produksjonen er ufullstendig.

- **Kilde:** Kap. 16.3 (l. 666) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** TIMELINE
- **Avhengigheter:** REQ-0216
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt scener uten produsert materiale, så kan filmen likevel spilles av og eksporteres (f.eks. med plassholder for manglende materiale).
- **Tester:**
  - e2e: avspilling av film med scener uten materiale
- **Implementering:** src/core/assembly/film.ts, src/engine/compositor/film.ts
- **Merknad:** Hvordan manglende materiale vises (plassholder, sort, manustekst) er ikke spesifisert.

#### REQ-0241 – Status for importert film
Importert film skal kunne få status som referanse, under arbeid, godkjent eller aktiv filmversjon.

- **Kilde:** Kap. 16.4 (l. 667-672) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** VERSION, LIBRARY
- **Avhengigheter:** REQ-0235; REQ-0232
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan sette hver av statusene referanse, under arbeid, godkjent og aktiv filmversjon på et importert klipp, og statusen vises og lagres.
- **Tester:**
  - enhet: statusoverganger
- **Implementering:** src/core/commands/apply.ts, src/app/assembly/ClipPanel.tsx
- **Merknad:** Forhold mellom status «aktiv filmversjon» og valg av aktiv variant (15.3) er uavklart.

#### REQ-0242 – Import bevarer kildemateriale
Import av film skal ikke ødelegge eller erstatte eksisterende kildemateriale.

- **Kilde:** Kap. 16.4 (l. 673) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 4
- **Moduler:** LIBRARY, VERSION, SECURITY · **Invarianter:** INV-07, INV-13
- **Avhengigheter:** REQ-0235
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt eksisterende materiale for en scene, når ny film importeres for samme scene, så er alt tidligere materiale uendret og tilgjengelig.
- **Tester:**
  - dataintegritet: hash av eksisterende mediefiler uendret etter ny import
- **Implementering:** src/app/assembly/film-import.ts, db/migrations/0011_project_delete_film.sql
- **Merknad:** Ufravikelig prinsipp nr. 27 i kap. 34.

### Kapittel 17

#### REQ-0243 – Brukerhandlingen «Generer scene»
En sentral brukerhandling skal være «Generer scene».

- **Kilde:** Kap. 17 (l. 675-677) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** PROMPT, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Handlingen «Generer scene» er tilgjengelig fra scenevisningen.
- **Tester:**
  - e2e: handlingen finnes og starter genereringsflyt
- **Implementering:** src/core/generation/scene-prompt.ts#buildScenePrompt, src/app/assembly/GenerateSceneDialog.tsx, src/app/assembly/SceneVideoSection.tsx, src/adapters/ai/video.functions.ts

#### REQ-0244 – Samle info og bygge genereringsinstruksjon
Når «Generer scene» aktiveres, skal systemet samle all relevant informasjon og bygge presise genereringsinstruksjoner.

- **Kilde:** Kap. 17 (l. 678) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** PROMPT
- **Avhengigheter:** REQ-0243
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Når «Generer scene» aktiveres, så produseres en strukturert instruksjon som brukeren kan se før noen betalt jobb starter.
- **Tester:**
  - integrasjon: promptbygging fra testscene gir forventet struktur
- **Implementering:** src/core/generation/scene-prompt.ts#buildScenePrompt, src/app/assembly/GenerateSceneDialog.tsx

#### REQ-0245 – Promptmotorens informasjonskilder
Promptmotoren skal kunne hente informasjon om manusets handling, replikker, karakterer, karakterenes aktive utseendetilstander, godkjente karakterreferanser, objekter og rekvisitter, lokasjon, miljø, visuell stil, kamerautsnitt, kamerabevegelser, laginformasjon fra 2D-editoren, scenevarighet, tidslinje, kontinuitetskrav, relevant materiale fra forrige og neste sekvens, ønsket AI-modell og modellens tekniske krav.

- **Kilde:** Kap. 17.1 (l. 679-698) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** PROMPT, CONTINUITY, LIBRARY, COMPOSE, CAMERA · **Invarianter:** INV-09
- **Avhengigheter:** REQ-0244; Kontinuitetsmotor (kap. 10)
- **Status:** Verifisert
- **Akseptansekriterier:**
  - For en testscene inneholder promptmotorens innsamlede kontekst alle 18 kategorier (der data finnes), inkludert aktiv utseendetilstand etter fortellingstid.
- **Tester:**
  - enhet: kontekstinnsamling per kategori
  - integrasjon: karaktertilstand før/etter kontinuitetshendelse velges korrekt
- **Implementering:** src/core/generation/scene-prompt.ts#buildScenePrompt, src/app/assembly/GenerateSceneDialog.tsx, src/core/generation/image-prompt.ts#buildContextImagePrompt

#### REQ-0246 – Modellspesifikk prompt
Den innsamlede informasjonen skal omformes til en egnet genereringsprompt for den valgte modellen.

- **Kilde:** Kap. 17.1 (l. 699) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** PROMPT, PROVIDER
- **Avhengigheter:** REQ-0245; REQ-0273
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Samme scene gir ulike prompter for to modeller med ulike kapabiliteter, og hver prompt holder seg innenfor modellens beskrevne begrensninger.
- **Tester:**
  - enhet: promptmal per adapter
  - integrasjon: validering mot adapterens kapabilitetsbeskrivelse
- **Implementering:** src/core/generation/prompt-writer.ts, src/adapters/ai/write-prompt.functions.ts, src/core/generation/model-prompt.ts

#### REQ-0247 – Engelske prompter som hovedregel
Tekniske systeminstruksjoner og genereringsprompter skal som hovedregel formuleres på engelsk, også når manuset og brukergrensesnittet er norske.

- **Kilde:** Kap. 17.2 (l. 700-702) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 5
- **Moduler:** PROMPT
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et norsk manus og norsk UI, så er genererte systeminstruksjoner og prompter på engelsk (unntatt ordrett dialog).
- **Tester:**
  - enhet: språkdeteksjon på genererte prompter
- **Implementering:** src/adapters/ai/generate-image.functions.ts, src/core/generation/scene-prompt.ts#buildScenePrompt, src/app/assembly/GenerateSceneDialog.tsx
- **Merknad:** Ufravikelig prinsipp nr. 12 i kap. 34.

#### REQ-0248 – Bevare norsk dialog ordrett
Systemet skal bevare den opprinnelige norske dialogen når dialogen skal brukes ordrett i genereringen.

- **Kilde:** Kap. 17.2 (l. 703) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** PROMPT, L10N · **Invarianter:** INV-05
- **Avhengigheter:** REQ-0247
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en replikk som skal sies ordrett, så finnes replikkens norske tekst tegn-for-tegn identisk i prompten.
- **Tester:**
  - enhet: ordrett dialog i prompt er identisk med manustekst
- **Implementering:** src/core/generation/scene-prompt.ts#buildScenePrompt, src/app/assembly/GenerateSceneDialog.tsx

#### REQ-0249 – Ingen utilsiktet omskriving av replikker
Oversettelse av instruksjoner må ikke føre til utilsiktet omskriving av replikkene.

- **Kilde:** Kap. 17.2 (l. 704) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** PROMPT, L10N · **Invarianter:** INV-05
- **Avhengigheter:** REQ-0248
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Replikker som er merket som ordrett dialog sendes aldri gjennom oversettelsessteget.
- **Tester:**
  - enhet: dialog-segmenter er beskyttet/markert i promptbyggeren
- **Implementering:** src/core/generation/scene-prompt.ts#buildScenePrompt, src/app/assembly/GenerateSceneDialog.tsx, src/core/generation/scene-prompt.ts#missingDialogue

#### REQ-0250 – Åpne genereringsprompten
Brukeren skal kunne åpne genereringsprompten.

- **Kilde:** Kap. 17.3 (l. 706-707) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 5
- **Moduler:** PROMPT, UI
- **Avhengigheter:** REQ-0244
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Fra scenen kan brukeren åpne gjeldende genereringsprompt i en egen visning.
- **Tester:**
  - e2e: åpne prompt
- **Implementering:** src/adapters/ai/generate-image.functions.ts, src/core/generation/scene-prompt.ts#buildScenePrompt, src/app/assembly/GenerateSceneDialog.tsx
- **Merknad:** Ufravikelig prinsipp nr. 11 (synlige prompter) i kap. 34.

#### REQ-0251 – Lese genereringsprompten
Brukeren skal kunne lese genereringsprompten i sin helhet.

- **Kilde:** Kap. 17.3 (l. 708) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P0 · **Fase:** 5
- **Moduler:** PROMPT, UI
- **Avhengigheter:** REQ-0250
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Hele prompten, inkludert systeminstruksjon, vises i lesbar form uten avkorting.
- **Tester:**
  - e2e: prompttekst i UI er identisk med prompt som sendes
- **Implementering:** src/adapters/ai/generate-image.functions.ts, src/core/generation/scene-prompt.ts#buildScenePrompt, src/app/assembly/GenerateSceneDialog.tsx

#### REQ-0252 – Redigere prompt manuelt
Brukeren skal kunne redigere genereringsprompten manuelt.

- **Kilde:** Kap. 17.3 (l. 709) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 5
- **Moduler:** PROMPT, UI
- **Avhengigheter:** REQ-0251
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan endre prompttekst, og endringen brukes ved neste generering.
- **Tester:**
  - e2e: rediger prompt og verifiser sendt payload (mock)
- **Implementering:** src/adapters/ai/generate-image.functions.ts, src/core/commands/apply.ts (SetGenerationPrompt), db/migrations/0014_ai_control.sql (generation_prompts), src/app/assembly/GenerateSceneDialog.tsx
- **Merknad:** Ufravikelig prinsipp nr. 11 (redigerbare prompter) i kap. 34.

#### REQ-0253 – Lagre redigert prompt
Brukeren skal kunne lagre en redigert versjon av genereringsprompten.

- **Kilde:** Kap. 17.3 (l. 710) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P0 · **Fase:** 5
- **Moduler:** PROMPT, VERSION
- **Avhengigheter:** REQ-0252
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Redigert prompt lagres som egen versjon og finnes etter omlasting.
- **Tester:**
  - dataintegritet: redigert prompt persisteres med versjon
- **Implementering:** src/core/commands/apply.ts (SetGenerationPrompt), db/migrations/0014_ai_control.sql (generation_prompts), src/app/assembly/GenerateSceneDialog.tsx

#### REQ-0254 – Kjøre «Generer scene» på nytt
Brukeren skal kunne kjøre «Generer scene» på nytt med endringene i prompten.

- **Kilde:** Kap. 17.3 (l. 711) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** PROMPT, QUEUE · **Invarianter:** INV-12
- **Avhengigheter:** REQ-0253
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en lagret redigert prompt, når brukeren kjører «Generer scene» igjen og godkjenner kostnad, så brukes den redigerte prompten.
- **Tester:**
  - integrasjon: regenerering bruker redigert prompt
- **Implementering:** src/app/assembly/SceneVideoSection.tsx

#### REQ-0255 – Skille automatisk og manuell prompt
Systemet skal skille mellom automatisk generert promptinnhold og manuelle overstyringer.

- **Kilde:** Kap. 17.3 (l. 712) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** PROMPT, VERSION
- **Avhengigheter:** REQ-0252
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Promptdata lagrer automatisk generert del og manuelle overstyringer separat, og UI markerer hvilke deler som er manuelt endret.
- **Tester:**
  - enhet: promptmodell med auto- og overstyringslag
- **Implementering:** src/core/commands/apply.ts (SetGenerationPrompt), db/migrations/0014_ai_control.sql (generation_prompts), src/app/assembly/GenerateSceneDialog.tsx

#### REQ-0256 – Manuelle promptendringer forsvinner ikke
Manuelle endringer i prompter skal ikke forsvinne ubemerket ved senere regenerering.

- **Kilde:** Kap. 17.3 (l. 713) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 5
- **Moduler:** PROMPT, VERSION
- **Avhengigheter:** REQ-0255
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en manuelt endret prompt, når underliggende data endres og prompten bygges på nytt, så beholdes overstyringen eller brukeren varsles eksplisitt om konflikt.
- **Tester:**
  - integrasjon: ombygging av prompt med manuell overstyring
- **Implementering:** src/core/commands/apply.ts (SetGenerationPrompt), db/migrations/0014_ai_control.sql (generation_prompts), src/app/assembly/GenerateSceneDialog.tsx
- **Merknad:** Knyttes til ufravikelig prinsipp nr. 27 (ingen destruktive endringer uten eksplisitt beslutning).

#### REQ-0257 – Full sporbarhet per generering
For hver generering skal programmet bevare systeminstruksjon, genereringsprompt, valgt modell, modellparametere, referanser, ressursversjoner, manusversjon, kostnadsinformasjon, genereringsresultat samt tidspunkt og status.

- **Kilde:** Kap. 17.4 (l. 714-725) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** VERSION, PROMPT, QUALITYCOST, QUEUE · **Invarianter:** INV-13
- **Avhengigheter:** REQ-0244
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Hver genereringsjobb har en uforanderlig post med alle ti feltene utfylt (eller eksplisitt tomme).
- **Tester:**
  - dataintegritet: genereringslogg inneholder alle felt
  - enhet: postene kan ikke endres etter fullføring
- **Implementering:** src/adapters/ai/generate-image.functions.ts, src/core/generation/trace.ts, src/adapters/ai/trace.server.ts, src/app/ai/TraceDetails.tsx

#### REQ-0258 – Sammenligne genereringsforsøk
Det skal være mulig å sammenligne genereringsforsøk.

- **Kilde:** Kap. 17.4 (l. 726) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** VERSION, UI
- **Avhengigheter:** REQ-0257
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan velge to genereringsforsøk og se resultatene og forskjeller i prompt/parametere side ved side.
- **Tester:**
  - e2e: sammenligningsvisning av to forsøk
- **Implementering:** src/app/assembly/CompareTakesDialog.tsx, src/core/generation/video.ts

### Kapittel 18

#### REQ-0259 – Automatisk håndtering av lange scener
Manusscener som er lengre enn en videomodell tillater i ett API-kall, skal håndteres automatisk så langt det er teknisk mulig.

- **Kilde:** Kap. 18 (l. 728-730) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** PROMPT, QUEUE, PROVIDER · **Invarianter:** INV-10
- **Avhengigheter:** REQ-0273
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en scene på 40 s og en modell med maks 10 s, så foreslår/planlegger systemet generering uten at brukeren må dele scenen manuelt.
- **Tester:**
  - integrasjon: segmentplan for lang scene med mock-adapter
- **Implementering:** src/core/generation/scene-prompt.ts#planSegments, segmentTimes, src/core/commands/apply.ts (ReplaceSegments), db/migrations/0014_ai_control.sql (production_segments.start_ms/end_ms)

#### REQ-0260 – Dele generering i segmenter
Når en scene overstiger modellens begrensninger, skal systemet kunne dele genereringsarbeidet i kortere segmenter.

- **Kilde:** Kap. 18.1 (l. 731-732) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 5
- **Moduler:** PROMPT, TIMELINE, QUEUE · **Invarianter:** INV-10
- **Avhengigheter:** REQ-0259
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt maks varighet M, så har alle segmenter varighet ≤ M og samlet dekker de hele scenen.
- **Tester:**
  - enhet: segmenteringsalgoritme dekker scenen uten hull/overlapp utover planlagt overlapp
- **Implementering:** src/core/generation/scene-prompt.ts#planSegments, segmentTimes, src/core/commands/apply.ts (ReplaceSegments), db/migrations/0014_ai_control.sql (production_segments.start_ms/end_ms)
- **Merknad:** Ufravikelig prinsipp nr. 14 i kap. 34.

#### REQ-0261 – Skjule API-begrensninger for brukeren
Brukeren skal ikke måtte forstå API-begrensningene for å oppnå en samlet scene.

- **Kilde:** Kap. 18.1 (l. 733) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** PROMPT, UI
- **Avhengigheter:** REQ-0260
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan generere en lang scene med én handling, og segmenteringen skjer uten at brukeren må angi segmentgrenser.
- **Tester:**
  - manuell: brukertest av generering av lang scene
- **Implementering:** src/core/generation/model-prompt.ts, src/adapters/ai/video.functions.ts

#### REQ-0262 – Segmentering tar hensyn til kontinuitet
Segmenteringen skal ta hensyn til narrative hendelser, dialog, kamerabevegelser, karaktertilstander, objekter, visuell stil og referanser fra tilstøtende segmenter.

- **Kilde:** Kap. 18.2 (l. 734-742) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** PROMPT, CONTINUITY, CAMERA · **Invarianter:** INV-09
- **Avhengigheter:** REQ-0260
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Segmentgrenser legges ikke midt i en replikk eller midt i en kamerabevegelse når et alternativ finnes, og hvert segment får riktige karaktertilstander, objekter, stil og referanse fra naboen.
- **Tester:**
  - enhet: segmentgrenser respekterer replikk- og bevegelsesgrenser
  - integrasjon: segmentprompter inneholder naboreferanser
- **Implementering:** src/core/generation/scene-prompt.ts#buildScenePrompt, src/app/assembly/GenerateSceneDialog.tsx

#### REQ-0263 – Kontinuitetsmekanismer mellom segmenter
Referansebilder eller andre støttede kontinuitetsmekanismer skal brukes når det er relevant.

- **Kilde:** Kap. 18.2 (l. 743) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** PROMPT, PROVIDER
- **Avhengigheter:** REQ-0262; REQ-0273
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en modell som støtter referansebilder/sisteramme-inndata, så sendes f.eks. siste bilde fra forrige segment som referanse til neste.
- **Tester:**
  - integrasjon: adapter med referansestøtte mottar referanse fra forrige segment
- **Implementering:** src/core/generation/video.ts, src/app/ai/last-frame.ts, src/app/assembly/SceneVideoSection.tsx, src/adapters/ai/video-followup.server.ts, src/adapters/ai/video.functions.ts

#### REQ-0264 – Sette segmenter sammen til én scene
Etter generering skal segmentene kunne settes sammen til én scene.

- **Kilde:** Kap. 18.3 (l. 744-745) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** TIMELINE
- **Avhengigheter:** REQ-0260
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Ferdige segmenter vises og spilles som én sammenhengende scene i filmtidslinjen.
- **Tester:**
  - e2e: sammensatt scene spilles av som én enhet
- **Implementering:** src/core/generation/video.ts, src/app/assembly/SceneVideoSection.tsx

#### REQ-0265 – Riktig rekkefølge, timing og overganger
Sammensettingen av segmenter skal ivareta riktig rekkefølge, timing og eventuelle overganger.

- **Kilde:** Kap. 18.3 (l. 746) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** TIMELINE
- **Avhengigheter:** REQ-0264
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Segmentene plasseres i planlagt rekkefølge og ved planlagte tidspunkter, med definerte overganger der det er satt.
- **Tester:**
  - enhet: sammensetting etter segmentplan
- **Implementering:** src/core/generation/video.ts, src/core/assembly/film.ts, src/app/assembly/ClipParts.tsx, src/engine/export/film-video.ts

#### REQ-0266 – Individuell revisjon av segmenter
Segmentene skal fortsatt være tilgjengelige for individuell revisjon etter sammensetting.

- **Kilde:** Kap. 18.3 (l. 747) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** TIMELINE, VERSION
- **Avhengigheter:** REQ-0264
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan regenerere eller bytte ett segment uten å påvirke de andre segmentene i scenen.
- **Tester:**
  - integrasjon: regenerering av ett segment
- **Implementering:** src/core/generation/video.ts

#### REQ-0267 – Segmentering endrer ikke manusstruktur
Automatisk segmentering skal ikke opprette nye manusscener, endre scenenummer eller endre den narrative sceneidentiteten.

- **Kilde:** Kap. 18.4 (l. 748-752) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 5
- **Moduler:** CORE, SCRIPT, TIMELINE · **Invarianter:** INV-02, INV-03, INV-10
- **Avhengigheter:** REQ-0260
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Etter segmentering av en scene er antall manusscener, scenenumre og scene-ID-er uendret.
- **Tester:**
  - dataintegritet: manusstruktur før/etter segmentering er identisk
- **Implementering:** src/core/generation/scene-prompt.ts#planSegments, segmentTimes, src/core/commands/apply.ts (ReplaceSegments), db/migrations/0014_ai_control.sql (production_segments.start_ms/end_ms)
- **Merknad:** Ufravikelig prinsipp nr. 14 i kap. 34.

#### REQ-0268 – Skille manusstruktur og genereringsstruktur
Systemet skal skille klart mellom manusstruktur og teknisk genereringsstruktur.

- **Kilde:** Kap. 18.4 (l. 753) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** CORE, TIMELINE · **Invarianter:** INV-10
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Datamodellen har egne entiteter for genereringssegmenter som refererer til, men ikke er, manusscener.
- **Tester:**
  - manuell: datamodellgjennomgang
  - enhet: segment-entitet har scene-ID-referanse
- **Implementering:** src/core/model.ts#ProductionSegment, src/core/commands/apply.ts#CreateSegments

### Kapittel 19

#### REQ-0269 – Leverandøruavhengig AI-arkitektur
Programmet skal ha en leverandøruavhengig arkitektur for integrasjon med relevante bilde-, video- og lydmodeller.

- **Kilde:** Kap. 19 (l. 755-756) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** PROVIDER, PROMPT
- **Status:** Implementert – ikke verifisert
- **Akseptansekriterier:**
  - Et nytt leverandøradapter kan legges til uten endring i kjerne-, manus- eller tidslinjemoduler.
- **Tester:**
  - manuell: arkitekturgjennomgang
  - integrasjon: to mock-adaptere bak samme grensesnitt
- **Implementering:** src/adapters/ai/providers.server.ts
- **Merknad:** Ufravikelig prinsipp nr. 11 (modellagnostisk) i kap. 34.

#### REQ-0270 – Koble egne API-kontoer
Brukeren skal kunne koble egne API-kontoer der leverandøren støtter det.

- **Kilde:** Kap. 19.1 (l. 757-758) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** PROVIDER, SECURITY
- **Avhengigheter:** REQ-0269
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan registrere egen API-nøkkel for en støttet leverandør, og nøkkelen valideres.
- **Tester:**
  - integrasjon: registrering og validering av nøkkel mot mock
- **Implementering:** src/app/ai/ProvidersDialog.tsx, src/adapters/ai/provider-keys.functions.ts, db/migrations/0024_ai_providers.sql

#### REQ-0271 – Sikker nøkkelhåndtering
API-nøkler skal håndteres sikkert.

- **Kilde:** Kap. 19.1 (l. 759) · **Opprinnelse:** mandat · **Type:** sikkerhet · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** SECURITY, PROVIDER
- **Status:** Verifisert
- **Akseptansekriterier:**
  - API-nøkler lagres kryptert på serversiden og brukes bare fra backend ved kall til leverandør.
- **Tester:**
  - manuell: sikkerhetsgjennomgang
  - integrasjon: nøkkel kan ikke hentes ut i klartekst via klient-API
- **Implementering:** src/adapters/ai/gateway.ts, src/adapters/ai/generate-image.functions.ts, src/adapters/ai/write-prompt.functions.ts, src/adapters/ai/key-vault.server.ts
- **Merknad:** Bare én plattformnøkkel (LOVABLE_API_KEY) finnes, som hemmelighet i Lovable Cloud brukt fra serverfunksjoner; ingen automatisk test søker etter nøkler i klientbunt, backup eller logger.

#### REQ-0272 – Hemmeligheter aldri eksponert
Hemmeligheter skal ikke lagres ukryptert i klientkode eller eksponeres i prosjektfiler og logger.

- **Kilde:** Kap. 19.1 (l. 760) · **Opprinnelse:** mandat · **Type:** sikkerhet · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** SECURITY, EXPORT
- **Avhengigheter:** REQ-0271
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Søk etter nøkkelverdi i klientbunt, eksporterte prosjektfiler/backup og logger gir ingen treff.
- **Tester:**
  - integrasjon: hemmelighetsskanning av klientbunt, prosjekteksport og logger
- **Implementering:** src/adapters/ai/gateway.ts#gatewayError, src/adapters/ai/generate-image.functions.ts, src/core/backup/index.ts, db/migrations/0024_ai_providers.sql, src/adapters/ai/providers.server.ts
- **Merknad:** Bare én plattformnøkkel (LOVABLE_API_KEY) finnes, som hemmelighet i Lovable Cloud brukt fra serverfunksjoner; ingen automatisk test søker etter nøkler i klientbunt, backup eller logger.

#### REQ-0273 – Adaptere beskriver faktiske muligheter
Hver leverandørintegrasjon skal beskrive sine faktiske muligheter, blant annet støttet oppgavetype, maksimal videovarighet, støttet oppløsning, referansebilder, bilde-til-video-funksjoner, tidsbegrensninger, kvalitetsparametere, tilgjengelige lydfunksjoner, kostnadsmodell og begrensninger.

- **Kilde:** Kap. 19.2 (l. 761-772) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** PROVIDER, QUALITYCOST
- **Avhengigheter:** REQ-0269
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Hvert adapter eksponerer en strukturert kapabilitetsbeskrivelse med alle ti feltene.
- **Tester:**
  - enhet: skjema-validering av kapabilitetsbeskrivelse
- **Implementering:** src/core/generation/providers.ts, src/adapters/ai/sound.functions.ts

#### REQ-0274 – Ingen antakelse om felles parametere
Systemet skal ikke anta at alle modeller støtter de samme parameterne.

- **Kilde:** Kap. 19.2 (l. 773) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** PROVIDER, PROMPT
- **Avhengigheter:** REQ-0273
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Parametere som en modell ikke støtter, sendes ikke og vises ikke som tilgjengelige for den modellen.
- **Tester:**
  - enhet: parameterfiltrering basert på kapabilitet
- **Implementering:** src/core/generation/providers.ts

#### REQ-0275 – Innsatsnivå per oppgave
Brukeren skal kunne velge ønsket innsatsnivå per oppgave: «Rask / Økonomisk» (prioriterer lavere kostnad og raske skisser), «Balansert» (prioriterer en hensiktsmessig kombinasjon av kvalitet, pris og behandlingstid) og «Høy / Premium» (prioriterer mer omfattende generering, referansekontroll og kvalitetssikring der dette støttes).

- **Kilde:** Kap. 19.3 (l. 774-783) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 5
- **Moduler:** QUALITYCOST, UI · **Invarianter:** INV-12
- **Avhengigheter:** REQ-0269
- **Status:** Verifisert
- **Akseptansekriterier:**
  - For hver genereringsoppgave kan brukeren velge ett av tre nivåer, og valget lagres med jobben.
- **Tester:**
  - e2e: velg nivå og verifiser at det lagres i jobbposten
- **Implementering:** src/app/ai/EffortPicker.tsx, src/core/generation/providers.ts, src/adapters/ai/video.functions.ts, src/core/generation/cost.ts
- **Merknad:** Linjene «Rask / Økonomisk» (l. 776–777) og «Høy / Premium» (l. 781–782) er duplisert. Ufravikelig prinsipp nr. 13 i kap. 34.

#### REQ-0276 – Innsatsnivå til leverandørfunksjoner
Valgt innsatsnivå skal oversettes til konkrete funksjoner hos den valgte leverandøren.

- **Kilde:** Kap. 19.3 (l. 784) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** QUALITYCOST, PROVIDER
- **Avhengigheter:** REQ-0275; REQ-0273
- **Status:** Verifisert
- **Akseptansekriterier:**
  - For en gitt modell gir hvert nivå et dokumentert sett med konkrete parametere (f.eks. oppløsning, antall kandidater).
- **Tester:**
  - enhet: mapping nivå→parametere per adapter
- **Implementering:** src/core/generation/providers.ts

#### REQ-0277 – Ikke love bedre resultat for pris
Programmet skal ikke love at høyere kostnad garanterer bedre resultat.

- **Kilde:** Kap. 19.3 (l. 785) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** QUALITYCOST, UI
- **Avhengigheter:** REQ-0275
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Tekster i nivåvelger og kostnadsdialog formulerer høyere nivå som prioritering, ikke garanti.
- **Tester:**
  - manuell: språkgjennomgang av UI-tekster
- **Implementering:** src/core/generation/providers.ts, src/app/ai/EffortPicker.tsx

#### REQ-0278 – Vise tilgjengelige kvalitetsmekanismer
Systemet skal vise hvilke modellspesifikke kvalitetsmekanismer som faktisk er tilgjengelige for valgt modell – f.eks. justerbar resonneringsinnsats, eller kvalitetsvalg gjennom oppløsning, varighet, flere kandidater, flere iterasjoner, referansestyring, kvalitetskontroll og andre parametere.

- **Kilde:** Kap. 19.4 (l. 786-796) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** QUALITYCOST, PROVIDER, UI
- **Avhengigheter:** REQ-0273
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Ved valg av modell vises kun de kvalitetsmekanismene adapteret oppgir som støttet.
- **Tester:**
  - integrasjon: UI viser mekanismer i samsvar med kapabilitetsbeskrivelse
- **Implementering:** src/core/generation/providers.ts

#### REQ-0279 – Kostnadsestimat før betalt oppgave
Før en betalt oppgave starter, skal brukeren få et tydelig kostnadsestimat.

- **Kilde:** Kap. 19.5 (l. 797-798) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 5
- **Moduler:** QUALITYCOST, QUEUE, UI · **Invarianter:** INV-12
- **Avhengigheter:** REQ-0273
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Ingen betalt jobb sendes til leverandør før brukeren har sett estimat og godkjent det.
- **Tester:**
  - integrasjon: jobb uten godkjent estimat blokkeres
- **Implementering:** src/core/generation/cost.ts, src/app/ai/AiPanel.tsx, src/app/library/GenerateImagePanel.tsx
- **Merknad:** Ufravikelig prinsipp nr. 13 i kap. 34.

#### REQ-0280 – Innhold i kostnadsestimat
Kostnadsestimatet skal så langt mulig inkludere modellvalg, antall genereringer, varighet, oppløsning, kvalitetsprofil, eventuelle ekstrarunder og samlet forventet kostnad.

- **Kilde:** Kap. 19.5 (l. 799-806) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** QUALITYCOST, UI
- **Avhengigheter:** REQ-0279
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Estimatdialogen viser de sju elementene der data finnes.
- **Tester:**
  - enhet: estimatberegning
  - e2e: estimatdialog viser alle felt
- **Implementering:** src/core/generation/providers.ts, src/app/library/GenerateSoundPanel.tsx, src/app/ai/CostLines.tsx

#### REQ-0281 – Merke usikre estimater
Usikre kostnadsestimater skal merkes tydelig.

- **Kilde:** Kap. 19.5 (l. 807) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** QUALITYCOST, UI
- **Avhengigheter:** REQ-0280
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Når adapteret oppgir usikker pris (f.eks. variabelt antall runder), vises estimatet med tydelig usikkerhetsmerking/intervall.
- **Tester:**
  - visuell: usikkerhetsmerking i estimatdialog
- **Implementering:** src/core/generation/cost.ts, src/app/ai/AiPanel.tsx, src/app/library/GenerateImagePanel.tsx

#### REQ-0282 – Budsjettrammer på flere nivåer
Brukeren skal kunne sette kostnadsrammer for en enkelt jobb, en scene, en gruppe scener, en produksjon og et helt prosjekt.

- **Kilde:** Kap. 19.6 (l. 808-814) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** QUALITYCOST · **Invarianter:** INV-12
- **Avhengigheter:** REQ-0279
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan sette ramme på hvert av de fem nivåene, og den strengeste gjeldende rammen håndheves.
- **Tester:**
  - enhet: budsjetthierarki og håndheving
- **Implementering:** src/core/generation/cost.ts, src/app/ai/AiPanel.tsx, src/app/library/GenerateImagePanel.tsx, src/adapters/ai/generate-image.functions.ts (budsjettport), src/core/commands/apply.ts (SetAiBudget), src/adapters/storage/commands.functions.ts (bare eier), src/adapters/ai/ai-gate.server.ts

#### REQ-0283 – Vise estimert og faktisk forbruk
Det skal være mulig å se estimert og registrert faktisk API-forbruk.

- **Kilde:** Kap. 19.6 (l. 815) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** QUALITYCOST, UI
- **Avhengigheter:** REQ-0257
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En forbruksoversikt viser estimert og faktisk kostnad per jobb og aggregert per nivå.
- **Tester:**
  - integrasjon: faktisk kostnad registreres fra adapter
- **Implementering:** src/core/generation/cost.ts, src/app/ai/AiPanel.tsx, src/app/library/GenerateImagePanel.tsx

#### REQ-0284 – Ingen generering utenfor rammer
Ingen ekstra betalte genereringer skal utføres utenfor brukerens godkjente rammer.

- **Kilde:** Kap. 19.6 (l. 816) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 5
- **Moduler:** QUALITYCOST, QUEUE · **Invarianter:** INV-12
- **Avhengigheter:** REQ-0282
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et oppbrukt budsjett, når en ny betalt jobb eller automatisk ekstrarunde forsøkes, så stoppes den og brukeren varsles.
- **Tester:**
  - integrasjon: kø stopper jobb som overskrider ramme
  - enhet: automatiske retries teller mot rammen
- **Implementering:** src/adapters/ai/generate-image.functions.ts (budsjettport), src/core/commands/apply.ts (SetAiBudget), src/adapters/storage/commands.functions.ts (bare eier), src/adapters/ai/ai-gate.server.ts, db/migrations/0024_ai_providers.sql

#### REQ-0285 – Generere og sammenligne kandidater
Brukeren skal kunne generere flere kandidater og sammenligne dem side ved side.

- **Kilde:** Kap. 19.7 (l. 817-818) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** QUALITYCOST, VERSION, UI · **Invarianter:** INV-12
- **Avhengigheter:** REQ-0279
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan bestille N kandidater (etter kostnadsgodkjenning) og se dem side ved side.
- **Tester:**
  - e2e: generer 3 kandidater med mock og vis side ved side
- **Implementering:** src/app/library/GenerateImagePanel.tsx, src/app/assembly/SceneVideoSection.tsx, src/app/library/ImageCompareDialog.tsx

#### REQ-0286 – Aktivere kandidat uten å slette andre
Den foretrukne kandidaten skal kunne aktiveres uten å slette de andre.

- **Kilde:** Kap. 19.7 (l. 819) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 5
- **Moduler:** VERSION · **Invarianter:** INV-07
- **Avhengigheter:** REQ-0285
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Etter aktivering av én kandidat finnes alle andre kandidater fortsatt.
- **Tester:**
  - dataintegritet: kandidater bevares etter aktivering
- **Implementering:** src/core/commands/apply.ts, src/core/library/reupload.ts, src/core/model.ts
- **Merknad:** Ufravikelig prinsipp nr. 6 i kap. 34. Mandatet sier «varianten»; i 19.7 betyr det genereringskandidat, ikke scenevariant (DEC-0015).

#### REQ-0287 – Støtte for kvalitetskontroll
Systemet skal kunne hjelpe brukeren å evaluere om generert materiale følger manus, karakterreferanser, stil, kontinuitet og kamera- og sceneinstruksjoner.

- **Kilde:** Kap. 19.8 (l. 820-826) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** QUALITYCOST, CONTINUITY
- **Avhengigheter:** REQ-0257
- **Status:** Verifisert
- **Akseptansekriterier:**
  - For et generert klipp kan brukeren få en vurdering per kriterium (manus, karakterreferanser, stil, kontinuitet, kamera/sceneinstruksjon).
- **Tester:**
  - integrasjon: vurderingsrapport med fem kriterier
  - manuell: kvalitativ vurdering av nytte
- **Implementering:** src/core/generation/quality.ts, src/app/assembly/CompareTakesDialog.tsx
- **Merknad:** Fasetilordning usikker (fase 5/6/8) – se ROADMAP (kvalitetskontroll fase 6/8).

#### REQ-0288 – Automatiske vurderinger er støtte
Automatiske kvalitetsvurderinger skal fremstilles som støtte, ikke garantier.

- **Kilde:** Kap. 19.8 (l. 827) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** QUALITYCOST, UI
- **Avhengigheter:** REQ-0287
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Vurderinger vises som rådgivende, og ingen automatisk vurdering godkjenner eller forkaster materiale uten brukerens beslutning.
- **Tester:**
  - manuell: UI-tekst og flyt-gjennomgang
- **Implementering:** src/core/generation/quality.ts

### Kapittel 20

#### REQ-0289 – Robust produksjonskø
Animatic Studio skal ha en robust produksjonskø.

- **Kilde:** Kap. 20 (l. 829-830) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** QUEUE
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Køen tåler omstart av klient og backend uten tap av jobber eller status.
- **Tester:**
  - integrasjon: restart av backend under kjørende jobb
- **Implementering:** src/adapters/ai/video-followup.server.ts, src/adapters/ai/queue.functions.ts

#### REQ-0290 – Massegenerering av scener
Brukeren skal kunne velge flere scener og legge dem i kø (f.eks. markere 15 scener og starte generering før vedkommende forlater arbeidsplassen).

- **Kilde:** Kap. 20.1 (l. 831-833) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** QUEUE, UI · **Invarianter:** INV-12
- **Avhengigheter:** REQ-0289; REQ-0279
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt 15 valgte scener, når brukeren starter massegenerering og godkjenner samlet estimat, så legges 15 jobber i kø.
- **Tester:**
  - e2e: massevalg og køing av 15 scener
- **Implementering:** src/app/assembly/BatchVideoDialog.tsx, src/core/generation/video.ts

#### REQ-0291 – Jobber uavhengige av nettleserfane
Renderingsjobber skal ikke være avhengige av at en bestemt nettleserfane forblir åpen.

- **Kilde:** Kap. 20.2 (l. 834-835) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P0 · **Fase:** 5
- **Moduler:** QUEUE
- **Avhengigheter:** REQ-0293
- **Status:** Implementert – ikke verifisert
- **Akseptansekriterier:**
  - Gitt kjørende jobber, når nettleserfanen lukkes, så fortsetter jobbene og fullføres.
- **Tester:**
  - e2e: lukk fane under kjøring og verifiser fullføring
- **Implementering:** src/core/generation/cost.ts#unclaimedImageJobs, src/app/ai/AiPanel.tsx, src/adapters/ai/video.functions.ts, src/app/ai/video-jobs.ts, src/routes/api/public/cron/ai-jobs.ts, src/adapters/ai/video-followup.server.ts
- **Merknad:** Genereringen er fortsatt et kall som nettleseren venter på; ekte kø gjenstår (M5).

#### REQ-0292 – Lagre og hente jobbstatus
Jobbstatus skal kunne lagres og hentes igjen senere.

- **Kilde:** Kap. 20.2 (l. 836) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P0 · **Fase:** 5
- **Moduler:** QUEUE, SECURITY
- **Avhengigheter:** REQ-0289
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Status for alle jobber er persistent og kan hentes etter ny innlogging fra en annen nettleser.
- **Tester:**
  - integrasjon: hent jobbstatus i ny økt
- **Implementering:** src/app/ai/use-ai-jobs.ts, src/app/ai/AiPanel.tsx, src/core/generation/cost.ts#jobState
- **Merknad:** Ufravikelig prinsipp nr. 26 i kap. 34.

#### REQ-0293 – Vedvarende backend-jobbarkitektur
Langvarige oppgaver skal utføres i en egnet vedvarende backend-jobbarkitektur.

- **Kilde:** Kap. 20.2 (l. 837) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** QUEUE
- **Avhengigheter:** Backend-valg (kap. 1.2)
- **Status:** Implementert – ikke verifisert
- **Akseptansekriterier:**
  - Langvarige oppgaver kjøres i en backend-jobbtjeneste med persistent kø, ikke i klienten.
- **Tester:**
  - manuell: arkitekturgjennomgang
- **Implementering:** db/migrations/0025_ai_queue.sql, src/adapters/ai/video-followup.server.ts, src/adapters/ai/queue.functions.ts
- **Merknad:** Ufravikelig prinsipp nr. 26 i kap. 34; kap. 1.2 sier at Lovable alene ikke kan antas å håndtere dette.

#### REQ-0294 – Jobbstatuser i køen
Køen skal vise statusene venter, klargjøres, genereres, etterbehandles, fullført, mislykket og stoppet eller avbrutt.

- **Kilde:** Kap. 20.3 (l. 838-846) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** QUEUE, UI
- **Avhengigheter:** REQ-0292
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Hver jobb har til enhver tid én av de sju statusene, og overganger vises i køvisningen.
- **Tester:**
  - enhet: tilstandsmaskin for jobbstatus
- **Implementering:** src/app/ai/use-ai-jobs.ts, src/app/ai/AiPanel.tsx, src/core/generation/cost.ts#jobState

#### REQ-0295 – Vise pålitelig fremdrift
Køen skal vise fremdrift når dette kan beregnes pålitelig.

- **Kilde:** Kap. 20.3 (l. 847) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** QUEUE, UI
- **Avhengigheter:** REQ-0294
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Fremdriftsindikator vises bare når adapter/jobb gir pålitelig fremdrift; ellers vises ubestemt indikator.
- **Tester:**
  - enhet: fremdriftsvisning avhengig av kapabilitet
- **Implementering:** src/core/generation/queue.ts, src/app/ai/AiPanel.tsx

#### REQ-0296 – Oversikt ved gjenåpning
Når brukeren åpner programmet igjen, skal vedkommende kunne se hva som er ferdig, hva som fortsatt kjører, hvilke jobber som feilet og hvilke resultater som kan gjennomgås.

- **Kilde:** Kap. 20.4 (l. 848-853) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** QUEUE, UI
- **Avhengigheter:** REQ-0292
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Ved innlogging etter fravær vises en oppsummering med fire grupper: ferdig, kjører, feilet, klar til gjennomgang.
- **Tester:**
  - e2e: gjenopptakelsesvisning etter simulert fravær
- **Implementering:** src/app/ai/use-ai-jobs.ts, src/app/ai/AiPanel.tsx, src/core/generation/cost.ts#jobState

#### REQ-0297 – Forsøk på nytt
Systemet skal kunne støtte forsøk på nytt for mislykkede jobber.

- **Kilde:** Kap. 20.5 (l. 854-856) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** QUEUE, QUALITYCOST · **Invarianter:** INV-12
- **Avhengigheter:** REQ-0289
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En mislykket jobb kan startes på nytt; automatiske nye forsøk respekterer kostnadsrammer.
- **Tester:**
  - integrasjon: forsøk på nytt med mock-leverandør
- **Implementering:** src/app/ai/use-ai-jobs.ts, src/app/ai/AiPanel.tsx, src/core/generation/cost.ts#jobState

#### REQ-0298 – Håndtering av API-begrensninger
Køen skal støtte håndtering av API-begrensninger (f.eks. ratebegrensning).

- **Kilde:** Kap. 20.5 (l. 857) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** QUEUE
- **Avhengigheter:** REQ-0289
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Ved ratebegrensningssvar fra leverandør venter køen og prøver igjen uten at jobben markeres som mislykket.
- **Tester:**
  - integrasjon: håndtering av api-begrensninger med mock-leverandør
- **Implementering:** src/adapters/ai/video.functions.ts, src/adapters/ai/sound.functions.ts

#### REQ-0299 – Feilmeldinger
Køen skal gi feilmeldinger for mislykkede jobber.

- **Kilde:** Kap. 20.5 (l. 858) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** QUEUE
- **Avhengigheter:** REQ-0289
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Mislykkede jobber viser en forståelig feilmelding og teknisk detalj (uten hemmeligheter).
- **Tester:**
  - integrasjon: feilmeldinger med mock-leverandør
- **Implementering:** src/app/ai/use-ai-jobs.ts, src/app/ai/AiPanel.tsx, src/core/generation/cost.ts#jobState

#### REQ-0300 – Køprioritering
Køen skal støtte køprioritering.

- **Kilde:** Kap. 20.5 (l. 859) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** QUEUE
- **Avhengigheter:** REQ-0289
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan endre prioritet/rekkefølge på ventende jobber, og høyere prioritet startes først.
- **Tester:**
  - integrasjon: køprioritering med mock-leverandør
- **Implementering:** src/core/generation/queue.ts, src/adapters/ai/queue.functions.ts, src/app/ai/AiPanel.tsx

#### REQ-0301 – Kontroll av parallellitet
Køen skal støtte kontroll av parallellitet.

- **Kilde:** Kap. 20.5 (l. 860) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** QUEUE
- **Avhengigheter:** REQ-0289
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Maks antall samtidige jobber kan settes (per leverandør/prosjekt) og overholdes.
- **Tester:**
  - integrasjon: kontroll av parallellitet med mock-leverandør
- **Implementering:** src/adapters/ai/video.functions.ts, src/app/assembly/SceneVideoSection.tsx, src/adapters/ai/video-followup.server.ts

#### REQ-0302 – Kostnadsgrenser i køen
Køen skal håndheve kostnadsgrenser.

- **Kilde:** Kap. 20.5 (l. 861) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** QUEUE, QUALITYCOST · **Invarianter:** INV-12
- **Avhengigheter:** REQ-0289
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Jobber som vil overskride gjeldende ramme startes ikke.
- **Tester:**
  - integrasjon: kostnadsgrenser i køen med mock-leverandør
- **Implementering:** src/adapters/ai/generate-image.functions.ts, src/adapters/ai/write-prompt.functions.ts, src/core/generation/cost.ts#aiUsage, src/adapters/ai/video.functions.ts
- **Merknad:** Budsjettporten på serveren stopper genereringer over månedsrammen (det finnes ingen egen kø), men porten er ikke testet automatisk.

#### REQ-0303 – Bevare fullførte resultater
Ved feil skal allerede fullførte resultater bevares.

- **Kilde:** Kap. 20.5 (l. 862) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 5
- **Moduler:** QUEUE · **Invarianter:** INV-07
- **Avhengigheter:** REQ-0289
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en massejobb der jobb 8 av 15 feiler, så er resultatene fra jobb 1–7 bevart og tilgjengelige.
- **Tester:**
  - integrasjon: bevare fullførte resultater med mock-leverandør
- **Implementering:** src/app/ai/use-ai-jobs.ts, src/app/ai/AiPanel.tsx, src/core/generation/cost.ts#jobState, src/adapters/ai/generate-image.functions.ts
- **Merknad:** Ufravikelig prinsipp nr. 27 i kap. 34.

### Kapittel 21

#### REQ-0304 – Versjonering dypt integrert
Versjonerings- og synkroniseringsavvikssystemet skal være dypt integrert i hele applikasjonen.

- **Kilde:** Kap. 21 (l. 864-865) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** VERSION, CORE · **Invarianter:** INV-07, INV-13
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Alle produksjonsobjekter (manus, ressurser, lyd, scener, genereringer) har versjonsreferanser fra første datamodell.
- **Tester:**
  - manuell: datamodellgjennomgang for versjonsfelt
- **Implementering:** src/core/commands/apply.ts, db/migrations/0001_core.sql, src/core/model.ts, db/migrations/0004_library_notes.sql
- **Merknad:** Manus, ressurser, scener og takes har versjonsobjekter, men ingen samlet test viser versjonsreferanser for alle produksjonsobjekttyper.

#### REQ-0305 – Endringsdeteksjon for berørt materiale
Når manus eller ressurser endres, skal systemet identifisere hvilke produksjonselementer som kan være påvirket – f.eks. ved at en replikk endres, handling endres, rekvisitt byttes, karaktervariant endres, scene forkortes, lyd byttes eller en kontinuitetshendelse flyttes.

- **Kilde:** Kap. 21.1 (l. 866-875) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 6
- **Moduler:** VERSION, CONTINUITY · **Invarianter:** INV-07
- **Avhengigheter:** REQ-0304
- **Status:** Verifisert
- **Akseptansekriterier:**
  - For hver av de sju eksempelendringene flagges de produksjonselementene som er avhengige av det endrede objektet.
- **Tester:**
  - integrasjon: avhengighetsgraf og flagging for hver eksempelendring
- **Implementering:** src/core/assembly/discrepancy.ts, src/core/commands/apply.ts (AcceptScriptChanges, SetProducedFrom), db/migrations/0014_ai_control.sql (compositions.produced_from, takes.accepted_from)
- **Merknad:** Ufravikelig prinsipp nr. 7 i kap. 34.

#### REQ-0306 – Tre valg ved avvik
Når eksisterende film ikke lenger samsvarer med gjeldende manus, skal brukeren kunne velge: A. Godkjenn eksisterende materiale, B. Oppdater eller generer på nytt, eller C. Angre manusendringen.

- **Kilde:** Kap. 21.2 (l. 876-888) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 6
- **Moduler:** VERSION, UI · **Invarianter:** INV-07, INV-08
- **Avhengigheter:** REQ-0305
- **Status:** Verifisert
- **Akseptansekriterier:**
  - For et flagget avvik tilbys nøyaktig de tre valgene A, B og C.
- **Tester:**
  - e2e: avviksdialog med tre valg
- **Implementering:** src/core/assembly/discrepancy.ts, src/core/commands/apply.ts (AcceptScriptChanges, SetProducedFrom), db/migrations/0014_ai_control.sql (compositions.produced_from, takes.accepted_from), src/app/assembly/ScriptChanges.tsx, src/app/assembly/FilmTimeline.tsx (merker), src/app/script/ScriptPageView.tsx (merker), src/app/scene-editor/SceneEditorWorkspace.tsx (varsel)
- **Merknad:** Linjene «A. Godkjenn eksisterende materiale» (l. 878–879) og «B. Oppdater eller generer på nytt» (l. 882–883) er duplisert. Ufravikelig prinsipp nr. 8.

#### REQ-0307 – Godkjenning registreres med versjoner
Ved valg A (godkjenn eksisterende materiale) bekrefter brukeren at avviket er akseptabelt, og beslutningen registreres sammen med relevante versjoner.

- **Kilde:** Kap. 21.2 (l. 880-881) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** VERSION · **Invarianter:** INV-08
- **Avhengigheter:** REQ-0306
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Etter godkjenning lagres en beslutningspost med bruker, tidspunkt, manusversjon og materialversjon, og avviket vises ikke lenger som uavklart.
- **Tester:**
  - dataintegritet: beslutningspost inneholder versjonsreferanser
- **Implementering:** src/core/assembly/discrepancy.ts, src/core/commands/apply.ts (AcceptScriptChanges, SetProducedFrom), db/migrations/0014_ai_control.sql (compositions.produced_from, takes.accepted_from)

#### REQ-0308 – Lokal oppdatering eller AI vurderes
Ved valg B skal systemet undersøke om oppdateringen kan utføres lokalt eller krever AI.

- **Kilde:** Kap. 21.2 (l. 884) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** VERSION, PROMPT · **Invarianter:** INV-11
- **Avhengigheter:** REQ-0306
- **Status:** Verifisert
- **Akseptansekriterier:**
  - For en endring som kan løses lokalt (f.eks. bytte av lydfil i 2D-animatic), foreslås lokal oppdatering uten AI-kostnad.
- **Tester:**
  - integrasjon: klassifisering lokal vs. AI for testendringer
- **Implementering:** src/core/generation/video.ts, src/app/assembly/AiUpdateSection.tsx

#### REQ-0309 – Kostnad vises før regenerering
Ved valg B skal eventuell kostnad vises før generering.

- **Kilde:** Kap. 21.2 (l. 885) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 6
- **Moduler:** QUALITYCOST, VERSION · **Invarianter:** INV-12
- **Avhengigheter:** REQ-0279
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Ingen regenerering fra avviksdialogen starter før kostnad er vist og godkjent.
- **Tester:**
  - integrasjon: regenerering fra avvik krever godkjent estimat
- **Implementering:** src/app/assembly/AiUpdateSection.tsx

#### REQ-0310 – Ny versjon ved siden av gammel
Ved valg B skal ny versjon bevares ved siden av den gamle.

- **Kilde:** Kap. 21.2 (l. 886) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 6
- **Moduler:** VERSION · **Invarianter:** INV-07
- **Avhengigheter:** REQ-0306
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Etter oppdatering finnes både gammel og ny versjon, og den gamle kan gjenaktiveres.
- **Tester:**
  - dataintegritet: gammel versjon bevart etter oppdatering
- **Implementering:** src/app/assembly/AiUpdateSection.tsx

#### REQ-0311 – Selektiv angring av manusendring
Ved valg C skal programmet reversere den relevante manusendringen uten å overskrive andre uavhengige redigeringer.

- **Kilde:** Kap. 21.2 (l. 887-888) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 6
- **Moduler:** VERSION, SCRIPT · **Invarianter:** INV-08
- **Avhengigheter:** REQ-0306
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt to uavhengige manusendringer X og Y, når brukeren velger C for avviket forårsaket av X, så reverseres X mens Y beholdes.
- **Tester:**
  - integrasjon: selektiv revert med uavhengige endringer
- **Implementering:** src/app/assembly/ScriptChanges.tsx, src/app/assembly/FilmTimeline.tsx (merker), src/app/script/ScriptPageView.tsx (merker), src/app/scene-editor/SceneEditorWorkspace.tsx (varsel), src/core/assembly/discrepancy.ts
- **Merknad:** Krever endringslogg på blokk-/feltnivå, ikke bare lineær angre-stakk – se ADR-0005 / OPEN_QUESTIONS B (selektiv angre).

#### REQ-0312 – Flagge bare berørt område
Hvis bare én replikk endres, skal systemet så langt mulig flagge bare berørt lyd og filmområde.

- **Kilde:** Kap. 21.3 (l. 889-890) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** VERSION, TIMELINE, AUDIO
- **Avhengigheter:** REQ-0305
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Endring av én replikk flagger kun replikkens dialoglyd og tidsintervallet koblet til replikken, ikke hele scenen.
- **Tester:**
  - integrasjon: granularitet på flagging ved replikkendring
- **Implementering:** src/core/assembly/discrepancy.ts, src/core/commands/apply.ts (AcceptScriptChanges, SetProducedFrom), db/migrations/0014_ai_control.sql (compositions.produced_from, takes.accepted_from), src/app/assembly/ScriptChanges.tsx, src/app/assembly/FilmTimeline.tsx (merker), src/app/script/ScriptPageView.tsx (merker), src/app/scene-editor/SceneEditorWorkspace.tsx (varsel)

#### REQ-0313 – Sen endring påvirker ikke tidlig sekvens
En endring sent i en scene skal ikke automatisk gjøre en uavhengig sekvens i begynnelsen av scenen utdatert.

- **Kilde:** Kap. 21.3 (l. 891) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** VERSION, TIMELINE
- **Avhengigheter:** REQ-0312
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en scene med to uavhengige delsekvenser, når en replikk i siste del endres, så forblir første delsekvens uflagget.
- **Tester:**
  - integrasjon: flagging per delsekvens
- **Implementering:** src/core/assembly/discrepancy.ts, src/core/commands/apply.ts (AcceptScriptChanges, SetProducedFrom), db/migrations/0014_ai_control.sql (compositions.produced_from, takes.accepted_from)

#### REQ-0314 – Vise usikre konsekvenser
Når konsekvensene av en endring er usikre, skal dette fremgå.

- **Kilde:** Kap. 21.3 (l. 892) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** VERSION, UI
- **Avhengigheter:** REQ-0312
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Flagg med usikker konsekvens har egen visuell markering («mulig berørt»).
- **Tester:**
  - visuell: skille sikre og usikre avviksflagg
- **Implementering:** src/core/library/impact.ts, src/app/library/ApproveImpactDialog.tsx, src/core/continuity/analysis.ts, src/app/continuity/ContinuityAnalysisPanel.tsx

#### REQ-0315 – Avvik synlige i alle arbeidsflater
Uavklarte avvik skal kunne vises i manusrelaterte arbeidsvisninger, sceneeditor, filmtidslinje, produksjonsoversikt og eksportkontroll.

- **Kilde:** Kap. 21.4 (l. 893-899) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** VERSION, UI, SCRIPT, COMPOSE, TIMELINE, EXPORT
- **Avhengigheter:** REQ-0305
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Et uavklart avvik på en scene vises i alle fem visningene.
- **Tester:**
  - e2e: avvik synlig i hver av de fem visningene
- **Implementering:** src/app/assembly/ScriptChanges.tsx, src/app/assembly/FilmTimeline.tsx (merker), src/app/script/ScriptPageView.tsx (merker), src/app/scene-editor/SceneEditorWorkspace.tsx (varsel), src/app/projects/ProjectOverview.tsx
- **Merknad:** Avvik skal ikke forstyrre ordinær manuslayout (jf. kap. 6.3) – derfor «manusrelaterte arbeidsvisninger».

#### REQ-0316 – Aldri kassere produksjonsversjoner
Programmet skal aldri automatisk kassere eksisterende produksjonsversjoner.

- **Kilde:** Kap. 21.5 (l. 900-901) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** VERSION, SECURITY · **Invarianter:** INV-07, INV-14
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Ingen automatisk prosess (opprydding, regenerering, import) sletter produksjonsversjoner.
- **Tester:**
  - dataintegritet: antall versjoner synker aldri uten eksplisitt brukerhandling
- **Implementering:** src/core/commands/apply.ts, db/migrations/0001_core.sql#protect_takes
- **Merknad:** Ufravikelig prinsipp nr. 6 og 27 i kap. 34.

#### REQ-0317 – Åpne og gjenaktivere tidligere resultater
Tidligere produksjonsresultater skal kunne åpnes og gjenaktiveres.

- **Kilde:** Kap. 21.5 (l. 902) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 4
- **Moduler:** VERSION, TIMELINE · **Invarianter:** INV-14
- **Avhengigheter:** REQ-0316
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan åpne en tidligere versjon og gjøre den til aktiv versjon igjen.
- **Tester:**
  - e2e: gjenaktiver tidligere versjon
- **Implementering:** src/app/assembly/ClipPanel.tsx
- **Merknad:** Ufravikelig prinsipp nr. 6 i kap. 34.

#### REQ-0318 – Sammenligne tidligere resultater
Tidligere produksjonsresultater skal kunne sammenlignes.

- **Kilde:** Kap. 21.5 (l. 902) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** VERSION, UI
- **Avhengigheter:** REQ-0317
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan vise to versjoner av en scene side ved side.
- **Tester:**
  - e2e: sammenligning av to versjoner
- **Implementering:** src/app/library/ImageCompareDialog.tsx, src/app/assembly/CompareTakesDialog.tsx, src/core/assembly/compare.ts, src/app/assembly/CompareVersionsDialog.tsx

### Kapittel 22

#### REQ-0319 – Rådgivende kontinuitetsanalyse
Systemet skal kunne tilby rådgivende kontinuitetsanalyse av manus og produksjon.

- **Kilde:** Kap. 22 (l. 904-905) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** CONTINUITY, SCRIPT
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan kjøre kontinuitetsanalyse og få en liste med funn som kan avvises eller følges opp.
- **Tester:**
  - integrasjon: analyse på testmanus gir forventede funn
- **Implementering:** src/core/continuity/analysis.ts, src/app/continuity/ContinuityAnalysisPanel.tsx

#### REQ-0320 – Karakter omtalt før introduksjon
Kontinuitetsanalysen skal kunne oppdage at en karakter omtales før vedkommende introduseres.

- **Kilde:** Kap. 22 (l. 906-907) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** CONTINUITY, SCRIPT · **Invarianter:** INV-09
- **Avhengigheter:** REQ-0319
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et testmanus/-produksjon konstruert med dette problemet, så rapporterer analysen et funn som peker på riktig scene/manusblokk.
- **Tester:**
  - integrasjon: analyse av konstruert testtilfelle
- **Implementering:** src/core/continuity/analysis.ts, src/app/continuity/ContinuityAnalysisPanel.tsx

#### REQ-0321 – Objekt brukt før etablering
Kontinuitetsanalysen skal kunne oppdage at et objekt brukes før det etableres.

- **Kilde:** Kap. 22 (l. 908) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** CONTINUITY, SCRIPT
- **Avhengigheter:** REQ-0319
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et testmanus/-produksjon konstruert med dette problemet, så rapporterer analysen et funn som peker på riktig scene/manusblokk.
- **Tester:**
  - integrasjon: analyse av konstruert testtilfelle
- **Implementering:** src/core/continuity/analysis.ts, src/app/continuity/ContinuityAnalysisPanel.tsx

#### REQ-0322 – Dialog viser til deaktivert scene
Kontinuitetsanalysen skal kunne oppdage at dialog viser til en hendelse i en deaktivert scene.

- **Kilde:** Kap. 22 (l. 909) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** CONTINUITY, SCRIPT · **Invarianter:** INV-14
- **Avhengigheter:** REQ-0319
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et testmanus/-produksjon konstruert med dette problemet, så rapporterer analysen et funn som peker på riktig scene/manusblokk.
- **Tester:**
  - integrasjon: analyse av konstruert testtilfelle
- **Implementering:** src/core/continuity/analysis.ts, src/app/continuity/ContinuityAnalysisPanel.tsx

#### REQ-0323 – Fysisk forandring uten årsak
Kontinuitetsanalysen skal kunne oppdage at en fysisk forandring mangler årsak.

- **Kilde:** Kap. 22 (l. 910) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** CONTINUITY, SCRIPT · **Invarianter:** INV-09
- **Avhengigheter:** REQ-0319
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et testmanus/-produksjon konstruert med dette problemet, så rapporterer analysen et funn som peker på riktig scene/manusblokk.
- **Tester:**
  - integrasjon: analyse av konstruert testtilfelle
- **Implementering:** src/core/continuity/analysis.ts, src/app/continuity/ContinuityAnalysisPanel.tsx

#### REQ-0324 – Tidsmessige motsetninger i sceneorden
Kontinuitetsanalysen skal kunne oppdage at sceneorden skaper tidsmessige motsetninger.

- **Kilde:** Kap. 22 (l. 911) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** CONTINUITY, SCRIPT · **Invarianter:** INV-09
- **Avhengigheter:** REQ-0319
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et testmanus/-produksjon konstruert med dette problemet, så rapporterer analysen et funn som peker på riktig scene/manusblokk.
- **Tester:**
  - integrasjon: analyse av konstruert testtilfelle
- **Implementering:** src/core/continuity/analysis.ts, src/app/continuity/ContinuityAnalysisPanel.tsx

#### REQ-0325 – Spinoff mangler nødvendig informasjon
Kontinuitetsanalysen skal kunne oppdage at en spinoff mangler informasjon som tidligere var nødvendig for forståelsen.

- **Kilde:** Kap. 22 (l. 912) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** CONTINUITY, SCRIPT · **Invarianter:** INV-04
- **Avhengigheter:** REQ-0319
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et testmanus/-produksjon konstruert med dette problemet, så rapporterer analysen et funn som peker på riktig scene/manusblokk.
- **Tester:**
  - integrasjon: analyse av konstruert testtilfelle
- **Implementering:** src/core/continuity/analysis.ts (spinoff_gap), src/app/continuity/ContinuityAnalysisPanel.tsx
- **Merknad:** Avhenger av spinoff-modellen (kap. 24).

#### REQ-0326 – Ingen automatisk omskriving av historien
Systemet skal ikke automatisk omskrive historien.

- **Kilde:** Kap. 22 (l. 913) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** CONTINUITY, SCRIPT · **Invarianter:** INV-08
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Ingen analyse- eller AI-funksjon endrer manustekst uten eksplisitt brukerhandling.
- **Tester:**
  - dataintegritet: manus uendret etter kontinuitetsanalyse
- **Implementering:** src/core/continuity/analysis.ts, src/app/continuity/ContinuityAnalysisPanel.tsx, src/app/script/Inspector.tsx, src/app/assembly/ScriptChanges.tsx
- **Merknad:** Følger av kap. 2.2 og prinsipp nr. 27.

#### REQ-0327 – Brukeren har redaksjonell kontroll
Brukeren har alltid redaksjonell kontroll over manus og fortelling.

- **Kilde:** Kap. 22 (l. 914) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** CONTINUITY, SCRIPT, UI · **Invarianter:** INV-08
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Alle forslag fra systemet (kontinuitet, koblinger, rettelser) krever brukerens godkjenning før de påvirker manuset.
- **Tester:**
  - manuell: gjennomgang av forslagsflyter
- **Implementering:** src/app/script/Inspector.tsx, src/app/library/SuggestionsDialog.tsx, src/app/library/ContinuityPanel.tsx, src/app/assembly/ScriptChanges.tsx

### Kapittel 23

#### REQ-0328 – Norsk er hovedmanus
Norsk er prosjektets primære manusspråk og redaksjonelle hovedkilde.

- **Kilde:** Kap. 23.1 (l. 917-918) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** L10N, SCRIPT, CORE · **Invarianter:** INV-05
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Datamodellen markerer norsk som hovedspråk; andre språkversjoner refererer til norske manusobjekter.
- **Tester:**
  - enhet: språkversjon har referanse til hovedmanus
  - manuell: datamodellgjennomgang
- **Implementering:** src/core/model.ts, db/migrations/0001_core.sql, src/core/model.ts#PRIMARY_LANGUAGE, src/core/translation/index.ts, db/migrations/0016_translations.sql
- **Merknad:** Ufravikelig prinsipp nr. 5 i kap. 34.

#### REQ-0329 – Engelsk som tilknyttet språkversjon
Engelsk skal kunne legges til som en tilknyttet språkversjon av manuset.

- **Kilde:** Kap. 23.1 (l. 919) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** L10N, SCRIPT · **Invarianter:** INV-05
- **Avhengigheter:** REQ-0328
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan legge til en engelsk språkversjon som er koblet til de norske scene- og replikk-ID-ene.
- **Tester:**
  - integrasjon: opprett engelsk versjon koblet til norsk
- **Implementering:** src/core/translation/index.ts, src/core/commands/apply.ts (AddTranslations, UpdateTranslations, SetTranslationsRemoved), db/migrations/0016_translations.sql, src/app/script/ScriptWorkspace.tsx
- **Merknad:** Ufravikelig prinsipp nr. 5 (engelsk er tilknyttet) gjør koblingsprinsippet P0 i datamodellen, selve funksjonen er fase 7.

#### REQ-0330 – Varsle om oversettelse som må gjennomgås
Endringer i norsk hovedmanus skal kunne varsle om at engelsk oversettelse må gjennomgås.

- **Kilde:** Kap. 23.1 (l. 920) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** L10N, VERSION
- **Avhengigheter:** REQ-0329
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en norsk replikk endres, så flagges tilsvarende engelsk replikk som «må gjennomgås».
- **Tester:**
  - integrasjon: flagging av oversettelse ved norsk endring
- **Implementering:** src/core/translation/index.ts, src/core/commands/apply.ts (AddTranslations, UpdateTranslations, SetTranslationsRemoved), db/migrations/0016_translations.sql, src/app/script/TranslationPanel.tsx

#### REQ-0331 – Engelsk endrer ikke norsk
Endringer i engelsk oversettelse skal ikke automatisk endre norsk hovedmanus.

- **Kilde:** Kap. 23.1 (l. 921) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 7
- **Moduler:** L10N, SCRIPT · **Invarianter:** INV-06
- **Avhengigheter:** REQ-0329
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Etter redigering av engelsk replikk er norsk replikk uendret.
- **Tester:**
  - dataintegritet: norsk manus uendret etter engelsk redigering
- **Implementering:** src/core/translation/index.ts, src/core/commands/apply.ts (AddTranslations, UpdateTranslations, SetTranslationsRemoved), db/migrations/0016_translations.sql

#### REQ-0332 – Importere oversatt engelsk manus
Brukeren skal kunne importere et allerede oversatt engelsk manus.

- **Kilde:** Kap. 23.2 (l. 922-923) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** L10N, SCRIPT
- **Avhengigheter:** Manusimport (kap. 4.1)
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan importere engelsk manus (DOCX), og det parses som en språkversjon, ikke som et nytt hovedmanus.
- **Tester:**
  - import/eksport: import av engelsk referansemanus (DOCX)
- **Implementering:** src/core/translation/index.ts, src/core/commands/apply.ts (AddTranslations, UpdateTranslations, SetTranslationsRemoved), db/migrations/0016_translations.sql, src/app/script/TranslationImportDialog.tsx
- **Merknad:** Engelsk referansemanus (DOCX) er bekreftet tilgjengelig (jf. DEC-0002).

#### REQ-0333 – Automatisk kobling engelsk–norsk
Systemet skal forsøke å koble engelske scener, replikker og handlinger til eksisterende norske sceneidentiteter ved analyse av scenestruktur, karakterer, handling, narrativ kontekst og eventuelle scenenumre.

- **Kilde:** Kap. 23.2 (l. 924-930) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** L10N, SCRIPT, CORE · **Invarianter:** INV-02
- **Avhengigheter:** REQ-0332
- **Status:** Verifisert
- **Akseptansekriterier:**
  - For referansemanusene kobles en høy andel scener og replikker korrekt, og hver kobling har en sikkerhetsgrad.
- **Tester:**
  - integrasjon: koblingsnøyaktighet mot manuelt fasitsett for referansemanusene
- **Implementering:** src/core/translation/index.ts, src/core/commands/apply.ts (AddTranslations, UpdateTranslations, SetTranslationsRemoved), db/migrations/0016_translations.sql

#### REQ-0334 – Ikke bare scenenumre eller ordrett tekst
Koblingen mellom engelsk og norsk manus skal ikke baseres utelukkende på identiske scenenumre eller ordrett tekst.

- **Kilde:** Kap. 23.2 (l. 931) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** L10N · **Invarianter:** INV-02
- **Avhengigheter:** REQ-0333
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et engelsk manus der scenenumre er forskjøvet, så kobles scener likevel korrekt basert på innhold.
- **Tester:**
  - integrasjon: kobling med forskjøvne scenenumre
- **Implementering:** src/core/translation/index.ts, src/core/commands/apply.ts (AddTranslations, UpdateTranslations, SetTranslationsRemoved), db/migrations/0016_translations.sql

#### REQ-0335 – Manuell godkjenning av usikre koblinger
Usikre koblinger mellom engelsk og norsk manus skal kunne godkjennes manuelt.

- **Kilde:** Kap. 23.2 (l. 932) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** L10N, UI · **Invarianter:** INV-08
- **Avhengigheter:** REQ-0333
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Koblinger under en sikkerhetsterskel vises i en gjennomgangsliste der brukeren kan godkjenne, endre eller avvise.
- **Tester:**
  - e2e: gjennomgang av usikre koblinger
- **Implementering:** src/core/translation/index.ts, src/core/commands/apply.ts (AddTranslations, UpdateTranslations, SetTranslationsRemoved), db/migrations/0016_translations.sql, src/app/script/TranslationImportDialog.tsx, src/app/script/TranslationPanel.tsx

#### REQ-0336 – Delt produksjonsmateriale mellom språk
Norsk og engelsk film skal som hovedregel kunne bruke samme sceneidentiteter, samme visuelle komposisjoner, samme kamerabevegelser, samme miljøer, samme objekter og samme genererte filmklipp når de er egnede.

- **Kilde:** Kap. 23.3 (l. 933-940) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** L10N, CORE, TIMELINE
- **Avhengigheter:** REQ-0329
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Engelsk filmversjon refererer de samme scene-, komposisjons-, kamera-, miljø-, objekt- og klippobjektene som norsk, uten kopiering.
- **Tester:**
  - dataintegritet: delte referanser, ikke kopier
- **Implementering:** src/core/language/index.ts, src/core/audio/index.ts (clipLanguage, playsIn, filmAudio med språk), src/core/commands/apply.ts (language, languageImages, SetTakeAudioLanguage), db/migrations/0017_language_versions.sql, src/app/assembly/AssemblyWorkspace.tsx

#### REQ-0337 – Bytte språkavhengige ressurser
Språkavhengige ressurser skal kunne byttes separat per språkversjon.

- **Kilde:** Kap. 23.3 (l. 941) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** L10N, LIBRARY
- **Avhengigheter:** REQ-0336
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan bytte f.eks. et skilt med tekst eller et dialogklipp i engelsk versjon uten at norsk endres.
- **Tester:**
  - integrasjon: språkspesifikk overstyring av ressurs
- **Implementering:** src/core/language/index.ts, src/core/audio/index.ts (clipLanguage, playsIn, filmAudio med språk), src/core/commands/apply.ts (language, languageImages, SetTakeAudioLanguage), db/migrations/0017_language_versions.sql, src/app/scene-editor/LayerInspector.tsx

#### REQ-0338 – Flere språkspesifikke lydfiler per replikk
Hver replikk skal kunne ha flere språkspesifikke lydfiler.

- **Kilde:** Kap. 23.4 (l. 942-943) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** AUDIO, L10N
- **Avhengigheter:** REQ-0204
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En replikk kan ha både norsk og engelsk lydfil.
- **Tester:**
  - enhet: replikk–lydfil-relasjon per språk
- **Implementering:** src/core/language/index.ts, src/core/audio/index.ts (clipLanguage, playsIn, filmAudio med språk), src/core/commands/apply.ts (language, languageImages, SetTakeAudioLanguage), db/migrations/0017_language_versions.sql, src/app/assembly/AudioClipPanel.tsx, src/app/assembly/AddAudioDialog.tsx

#### REQ-0339 – Én narrativ replikk på tvers av språk
Tekster og lydfiler på ulike språk skal tilhøre samme underliggende narrative replikk (f.eks. replikk-ID dlg_294 med norsk «Hvor er Ola?» og engelsk «Where is Ola?»).

- **Kilde:** Kap. 23.4 (l. 944-948) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** AUDIO, L10N, CORE · **Invarianter:** INV-05
- **Avhengigheter:** REQ-0338
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Norsk og engelsk tekst og lyd for samme replikk deler én replikk-ID.
- **Tester:**
  - dataintegritet: språkvarianter refererer samme replikk-ID
- **Implementering:** src/core/translation/index.ts, src/core/commands/apply.ts (AddTranslations, UpdateTranslations, SetTranslationsRemoved), db/migrations/0016_translations.sql, src/core/language/index.ts, src/core/audio/index.ts (clipLanguage, playsIn, filmAudio med språk), src/core/commands/apply.ts (language, languageImages, SetTakeAudioLanguage), db/migrations/0017_language_versions.sql, src/core/translation/index.ts
- **Merknad:** Krever at replikk-ID finnes fra fase 1 (kap. 3.2).

#### REQ-0340 – Gjenbruk av ikke-dialoglyd
Musikk, atmosfære og lydeffekter skal i utgangspunktet kunne gjenbrukes mellom språkversjonene.

- **Kilde:** Kap. 23.5 (l. 949-950) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** AUDIO, L10N
- **Avhengigheter:** REQ-0200
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Engelsk versjon bruker samme musikk-, atmosfære- og effektspor som norsk uten kopiering.
- **Tester:**
  - integrasjon: delt ikke-dialoglyd mellom språk
- **Implementering:** src/core/language/index.ts, src/core/audio/index.ts (clipLanguage, playsIn, filmAudio med språk), src/core/commands/apply.ts (language, languageImages, SetTakeAudioLanguage), db/migrations/0017_language_versions.sql

#### REQ-0341 – Importert film med blandet lyd
Programmet skal kunne håndtere at importert ferdig film kan ha dialog og øvrig lyd blandet sammen.

- **Kilde:** Kap. 23.5 (l. 951) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** AUDIO, L10N, LIBRARY
- **Avhengigheter:** REQ-0235
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Importert film kan merkes som «blandet lydspor», og systemet håndterer da språkbytte uten å anta separat dialogspor.
- **Tester:**
  - integrasjon: språkversjon av scene med blandet lyd
- **Implementering:** src/core/language/index.ts, src/core/audio/index.ts (clipLanguage, playsIn, filmAudio med språk), src/core/commands/apply.ts (language, languageImages, SetTakeAudioLanguage), db/migrations/0017_language_versions.sql, src/app/assembly/ClipPanel.tsx

#### REQ-0342 – Ikke love perfekt dialogutskifting
Programmet skal ikke love perfekt utskifting av dialog dersom separate lydspor ikke finnes.

- **Kilde:** Kap. 23.5 (l. 952) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** AUDIO, L10N, UI
- **Avhengigheter:** REQ-0341
- **Status:** Verifisert
- **Akseptansekriterier:**
  - For scener med blandet lyd vises en tydelig begrensning ved språkbytte.
- **Tester:**
  - manuell: UI-tekst ved blandet lyd
- **Implementering:** src/core/language/index.ts, src/core/audio/index.ts (clipLanguage, playsIn, filmAudio med språk), src/core/commands/apply.ts (language, languageImages, SetTakeAudioLanguage), db/migrations/0017_language_versions.sql, src/app/assembly/LanguageVersionDialog.tsx, src/app/assembly/ExportAnimaticDialog.tsx

#### REQ-0343 – Identifisere timingkonflikter
Systemet skal kunne identifisere timingkonflikter som følge av at engelske replikker kan være lengre eller kortere enn norske, og foreslå justeringer.

- **Kilde:** Kap. 23.6 (l. 953-955) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** L10N, AUDIO, TIMELINE
- **Avhengigheter:** REQ-0339
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en engelsk replikk som er lengre enn tilgjengelig tidsintervall, så flagges konflikten med et forslag (f.eks. forlenge pause, justere klipp).
- **Tester:**
  - integrasjon: deteksjon av timingkonflikt
- **Implementering:** src/core/language/index.ts, src/core/audio/index.ts (clipLanguage, playsIn, filmAudio med språk), src/core/commands/apply.ts (language, languageImages, SetTakeAudioLanguage), db/migrations/0017_language_versions.sql, src/app/assembly/LanguageVersionDialog.tsx

#### REQ-0344 – Språktiming endrer ikke hovedfilm
Språkspesifikke timingendringer skal ikke automatisk endre hovedfilmens originale timing.

- **Kilde:** Kap. 23.6 (l. 956) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** L10N, TIMELINE · **Invarianter:** INV-06
- **Avhengigheter:** REQ-0343
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Etter timingjustering i engelsk versjon er norsk filmmontering uendret.
- **Tester:**
  - dataintegritet: norsk tidslinje uendret etter engelsk justering
- **Implementering:** src/core/language/index.ts, src/core/audio/index.ts (clipLanguage, playsIn, filmAudio med språk), src/core/commands/apply.ts (language, languageImages, SetTakeAudioLanguage), db/migrations/0017_language_versions.sql
- **Merknad:** INV-06 gjelder ordlyden manus; her brukes det analogt for filmtiming.

#### REQ-0345 – Skille materialtyper for leppesynk
Systemet skal ved språkbytte skille mellom stillbilder, enkle 2D-animatics, redigerbare 2D-karakterer, AI-generert video og ferdig importert film.

- **Kilde:** Kap. 23.7 (l. 957-963) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** L10N, VERSION, AUDIO
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Hvert klipp har en materialtype blant de fem, som brukes i vurdering av leppesynkbehov.
- **Tester:**
  - enhet: materialtype-klassifisering
- **Implementering:** src/core/language/index.ts, src/core/audio/index.ts (clipLanguage, playsIn, filmAudio med språk), src/core/commands/apply.ts (language, languageImages, SetTakeAudioLanguage), db/migrations/0017_language_versions.sql

#### REQ-0346 – Vurdere behov for leppesynk
Programmet skal vurdere om dialog kan byttes direkte (ofte for enkle animatics) eller om synlige munnbevegelser krever ny leppesynkronisering eller målrettet oppdatering.

- **Kilde:** Kap. 23.7 (l. 964-966) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** L10N, AUDIO, PROMPT
- **Avhengigheter:** REQ-0345
- **Status:** Verifisert
- **Akseptansekriterier:**
  - For et stillbilde foreslås direkte dialogbytte; for AI-video med synlig munn foreslås leppesynk/målrettet oppdatering.
- **Tester:**
  - integrasjon: anbefaling per materialtype
- **Implementering:** src/core/language/index.ts, src/core/audio/index.ts (clipLanguage, playsIn, filmAudio med språk), src/core/commands/apply.ts (language, languageImages, SetTakeAudioLanguage), db/migrations/0017_language_versions.sql, src/app/assembly/LanguageVersionDialog.tsx

#### REQ-0347 – Ingen automatisk full regenerering
Ved språkbytte skal programmet ikke automatisk regenerere hele scenen.

- **Kilde:** Kap. 23.7 (l. 966) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 7
- **Moduler:** L10N, QUEUE · **Invarianter:** INV-07, INV-12
- **Avhengigheter:** REQ-0346
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Språkbytte starter aldri en regenerering uten brukerens beslutning og kostnadsgodkjenning.
- **Tester:**
  - integrasjon: ingen jobber opprettes automatisk ved språkbytte
- **Implementering:** src/core/language/index.ts, src/core/audio/index.ts (clipLanguage, playsIn, filmAudio med språk), src/core/commands/apply.ts (language, languageImages, SetTakeAudioLanguage), db/migrations/0017_language_versions.sql

#### REQ-0348 – Språkspesifikk filmeksport
Brukeren skal kunne eksportere norsk film og engelsk film.

- **Kilde:** Kap. 23.8 (l. 967-970) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** EXPORT, L10N
- **Avhengigheter:** REQ-0336
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Eksport kan gjøres per språk og gir film med språkets dialog og ellers felles materiale.
- **Tester:**
  - import/eksport: norsk og engelsk filmeksport
- **Implementering:** src/core/language/index.ts, src/core/audio/index.ts (clipLanguage, playsIn, filmAudio med språk), src/core/commands/apply.ts (language, languageImages, SetTakeAudioLanguage), db/migrations/0017_language_versions.sql, src/app/assembly/ExportAnimaticDialog.tsx, src/engine/export/animatic.ts

#### REQ-0349 – Språkspesifikk manuseksport
Brukeren skal kunne eksportere norsk manus og engelsk manus.

- **Kilde:** Kap. 23.8 (l. 971-972) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** EXPORT, L10N, SCRIPT
- **Avhengigheter:** REQ-0329
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Manuseksport kan velges per språk med korrekt manusformat.
- **Tester:**
  - import/eksport: norsk og engelsk manuseksport
- **Implementering:** src/core/translation/index.ts, src/core/commands/apply.ts (AddTranslations, UpdateTranslations, SetTranslationsRemoved), db/migrations/0016_translations.sql, src/app/script/ExportDialog.tsx

#### REQ-0350 – Eksport av separate dialogspor
Brukeren skal kunne eksportere separate dialogspor.

- **Kilde:** Kap. 23.8 (l. 973) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** EXPORT, AUDIO, L10N
- **Avhengigheter:** REQ-0338
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Dialog kan eksporteres som egen lydfil per språk, adskilt fra musikk og effekter.
- **Tester:**
  - import/eksport: separat dialogspor
- **Implementering:** src/core/language/index.ts, src/core/audio/index.ts (clipLanguage, playsIn, filmAudio med språk), src/core/commands/apply.ts (language, languageImages, SetTakeAudioLanguage), db/migrations/0017_language_versions.sql, src/engine/export/audio-stem.ts, src/app/assembly/ExportAnimaticDialog.tsx

#### REQ-0351 – Eksport av undertekstfiler
Brukeren skal kunne eksportere undertekstfiler.

- **Kilde:** Kap. 23.8 (l. 974) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** EXPORT, L10N
- **Avhengigheter:** REQ-0339
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Undertekstfil genereres fra replikkenes tidskoblinger i aktiv film med korrekt timing.
- **Tester:**
  - import/eksport: undertekstfil validerer og har tider i samsvar med aktiv film
- **Implementering:** src/core/translation/index.ts, src/core/commands/apply.ts (AddTranslations, UpdateTranslations, SetTranslationsRemoved), db/migrations/0016_translations.sql, src/app/assembly/SubtitleDialog.tsx
- **Merknad:** Undertekstformat (SRT/VTT/annet) er ikke spesifisert.

#### REQ-0352 – Uavhengige språkvalg
Grensesnittspråk, manusspråk, dialogspråk og undertekstspråk skal kunne velges uavhengig av hverandre.

- **Kilde:** Kap. 23.8 (l. 975) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** L10N, UI, EXPORT
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt norsk UI, kan brukeren vise engelsk manus, spille av med norsk dialog og engelske undertekster.
- **Tester:**
  - e2e: kombinasjon av fire uavhengige språkvalg
- **Implementering:** src/core/translation/index.ts, src/core/commands/apply.ts (AddTranslations, UpdateTranslations, SetTranslationsRemoved), db/migrations/0016_translations.sql, src/app/assembly/SubtitleDialog.tsx, src/core/language/index.ts, src/core/audio/index.ts (clipLanguage, playsIn, filmAudio med språk), src/core/commands/apply.ts (language, languageImages, SetTakeAudioLanguage), db/migrations/0017_language_versions.sql, src/app/assembly/use-film-language.tsx, src/engine/compositor/film.ts (drawSubtitle)

### Kapittel 24

#### REQ-0353 – Avledede produksjoner i samme prosjekt
Animatic Studio skal støtte flere selvstendige produksjoner innenfor samme overordnede prosjekt. En avledet produksjon kan være: kortfilm, spinoff, trailer, teaser, pitchfilm, pilotsekvens, alternativ fortelling eller annen avgrenset filmversjon.

- **Kilde:** Kap. 24 (l. 977-987) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** CORE · **Invarianter:** INV-04
- **Avhengigheter:** Project Core med produksjonsbegrep (fase 1)
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et prosjekt med hovedfilm, når brukeren oppretter en avledet produksjon av hver av typene kortfilm, spinoff, trailer, teaser, pitchfilm, pilotsekvens, alternativ fortelling og annen avgrenset filmversjon, så finnes alle som selvstendige produksjoner i samme prosjekt.
- **Tester:**
  - enhet: produksjonstype-enum inneholder alle åtte typer
  - integrasjon: flere produksjoner under ett prosjekt-ID
- **Implementering:** src/core/production/index.ts, src/app/projects/ProductionList.tsx
- **Merknad:** Datamodellen (fase 1) må ha produksjon som eget objekt selv om funksjonen kommer i fase 7.

#### REQ-0354 – Opprette avledet produksjon fra utvalgte scener
Brukeren skal kunne opprette en avledet produksjon ved å velge ut scener fra hovedfilmen.

- **Kilde:** Kap. 24.1 (l. 988-989) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** CORE, TIMELINE, UI · **Invarianter:** INV-04
- **Avhengigheter:** REQ-0353
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt hovedfilmen med N scener, når brukeren velger M scener og oppretter en avledet produksjon, så inneholder den nye produksjonen sceneforekomster for nøyaktig de M valgte scenene, og hovedfilmen er uendret.
- **Tester:**
  - integrasjon: oppretting gir nye sceneforekomster som refererer samme scene-ID
  - e2e: velg scener og opprett spinoff
- **Implementering:** src/core/production/index.ts, src/app/projects/ProductionDialog.tsx

#### REQ-0355 – Egne egenskaper per avledet produksjon
Den nye avledede produksjonen skal kunne få: eget navn, egen sceneorden, eget manus, egen filmtidslinje, egen varighetsberegning, egne aktive filmversjoner og egne eksportfiler.

- **Kilde:** Kap. 24.1 (l. 990-997) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** CORE, SCRIPT, TIMELINE, EXPORT · **Invarianter:** INV-04
- **Avhengigheter:** REQ-0354
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en spinoff, så kan navn, sceneorden, manus, filmtidslinje, varighetsberegning, aktive filmversjoner og eksportfiler endres/beregnes uten at tilsvarende verdier i hovedfilmen endres.
- **Tester:**
  - enhet: varighetsberegning per produksjon
  - dataintegritet: endring i spinoffens egenskaper berører ikke hovedfilmen
- **Implementering:** src/core/production/index.ts, src/app/project/use-production.tsx, src/app/projects/ProductionDialog.tsx
- **Merknad:** Sceneorden, manus og egne versjoner er testet, men eget navn (kan bare settes ved opprettelse), egen varighetsberegning og egne eksportfiler per produksjon har ingen egne tester.

#### REQ-0356 – Flytte/skjule scene i spinoff uavhengig av hovedfilm
En scene skal kunne flyttes eller skjules i en spinoff uten at den flyttes eller skjules i hovedfilmen.

- **Kilde:** Kap. 24.2 (l. 998-999) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** CORE, TIMELINE · **Invarianter:** INV-04, INV-14
- **Avhengigheter:** REQ-0354
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en scene brukt i både hovedfilm og spinoff, når brukeren flytter eller skjuler den i spinoffen, så er dens plassering og synlighet i hovedfilmen uendret.
- **Tester:**
  - dataintegritet: sceneforekomster per produksjon er uavhengige
  - e2e: skjul scene i spinoff, kontroller hovedfilm
- **Implementering:** src/core/production/index.ts

#### REQ-0357 – Spinoffens manus og tidslinje synkronisert
Spinoffens manus og filmtidslinje skal likevel være fullt synkronisert med hverandre.

- **Kilde:** Kap. 24.2 (l. 1000) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P0 · **Fase:** 7
- **Moduler:** CORE, SCRIPT, TIMELINE · **Invarianter:** INV-01
- **Avhengigheter:** REQ-0356
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en spinoff, når en scene flyttes eller deaktiveres i spinoffens manus, så vises samme endring i spinoffens filmtidslinje (og omvendt), i samme transaksjon.
- **Tester:**
  - integrasjon: toveis strukturell synk per produksjon
  - dataintegritet: ingen tilstand der spinoffens manus og tidslinje har ulik aktiv struktur
- **Implementering:** src/core/production/index.ts
- **Merknad:** Anvendelse av kap. 2/INV-01 på hver produksjon.

#### REQ-0358 – Egen aktiv scene- og monteringsstruktur per produksjon
Hver produksjon skal ha sin egen aktive scene- og monteringsstruktur.

- **Kilde:** Kap. 24.2 (l. 1001) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** CORE, TIMELINE · **Invarianter:** INV-04
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt to produksjoner i samme prosjekt, så har hver sin egen liste over aktive sceneforekomster og sin egen filmmontering.
- **Tester:**
  - enhet: datamodell knytter filmmontering og sceneforekomster til produksjon-ID
- **Implementering:** src/core/model.ts, src/core/views.ts#orderedOccurrences, src/core/assembly/film.ts#filmClips
- **Merknad:** Formulert som konstatering («har dermed»); registrert som arkitekturkrav. Må støttes av datamodellen i fase 1.

#### REQ-0359 – Gjenbruk av materiale i spinoff
Spinoffen skal kunne gjenbruke: manusscener, ferdige filmklipp, AI-genererte scener, 2D-animatics, karakterer, objekter, lokasjoner, lyd og stilprofiler.

- **Kilde:** Kap. 24.3 (l. 1002-1012) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** CORE, LIBRARY, TIMELINE, AUDIO · **Invarianter:** INV-04
- **Avhengigheter:** REQ-0354
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en spinoff, så kan hver av ressurstypene manusscener, ferdige filmklipp, AI-genererte scener, 2D-animatics, karakterer, objekter, lokasjoner, lyd og stilprofiler fra prosjektet brukes i spinoffen.
- **Tester:**
  - integrasjon: gjenbruk av hver ressurstype i spinoff
  - e2e: bygg spinoff kun av gjenbrukt materiale
- **Implementering:** src/core/production/index.ts
- **Merknad:** Gjenbruk av scener, ferdige filmklipp og 2D-scener er testet, men ikke hver av de ni ressurstypene (bl.a. lyd og stilprofiler) i en spinoff.

#### REQ-0360 – Referansebasert gjenbruk av versjonert kildemateriale
Gjenbruk skal i utgangspunktet være basert på referanser til versjonert kildemateriale, slik at unødvendig duplisering unngås.

- **Kilde:** Kap. 24.3 (l. 1013) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** CORE, VERSION, LIBRARY · **Invarianter:** INV-13
- **Avhengigheter:** Version & Dependency Engine
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et filmklipp gjenbrukt i en spinoff, så lagres en referanse til klippets versjons-ID og ikke en kopi av mediefilen.
  - Gitt at kildematerialet får ny versjon, så peker spinoffens referanse fortsatt på den versjonen den ble koblet til inntil brukeren velger annet.
- **Tester:**
  - dataintegritet: ingen duplisert mediefil ved gjenbruk
  - enhet: referanse inneholder versjons-ID
- **Implementering:** src/core/production/index.ts
- **Merknad:** «i utgangspunktet» – standardatferd, unntak tillatt.

#### REQ-0361 – Nye scener som bare finnes i spinoffen
Brukeren skal kunne skrive og produsere helt nye scener som bare finnes i spinoffen.

- **Kilde:** Kap. 24.4 (l. 1014-1015) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** SCRIPT, CORE · **Invarianter:** INV-04
- **Avhengigheter:** REQ-0354
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en spinoff, når brukeren skriver en ny scene der, så vises scenen i spinoffens manus og tidslinje og ikke i noen annen produksjon.
- **Tester:**
  - e2e: skriv og produser ny scene i spinoff
- **Implementering:** src/app/script/ScriptWorkspace.tsx

#### REQ-0362 – Permanente identiteter for spinoff-scener
Nye scener i spinoffen skal få egne permanente sceneidentiteter.

- **Kilde:** Kap. 24.4 (l. 1016) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** CORE · **Invarianter:** INV-02, INV-03
- **Avhengigheter:** REQ-0361
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en ny spinoff-scene, så får den en unik permanent scene-ID som er uavhengig av scenenummer og ikke kolliderer med hovedfilmens scene-ID-er.
- **Tester:**
  - enhet: ID-generering for spinoff-scene
  - dataintegritet: ID uendret etter flytting/omnummerering
- **Implementering:** src/core/commands/apply.ts (CreateScene)

#### REQ-0363 – Spinoff-scener legges ikke automatisk i hovedmanus
Nye scener i spinoffen skal ikke automatisk legges til hovedmanuset.

- **Kilde:** Kap. 24.4 (l. 1017) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 7
- **Moduler:** CORE, SCRIPT · **Invarianter:** INV-04
- **Avhengigheter:** REQ-0361
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en ny spinoff-scene, når den lagres, så er hovedmanuset og hovedfilmens tidslinje uendret.
- **Tester:**
  - dataintegritet: hovedmanusets scenesett før/etter er identisk
- **Implementering:** src/core/commands/apply.ts (CreateScene)
- **Merknad:** Gjentas som prinsipp 21 i kap. 34.

#### REQ-0364 – Spinoff-scener bruker globale ressurser og eget materiale
Nye spinoff-scener skal kunne bruke globale ressurser og få egne animatics, lydfiler og genererte filmklipp.

- **Kilde:** Kap. 24.4 (l. 1018) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** LIBRARY, COMPOSE, AUDIO, PROMPT
- **Avhengigheter:** REQ-0361
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en ny spinoff-scene, så kan brukeren knytte globale karakterer/objekter/miljøer til den og knytte egne animatics, lydfiler og genererte filmklipp til den.
- **Tester:**
  - integrasjon: globale ressurser tilgjengelige i spinoff-scene
- **Implementering:** src/app/scene-editor/SceneEditorWorkspace.tsx

#### REQ-0365 – Endring i gjenbrukt scene blir lokal variant
Hvis en gjenbrukt scene endres i spinoffen, skal endringen som standard lagres som en produksjonsspesifikk variant. Hovedfilmens scene skal ikke endres. Eksempel: spinoffen bruker en scene fra hovedfilmen, men forkorter dialogen og velger et annet kamerautsnitt.

- **Kilde:** Kap. 24.5 (l. 1019-1023) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P0 · **Fase:** 7
- **Moduler:** CORE, VERSION, SCRIPT · **Invarianter:** INV-04, INV-13
- **Avhengigheter:** REQ-0354
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en gjenbrukt scene, når brukeren forkorter dialogen og velger et annet kamerautsnitt i spinoffen, så opprettes en scenevariant knyttet til spinoffen, og hovedfilmens scene (manus, kamera) er uendret.
- **Tester:**
  - dataintegritet: hovedfilmens scene byte-lik før/etter spinoff-redigering
  - enhet: variant knyttet til produksjon-ID
- **Implementering:** src/core/production/index.ts, src/app/project/use-commands.ts

#### REQ-0366 – Variant tilhører spinoffen til brukeren deler
Den nye varianten tilhører spinoffen inntil brukeren eventuelt velger å dele endringene.

- **Kilde:** Kap. 24.5 (l. 1024) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** CORE, VERSION · **Invarianter:** INV-04
- **Avhengigheter:** REQ-0365
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en spinoff-variant, så er den bare synlig i spinoffen inntil brukeren eksplisitt velger å dele den.
- **Tester:**
  - integrasjon: deling krever eksplisitt brukerhandling
- **Implementering:** src/core/production/index.ts
- **Merknad:** Mekanismen for «dele» er beskrevet i kap. 25 (tilbakeføring).

#### REQ-0367 – Bruke utdrag av ferdig filmklipp
Brukeren skal kunne bruke bare deler av et ferdig filmklipp. En scene på 90 sekunder i hovedfilmen kan eksempelvis bidra med 20 sekunder i en trailer.

- **Kilde:** Kap. 24.6 (l. 1025-1027) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** TIMELINE
- **Avhengigheter:** REQ-0354
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et klipp på 90 s, når brukeren velger et utdrag på 20 s til en trailer, så spiller traileren nøyaktig det valgte tidsintervallet.
- **Tester:**
  - enhet: inn-/utpunkt på sceneforekomst
  - e2e: trailer med utdrag
- **Implementering:** src/core/commands/apply.ts (SetSceneEdit), src/app/assembly/ClipParts.tsx

#### REQ-0368 – Utdrag påvirker ikke originalfil
Bruk av utdrag fra et ferdig filmklipp skal ikke påvirke originalfilen.

- **Kilde:** Kap. 24.6 (l. 1028) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P0 · **Fase:** 7
- **Moduler:** TIMELINE, SECURITY · **Invarianter:** INV-13, INV-07
- **Avhengigheter:** REQ-0367
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et utdrag brukt i en trailer, så er originalfilens innhold, varighet og sjekksum uendret.
- **Tester:**
  - dataintegritet: sjekksum av original før/etter
- **Implementering:** src/core/commands/apply.ts (SetSceneEdit)

#### REQ-0369 – Varsel om narrative problemer i spinoff
Systemet skal kunne varsle når en spinoff kombinerer scener på en måte som skaper mulige narrative problemer.

- **Kilde:** Kap. 24.7 (l. 1029-1030) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** CONTINUITY
- **Avhengigheter:** REQ-0354; Continuity Engine (fase 6)
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en spinoff der en scene forutsetter en hendelse fra en utelatt scene, så vises et varsel om mulig narrativt problem.
- **Tester:**
  - integrasjon: kontinuitetsanalyse per produksjon
  - manuell: vurdering av varslenes relevans
- **Implementering:** src/core/continuity/analysis.ts (spinoff_gap), src/app/continuity/ContinuityAnalysisPanel.tsx

#### REQ-0370 – Opprette sammenbindende scener og overganger
Brukeren skal kunne opprette nye sammenbindende scener og overganger i en spinoff.

- **Kilde:** Kap. 24.7 (l. 1031) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** SCRIPT, TIMELINE
- **Avhengigheter:** REQ-0361
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en spinoff, så kan brukeren sette inn en ny sammenbindende scene eller en overgang mellom to sceneforekomster.
- **Tester:**
  - e2e: legg til overgang i spinoff
- **Implementering:** src/app/script/ScriptWorkspace.tsx (Skriv ny scene), src/core/commands/apply.ts (CreateScene, SetTransition)

#### REQ-0371 – Egne norske og engelske manus og lydspor for spinoff
Spinoffer skal kunne ha egne norske og engelske manus og lydspor.

- **Kilde:** Kap. 24.8 (l. 1032-1033) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** L10N, AUDIO, SCRIPT · **Invarianter:** INV-05, INV-06
- **Avhengigheter:** REQ-0354
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en spinoff, så kan den ha et eget norsk manus, et eget engelsk manus og egne lydspor per språk, uavhengig av hovedfilmens.
- **Tester:**
  - integrasjon: språkversjoner per produksjon
- **Implementering:** src/core/language/index.ts, src/core/audio/index.ts (clipLanguage, playsIn, filmAudio med språk), src/core/commands/apply.ts (language, languageImages, SetTakeAudioLanguage), db/migrations/0017_language_versions.sql

#### REQ-0372 – Gjenbruk av eksisterende oversettelser i spinoff
Eksisterende oversettelser skal gjenbrukes der det passer.

- **Kilde:** Kap. 24.8 (l. 1034) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** L10N
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en gjenbrukt scene med eksisterende engelsk oversettelse, så foreslås/brukes denne oversettelsen i spinoffens engelske manus.
- **Tester:**
  - integrasjon: oversettelsesreferanse gjenbrukes
- **Implementering:** src/core/translation/index.ts, src/core/commands/apply.ts (AddTranslations, UpdateTranslations, SetTranslationsRemoved), db/migrations/0016_translations.sql, src/core/production/index.ts

### Kapittel 25

#### REQ-0373 – Foreslå tilbakeføring fra spinoff til hovedfilm
En forbedret scenevariant som er utviklet i en spinoff skal kunne foreslås overført til hovedfilmen.

- **Kilde:** Kap. 25 (l. 1036-1037) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** CORE, VERSION · **Invarianter:** INV-08
- **Avhengigheter:** REQ-0365
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en spinoff-variant, så kan brukeren starte et forslag om overføring til hovedfilmen.
- **Tester:**
  - e2e: start tilbakeføringsforslag
- **Implementering:** src/core/production/promote.ts, src/core/commands/apply.ts (ForkVariant.sourceVariantId, TransferScene, SetContinuityEventDisabled), src/app/projects/PromotionDialog.tsx

#### REQ-0374 – Tilbakeføring skjer aldri automatisk
Tilbakeføring fra spinoff til hovedfilm skal aldri skje automatisk.

- **Kilde:** Kap. 25 (l. 1038) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 7
- **Moduler:** CORE, VERSION · **Invarianter:** INV-04, INV-08
- **Avhengigheter:** REQ-0373
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt endringer i en spinoff-variant, så endres hovedfilmen ikke før brukeren har tatt en eksplisitt beslutning.
- **Tester:**
  - dataintegritet: hovedfilm uendret uten brukerbeslutning
- **Implementering:** src/core/production/promote.ts, src/core/commands/apply.ts (ForkVariant.sourceVariantId, TransferScene, SetContinuityEventDisabled), src/app/projects/PromotionDialog.tsx

#### REQ-0375 – Sammenligning original vs. spinoff-variant
Systemet skal ved tilbakeføring vise: originalscene, spinoff-variant, endringer i manus, endringer i lyd, endringer i kamera, endringer i timing og endringer i visuelt materiale.

- **Kilde:** Kap. 25.1 (l. 1039-1047) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** VERSION, UI
- **Avhengigheter:** REQ-0373
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en spinoff-variant med endringer i manus, lyd, kamera, timing og visuelt materiale, så viser sammenligningen originalscene, varianten og hver endringskategori separat.
- **Tester:**
  - integrasjon: diff-beregning per kategori
  - visuell: sammenligningsvisning
- **Implementering:** src/core/production/promote.ts, src/core/commands/apply.ts (ForkVariant.sourceVariantId, TransferScene, SetContinuityEventDisabled), src/app/projects/PromotionDialog.tsx

#### REQ-0376 – Beholde alt uendret
Brukeren skal kunne velge å beholde alt uendret.

- **Kilde:** Kap. 25.2 (l. 1050) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** CORE, VERSION, UI · **Invarianter:** INV-08
- **Avhengigheter:** REQ-0373
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et tilbakeføringsforslag, når brukeren velger «beholde alt uendret», så overføres nøyaktig det valgte (og ikke noe annet) til hovedfilmen, og alle relasjoner bevares.
- **Tester:**
  - integrasjon: selektiv tilbakeføring
  - dataintegritet: kun valgt kategori endret
- **Implementering:** src/core/production/promote.ts, src/core/commands/apply.ts (ForkVariant.sourceVariantId, TransferScene, SetContinuityEventDisabled), src/app/projects/PromotionDialog.tsx

#### REQ-0377 – Tilbakeføre bare manusendringer
Brukeren skal kunne velge å tilbakeføre bare manusendringer.

- **Kilde:** Kap. 25.2 (l. 1051) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** CORE, VERSION, UI · **Invarianter:** INV-08
- **Avhengigheter:** REQ-0373
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et tilbakeføringsforslag, når brukeren velger «tilbakeføre bare manusendringer», så overføres nøyaktig det valgte (og ikke noe annet) til hovedfilmen, og alle relasjoner bevares.
- **Tester:**
  - integrasjon: selektiv tilbakeføring
  - dataintegritet: kun valgt kategori endret
- **Implementering:** src/core/production/promote.ts, src/core/commands/apply.ts (ForkVariant.sourceVariantId, TransferScene, SetContinuityEventDisabled), src/app/projects/PromotionDialog.tsx

#### REQ-0378 – Tilbakeføre bestemte visuelle endringer
Brukeren skal kunne velge å tilbakeføre bestemte visuelle endringer.

- **Kilde:** Kap. 25.2 (l. 1052) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** CORE, VERSION, UI · **Invarianter:** INV-08
- **Avhengigheter:** REQ-0373
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et tilbakeføringsforslag, når brukeren velger «tilbakeføre bestemte visuelle endringer», så overføres nøyaktig det valgte (og ikke noe annet) til hovedfilmen, og alle relasjoner bevares.
- **Tester:**
  - integrasjon: selektiv tilbakeføring
  - dataintegritet: kun valgt kategori endret
- **Implementering:** src/core/production/promote.ts, src/core/commands/apply.ts (ForkVariant.sourceVariantId, TransferScene, SetContinuityEventDisabled), src/app/projects/PromotionDialog.tsx

#### REQ-0379 – Tilbakeføre lyd eller timing
Brukeren skal kunne velge å tilbakeføre lyd eller timing.

- **Kilde:** Kap. 25.2 (l. 1053) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** CORE, VERSION, UI · **Invarianter:** INV-08
- **Avhengigheter:** REQ-0373
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et tilbakeføringsforslag, når brukeren velger «tilbakeføre lyd eller timing», så overføres nøyaktig det valgte (og ikke noe annet) til hovedfilmen, og alle relasjoner bevares.
- **Tester:**
  - integrasjon: selektiv tilbakeføring
  - dataintegritet: kun valgt kategori endret
- **Implementering:** src/core/production/promote.ts, src/core/commands/apply.ts (ForkVariant.sourceVariantId, TransferScene, SetContinuityEventDisabled), src/app/projects/PromotionDialog.tsx

#### REQ-0380 – Ny hovedfilmvariant fra spinoff-versjon
Brukeren skal kunne velge å opprette en ny hovedfilmvariant fra spinoff-versjonen.

- **Kilde:** Kap. 25.2 (l. 1054) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** CORE, VERSION, UI · **Invarianter:** INV-08
- **Avhengigheter:** REQ-0373
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et tilbakeføringsforslag, når brukeren velger «ny hovedfilmvariant fra spinoff-versjon», så overføres nøyaktig det valgte (og ikke noe annet) til hovedfilmen, og alle relasjoner bevares.
- **Tester:**
  - integrasjon: selektiv tilbakeføring
  - dataintegritet: kun valgt kategori endret
- **Implementering:** src/core/production/promote.ts, src/core/commands/apply.ts (ForkVariant.sourceVariantId, TransferScene, SetContinuityEventDisabled), src/app/projects/PromotionDialog.tsx

#### REQ-0381 – Overføre ny spinoff-scene til hovedfilm
Brukeren skal kunne velge å overføre en helt ny spinoff-scene til hovedfilmen.

- **Kilde:** Kap. 25.2 (l. 1055) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** CORE, VERSION, UI · **Invarianter:** INV-08
- **Avhengigheter:** REQ-0373
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et tilbakeføringsforslag, når brukeren velger «overføre ny spinoff-scene til hovedfilm», så overføres nøyaktig det valgte (og ikke noe annet) til hovedfilmen, og alle relasjoner bevares.
- **Tester:**
  - integrasjon: selektiv tilbakeføring
  - dataintegritet: kun valgt kategori endret
- **Implementering:** src/core/production/promote.ts, src/core/commands/apply.ts (ForkVariant.sourceVariantId, TransferScene, SetContinuityEventDisabled), src/app/projects/PromotionDialog.tsx

#### REQ-0382 – Tilbakeføring overskriver ikke godkjent materiale
Ingen tilbakeføring skal overskrive eksisterende godkjent materiale uten en eksplisitt beslutning.

- **Kilde:** Kap. 25.2 (l. 1056) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P0 · **Fase:** 7
- **Moduler:** VERSION, CORE · **Invarianter:** INV-07, INV-13
- **Avhengigheter:** REQ-0373
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt godkjent materiale i hovedfilmen, når en tilbakeføring ville erstatte det, så kreves en eksplisitt bekreftelse, og uten den beholdes materialet.
- **Tester:**
  - dataintegritet: godkjent materiale uendret uten bekreftelse
- **Implementering:** src/core/production/promote.ts, src/core/commands/apply.ts (ForkVariant.sourceVariantId, TransferScene, SetContinuityEventDisabled), src/app/projects/PromotionDialog.tsx

#### REQ-0383 – Bevare relasjoner og historiske versjoner ved tilbakeføring
Alle relasjoner og historiske versjoner skal bevares ved tilbakeføring.

- **Kilde:** Kap. 25.2 (l. 1057) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P0 · **Fase:** 7
- **Moduler:** VERSION, CORE · **Invarianter:** INV-13
- **Avhengigheter:** REQ-0373
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en gjennomført tilbakeføring, så finnes original, spinoff-variant og ny hovedfilmversjon fortsatt, med sporbar relasjon mellom dem.
- **Tester:**
  - dataintegritet: versjonshistorikk komplett etter tilbakeføring
- **Implementering:** src/core/production/promote.ts, src/core/commands/apply.ts (ForkVariant.sourceVariantId, TransferScene, SetContinuityEventDisabled)

### Kapittel 26

#### REQ-0384 – Profesjonelle visuelle prosjektpresentasjoner
Animatic Studio skal kunne produsere profesjonelle visuelle presentasjoner av et filmprosjekt.

- **Kilde:** Kap. 26 (l. 1059-1060) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** PRESENT
- **Avhengigheter:** Resource Library; Project Core
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et prosjekt med karakterer og ressurser, så kan brukeren produsere en visuell presentasjon (plakat) av prosjektet.
- **Tester:**
  - e2e: generer presentasjon fra prosjekt
  - manuell: profesjonell kvalitet vurderes
- **Implementering:** src/core/presentation/poster.ts, src/core/presentation/relations.ts, src/core/presentation/metrics.ts, src/core/presentation/document.ts, src/app/release/PosterWorkspace.tsx

#### REQ-0385 – Presentasjon som egen eksportfunksjon
Produksjon av presentasjonsmateriell skal være en egen eksportfunksjon.

- **Kilde:** Kap. 26 (l. 1061) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** PRESENT, EXPORT
- **Avhengigheter:** REQ-0384
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Presentasjonseksport er tilgjengelig som egen funksjon atskilt fra film- og manuseksport.
- **Tester:**
  - integrasjon: presentasjonseksport via Export Engine
- **Implementering:** src/app/release/PosterWorkspace.tsx, src/app/release/PosterDialogs.tsx (ExportPosterDialog)

#### REQ-0386 – Plakatformat 70 × 100 cm stående
Programmet skal støtte minst plakatformatet 70 × 100 cm, stående format.

- **Kilde:** Kap. 26.1 (l. 1062-1065) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** PRESENT, EXPORT
- **Avhengigheter:** REQ-0384
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en plakat, når den eksporteres i 70 × 100 cm stående, så har filen korrekt fysisk størrelse og orientering.
- **Tester:**
  - import/eksport: kontroller sidestørrelse 700 × 1000 mm
- **Implementering:** src/core/presentation/poster.ts (POSTER_FORMATS)
- **Merknad:** Linje 1064 og 1065 er duplikat. «minst» – andre formater kan støttes.

#### REQ-0387 – Plakateksport for trykk og digital distribusjon
Plakateksporten skal kunne tilpasses profesjonell trykkproduksjon og digital distribusjon, med relevante innstillinger for: oppløsning, filformat, utfallende trykk, fargehåndtering og trykkegnet tekst og grafikk.

- **Kilde:** Kap. 26.1 (l. 1066-1072) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** PRESENT, EXPORT
- **Avhengigheter:** REQ-0384
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt eksportdialogen for plakat, så kan brukeren stille oppløsning, filformat, utfallende (bleed), fargehåndtering/fargeprofil og vektor-/trykkegnet tekst og grafikk.
  - Gitt trykkinnstillinger med utfallende, så inneholder filen bleed-område.
- **Tester:**
  - import/eksport: verifiser oppløsning, bleed og fargeprofil i eksportert fil
- **Implementering:** src/engine/export/poster-pdf.ts, src/engine/export/poster-canvas.ts

#### REQ-0388 – Kinopitch-plakat
Programmet skal kunne lage en kinopitch-plakat: en elegant, filmatisk og selgende plakat som fremhever filmens tittel, hovedkarakterer, stemning, visuelt univers, relevante miljøer, symbolske objekter og valgfri logline. Den skal ha et sterkt visuelt hierarki og profesjonell komposisjon.

- **Kilde:** Kap. 26.2 A (l. 1073-1083) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** PRESENT
- **Avhengigheter:** REQ-0384
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et prosjekt, når brukeren lager en kinopitch-plakat, så inneholder den tittel, hovedkarakterer, miljøer og symbolske objekter, og logline kan slås av/på.
- **Tester:**
  - visuell: komposisjon og hierarki vurderes
  - manuell: profesjonelt uttrykk
- **Implementering:** src/core/presentation/poster.ts (layoutPoster: pitch)

#### REQ-0389 – Karakter- og universkart
Programmet skal kunne lage et karakter- og universkart: en informativ plakat som viser karakterportretter, karakternavn, beskrivelser, relasjoner, sentrale objekter, viktige steder og eventuelle andre sentrale historieelementer. Det skal være en tydelig, visuelt attraktiv prosjektoversikt.

- **Kilde:** Kap. 26.2 B (l. 1084-1093) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** PRESENT
- **Avhengigheter:** REQ-0384
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et prosjekt med karakterer, relasjoner, objekter og steder, så viser karakterkartet portretter, navn, beskrivelser, relasjoner, objekter og steder.
- **Tester:**
  - visuell: karakterkart-layout
  - integrasjon: data hentes fra ressursbiblioteket
- **Implementering:** src/core/presentation/poster.ts (layoutPoster: character_map)

#### REQ-0390 – Valgfritt informasjonsnivå via avkrysning
Brukeren skal kunne velge plakatinnhold gjennom avkrysningsvalg som omfatter: bare bilder og navn, korte karakterbeskrivelser, utfyllende karakterbeskrivelser, relasjonslinjer, navngitte relasjoner, forklarende relasjonstekster, objektbilder, objektbeskrivelser, stedsbilder, stedsbeskrivelser, logline, sjanger og stemning, og andre relevante prosjektdata.

- **Kilde:** Kap. 26.3 (l. 1094-1109) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** PRESENT, UI
- **Avhengigheter:** REQ-0384
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt plakatredigering, så finnes et avkrysningsvalg for hver av de 13 innholdstypene, og plakaten oppdateres når valg endres.
- **Tester:**
  - e2e: slå hver avkrysning av/på og kontroller plakaten
- **Implementering:** src/core/presentation/poster.ts (defaultOptions, POSTER_OPTION_LABEL), src/app/release/PosterInspector.tsx

#### REQ-0391 – Layout tilpasses informasjonsmengde
Systemet skal justere plakatens layout til informasjonsmengden.

- **Kilde:** Kap. 26.3 (l. 1110) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** PRESENT
- **Avhengigheter:** REQ-0390
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt at brukeren legger til flere innholdstyper, så reflowes layouten uten overlapp eller avkuttet innhold.
- **Tester:**
  - visuell: layout ved minimum og maksimum informasjonsmengde
- **Implementering:** src/core/presentation/poster.ts (layoutPoster)

#### REQ-0392 – Varsel om redusert lesbarhet
Hvis innholdet blir for omfattende, skal programmet varsle om redusert lesbarhet eller foreslå en annen komposisjon.

- **Kilde:** Kap. 26.3 (l. 1111) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** PRESENT, UI
- **Avhengigheter:** REQ-0390
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt så mye innhold at minste tekststørrelse faller under definert terskel for formatet, så vises et varsel om redusert lesbarhet eller et forslag om annen komposisjon.
- **Tester:**
  - enhet: lesbarhetsterskel
  - visuell: varsel vises
- **Implementering:** src/core/presentation/poster.ts (posterChecks, minReadablePt), src/app/release/PosterInspector.tsx (PosterChecksList)

#### REQ-0393 – Visuelt relasjonskart med relasjonstyper
Karakterrelasjoner skal kunne fremstilles visuelt. Programmet skal støtte forbindelser som familie, vennskap, konflikt, omsorg, romantikk, mentorforhold, skjulte forbindelser og andre brukerdefinerte relasjoner.

- **Kilde:** Kap. 26.4 (l. 1112-1122) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** PRESENT, LIBRARY
- **Avhengigheter:** REQ-0384
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt karakterer med relasjoner av hver type, inkludert en brukerdefinert type, så vises de som visuelle forbindelser i relasjonskartet.
- **Tester:**
  - enhet: relasjonstyper inkl. brukerdefinert
  - visuell: relasjonslinjer
- **Implementering:** src/core/presentation/relations.ts, src/core/presentation/poster.ts (relasjonslinjer)

#### REQ-0394 – Relasjonsforslag uten usikre antakelser som fakta
Systemet kan foreslå relasjoner basert på manus, men skal ikke presentere usikre antakelser som fakta.

- **Kilde:** Kap. 26.4 (l. 1123) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** PRESENT, SCRIPT, PROMPT
- **Avhengigheter:** REQ-0393
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt automatisk foreslåtte relasjoner, så er de tydelig merket som forslag (ikke godkjent) inntil brukeren godkjenner dem.
- **Tester:**
  - integrasjon: forslag har status «foreslått»
  - manuell: merking er tydelig
- **Implementering:** src/core/presentation/relations.ts (relationSuggestions), src/app/release/RelationsDialog.tsx
- **Merknad:** «kan foreslå» = valgfritt; forbudet mot å presentere antakelser som fakta er absolutt når funksjonen finnes.

#### REQ-0395 – Godkjenne og redigere relasjoner
Brukeren skal kunne godkjenne og redigere relasjonene.

- **Kilde:** Kap. 26.4 (l. 1124) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** PRESENT, LIBRARY
- **Avhengigheter:** REQ-0393
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en foreslått relasjon, så kan brukeren godkjenne, endre type/tekst eller forkaste den.
- **Tester:**
  - e2e: godkjenn og rediger relasjon
- **Implementering:** src/app/release/RelationsDialog.tsx, src/core/commands/apply.ts (AddRelations, UndoAddRelations, UpdateRelations, SetRelationsRemoved, CreatePoster, UndoCreatePoster, UpdatePoster, SetPosterRemoved)

#### REQ-0396 – Automatisk førsteutkast til plakat
Programmet skal kunne analysere prosjektet og foreslå: hvilke karakterer som bør fremheves, hvilke miljøer som er viktigst, hvilke objekter som er sentrale, hvilke relasjoner som bør vises, hvilken komposisjon som passer og hvilken visuell stil som bør brukes.

- **Kilde:** Kap. 26.5 (l. 1125-1132) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** PRESENT, PROMPT, SCRIPT
- **Avhengigheter:** REQ-0384
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et prosjekt, når brukeren ber om førsteutkast, så foreslås karakterer, miljøer, objekter, relasjoner, komposisjon og visuell stil, alle redigerbare før bruk.
- **Tester:**
  - integrasjon: analyse av prosjektdata gir forslag i alle seks kategorier
- **Implementering:** src/core/presentation/poster.ts (posterAnalysis, posterDraft), src/app/release/PosterDialogs.tsx (NewPosterDialog)

#### REQ-0397 – Redigerbar plakat etter generering
Etter generering skal brukeren kunne justere: bilder, tekst, typografi, farger, plassering, skalering, relasjonslinjer, synlighet og komposisjon.

- **Kilde:** Kap. 26.6 (l. 1133-1143) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** PRESENT, UI
- **Avhengigheter:** REQ-0384
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en generert plakat, så kan brukeren endre hver av bilder, tekst, typografi, farger, plassering, skalering, relasjonslinjer, synlighet og komposisjon.
- **Tester:**
  - e2e: endre hver egenskap og lagre
- **Implementering:** src/app/release/PosterWorkspace.tsx, src/app/release/PosterCanvas.tsx, src/app/release/PosterInspector.tsx

#### REQ-0398 – Separate redigerbare plakatelementer
Tekst og grafiske elementer i plakaten skal så langt mulig være separate redigerbare elementer.

- **Kilde:** Kap. 26.6 (l. 1144) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** PRESENT
- **Avhengigheter:** REQ-0397
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en lagret plakat, så er tekst og grafiske elementer lagret som separate objekter som kan redigeres enkeltvis.
- **Tester:**
  - dataintegritet: plakatmodell har separate element-objekter
- **Implementering:** src/core/model.ts (PosterDocument, PosterElement)
- **Merknad:** «så langt mulig».

#### REQ-0399 – AI-bakgrunn ikke eneste lagringsform
AI-genererte bakgrunnsbilder skal ikke være den eneste lagringsformen for plakaten.

- **Kilde:** Kap. 26.6 (l. 1145) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** PRESENT
- **Avhengigheter:** REQ-0397
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en plakat med AI-generert bakgrunn, så finnes en strukturert plakatmodell (lag/elementer) i tillegg til bildet, og plakaten kan gjenoppbygges fra den.
- **Tester:**
  - dataintegritet: plakat kan åpnes og redigeres uten å regenerere bakgrunnen
- **Implementering:** src/core/model.ts (PosterDocument), db/migrations/0019_presentation.sql

#### REQ-0400 – Stilharmonisering av karakterbilder i plakat
Plakatmodulen skal kunne harmonisere karakterbilder til samme tegnestil, lyssetting og fargepalett.

- **Kilde:** Kap. 26.7 (l. 1146-1147) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** PRESENT, PROMPT, PROVIDER · **Invarianter:** INV-12
- **Avhengigheter:** REQ-0384; Prompt Orchestration og Provider Adapters (fase 5)
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Gitt karakterbilder i ulike stiler, når brukeren harmoniserer, så produseres nye versjoner i felles tegnestil, lyssetting og fargepalett uten at originalene endres.
- **Tester:**
  - integrasjon: harmonisering lager nye versjoner
  - manuell: visuell konsistens

#### REQ-0401 – Valg av kvalitetsnivå og modell for harmonisering
Brukeren skal kunne velge ønsket kvalitetsnivå og modell for stilharmonisering.

- **Kilde:** Kap. 26.7 (l. 1148) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** QUALITYCOST, PRESENT · **Invarianter:** INV-12
- **Avhengigheter:** REQ-0400
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Gitt harmonisering, så kan brukeren velge modell og kvalitetsnivå før kjøring.
- **Tester:**
  - integrasjon: valg sendes til Quality & Cost Engine

#### REQ-0402 – Publisere harmoniserte bilder til globalt bibliotek
Vellykkede harmoniserte bilder skal kunne publiseres til det globale ressursbiblioteket som nye godkjente stilvarianter.

- **Kilde:** Kap. 26.7 (l. 1149) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** LIBRARY, PRESENT, VERSION · **Invarianter:** INV-13
- **Avhengigheter:** REQ-0400
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Gitt et harmonisert bilde, når brukeren godkjenner og publiserer, så finnes det som ny stilvariant på karakteren i det globale biblioteket, og eksisterende varianter er uendret.
- **Tester:**
  - integrasjon: ny stilvariant opprettes
  - dataintegritet: eksisterende varianter uendret

#### REQ-0403 – Flere plakatvarianter for hovedfilm og spinoffer
Brukeren skal kunne lage og lagre flere plakatvarianter, både for hovedfilm og spinoffer.

- **Kilde:** Kap. 26.8 (l. 1150-1152) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** PRESENT, CORE
- **Avhengigheter:** REQ-0384
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt hovedfilm og en spinoff, så kan brukeren lagre flere plakatvarianter knyttet til hver produksjon.
- **Tester:**
  - enhet: plakat knyttet til produksjon-ID
  - e2e: flere varianter lagres og gjenåpnes
- **Implementering:** src/app/release/PosterWorkspace.tsx (plakater per produksjon)

#### REQ-0404 – Plakater på norsk og engelsk
Plakater skal kunne eksporteres på norsk og engelsk.

- **Kilde:** Kap. 26.8 (l. 1153) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** PRESENT, L10N, EXPORT
- **Avhengigheter:** REQ-0384
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en plakat, så kan den eksporteres i norsk og engelsk språkversjon med oversatt tekst.
- **Tester:**
  - import/eksport: plakat i to språk
- **Implementering:** src/core/presentation/poster.ts (LocalizedText, elementText), src/app/release/PosterInspector.tsx (Bilingual)

### Kapittel 27

#### REQ-0405 – Hovedoversikt over prosjektets tilstand
Animatic Studio skal gi brukeren kontinuerlig oversikt over prosjektets tilstand. Hovedoversikten skal blant annet vise: produksjoner i prosjektet, antall scener, total estimert spilletid, bekreftet spilletid, antall ferdige scener, scener under arbeid, scener som mangler produksjon, renderingsjobber, synkroniseringsavvik og API-kostnader.

- **Kilde:** Kap. 27.1 (l. 1155-1168) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** UI, CORE, QUEUE, QUALITYCOST, VERSION
- **Avhengigheter:** Varighetsestimering (kap. 7)
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et prosjekt, så viser hovedoversikten alle ti nøkkeltall, og de oppdateres når underliggende data endres.
- **Tester:**
  - integrasjon: aggregering av nøkkeltall
  - e2e: endre scenestatus og se oversikt oppdateres
- **Implementering:** src/core/assembly/status.ts#productionStatus, src/app/projects/DurationOverview.tsx, src/app/projects/ProjectOverview.tsx, src/app/ai/AiPanel.tsx, src/core/generation/cost.ts
- **Merknad:** Tallene for scener, varighet og avvik er testet i production-status.test.ts, men ingen test viser at oversikten viser alle ti nøkkeltall (jobber og API-kostnad ligger i AI-panelet).

#### REQ-0406 – Filtrering av oversikten
Brukeren skal kunne filtrere oversikten etter: produksjon, scene, karakter, objekt, status, ressursendring, språk og uavklarte avvik.

- **Kilde:** Kap. 27.2 (l. 1169-1178) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** UI, CORE
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt hovedoversikten, så kan brukeren filtrere på hvert av de åtte kriteriene og kombinere filtre.
- **Tester:**
  - enhet: filterlogikk
  - e2e: filtrer på karakter og status
- **Implementering:** src/core/assembly/status.ts#filterStatusRows, src/app/projects/DurationOverview.tsx
- **Merknad:** Mangler filter på ressursendring og språk.

#### REQ-0407 – Langvarige prosjekter uten tap av arbeid
Prosjektet skal bevare arbeidet over tid. Brukeren skal kunne forlate programmet og fortsette senere uten tap av: sceneoppbygging, historikk, genereringsprompter, ressurser, lyd, jobbstatus, eksportinnstillinger og produksjonsversjoner.

- **Kilde:** Kap. 27.3 (l. 1179-1189) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** CORE, SECURITY, QUEUE · **Invarianter:** INV-13
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et prosjekt med data i alle åtte kategorier, når brukeren lukker programmet og åpner det igjen (også på annen nettleserøkt), så er alle data intakte.
- **Tester:**
  - e2e: lukk/åpne og sammenlign tilstand
  - dataintegritet: persistens av alle kategorier
- **Implementering:** src/app/assembly/ExportAnimaticDialog.tsx, db/migrations/0027_review_export.sql
- **Merknad:** Jf. prinsipp 26.

### Kapittel 28

#### REQ-0408 – Brukerens kontroll over prosjektdata
Brukeren skal ha kontroll over prosjektdataene.

- **Kilde:** Kap. 28 (l. 1191-1192) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** SECURITY, CORE
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan se, eksportere, endre og slette sine prosjektdata.
- **Tester:**
  - manuell: gjennomgang av dataeierskap
- **Implementering:** src/core/backup/index.ts, src/adapters/storage/backup.functions.ts, src/adapters/storage/project-admin.functions.ts, src/app/projects/ProjectDangerDialogs.tsx

#### REQ-0409 – Vedvarende lagring av prosjektinformasjon
Prosjektinformasjon skal bevares til brukeren selv velger å endre eller slette den, innenfor tjenestens faktiske lagringsvilkår.

- **Kilde:** Kap. 28.1 (l. 1193-1194) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** SECURITY · **Invarianter:** INV-14
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt lagret prosjektinformasjon, så slettes den aldri automatisk av applikasjonen uten brukerens handling.
- **Tester:**
  - dataintegritet: ingen automatisk sletting
- **Implementering:** db/migrations/0001_core.sql, src/adapters/storage/project-rows.ts

#### REQ-0410 – Ikke kritiske data kun i nettlesertilstand
Kritisk produksjonsdata skal ikke bygges utelukkende på midlertidig nettlesertilstand.

- **Kilde:** Kap. 28.1 (l. 1195) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** SECURITY, CORE
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt at nettleserens lokale lagring tømmes, så er alle kritiske prosjektdata fortsatt tilgjengelige fra varig lagring.
- **Tester:**
  - e2e: tøm localStorage/IndexedDB og åpne prosjekt
- **Implementering:** src/adapters/storage/commands.functions.ts, src/adapters/storage/project-rows.ts

#### REQ-0411 – Portabel eksport/sikkerhetskopi av prosjekt
Prosjektet skal kunne eksporteres eller sikkerhetskopieres i et dokumentert, portabelt format.

- **Kilde:** Kap. 28.2 (l. 1196-1197) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** EXPORT, SECURITY
- **Avhengigheter:** Project Core
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et prosjekt, så kan det eksporteres til et dokumentert format, og formatet er beskrevet i dokumentasjon.
- **Tester:**
  - import/eksport: eksport → reimport gir likt prosjekt
- **Implementering:** src/core/backup/index.ts, src/app/projects/backup.ts, src/app/projects/BackupDialogs.tsx, src/adapters/storage/backup.functions.ts, docs/architecture/BACKUP_FORMAT.md
- **Merknad:** Fase ikke angitt i kap. 32; satt til fase 4 (eksport). Jf. prinsipp 28.

#### REQ-0412 – Innhold i sikkerhetskopi
Sikkerhetskopien skal så langt praktisk mulig omfatte: strukturert prosjektdata, manusversjoner, ressursreferanser, redigerbare scener, promptversjoner, kontinuitetsdata, produksjonshistorikk og relevante mediefiler eller en tydelig oversikt over eksterne avhengigheter.

- **Kilde:** Kap. 28.2 (l. 1198-1206) · **Opprinnelse:** mandat · **Type:** data · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** EXPORT, SECURITY, VERSION
- **Avhengigheter:** REQ-0411
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en sikkerhetskopi, så inneholder den alle åtte kategorier, eller en oversikt over eksterne mediefiler som ikke er inkludert.
- **Tester:**
  - import/eksport: innholdskontroll av backup
  - dataintegritet: reimport bevarer ID-er og relasjoner
- **Implementering:** src/core/backup/index.ts
- **Merknad:** «så langt praktisk mulig».

#### REQ-0413 – Sikker håndtering av API-nøkler
API-nøkler og andre hemmeligheter skal håndteres sikkert.

- **Kilde:** Kap. 28.3 (l. 1207-1208) · **Opprinnelse:** mandat · **Type:** sikkerhet · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** SECURITY, PROVIDER
- **Status:** Verifisert
- **Akseptansekriterier:**
  - API-nøkler lagres kryptert/i hemmelighetslager og eksponeres ikke i klientkode, eksportfiler eller backup i klartekst.
- **Tester:**
  - integrasjon: nøkkel ikke lesbar fra klient
  - manuell: sikkerhetsgjennomgang
- **Implementering:** src/adapters/ai/generate-image.functions.ts, src/adapters/ai/gateway.ts, src/integrations/supabase/client.server.ts, src/adapters/ai/key-vault.server.ts, src/adapters/ai/provider-keys.functions.ts
- **Merknad:** Bare én plattformnøkkel (LOVABLE_API_KEY) finnes, som hemmelighet i Lovable Cloud brukt fra serverfunksjoner; ingen automatisk test søker etter nøkler i klientbunt, backup eller logger.

#### REQ-0414 – Logging avslører ikke tilgangsopplysninger
Loggføring må ikke avsløre sensitive tilgangsopplysninger.

- **Kilde:** Kap. 28.3 (l. 1209) · **Opprinnelse:** mandat · **Type:** sikkerhet · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** SECURITY
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et API-kall med nøkkel som feiler, så inneholder ingen logglinje nøkkelen eller andre hemmeligheter.
- **Tester:**
  - enhet: logg-redigering av hemmeligheter
  - integrasjon: søk etter nøkkel i logger
- **Implementering:** src/adapters/storage/commands.functions.ts, src/adapters/ai/gateway.ts#gatewayError, src/adapters/ai/video-followup.server.ts
- **Merknad:** Feilmeldinger og logglinjer tar ikke med nøkkelen, men ingen test sjekker logglinjer ved feilet API-kall.

#### REQ-0415 – Skille mellom lagringskategorier
Systemet må skille mellom: redigerbare prosjektdata, kildemedier, genererte mediefiler, midlertidige renderingsfiler, eksportfiler og historiske versjoner. Dette er nødvendig for pålitelig lagring, backup og senere migrering.

- **Kilde:** Kap. 28.4 (l. 1210-1218) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** SECURITY, CORE
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Hver lagret fil/post er klassifisert i én av de seks kategoriene, og kategoriene lagres atskilt.
- **Tester:**
  - enhet: lagringsklassifisering
  - dataintegritet: midlertidige filer kan slettes uten tap av andre kategorier
- **Implementering:** src/core/library/storage-paths.ts, src/core/library/storage.ts, src/app/projects/StorageSection.tsx

### Kapittel 29

#### REQ-0416 – Eksport som selvstendig modul uten AI
Eksport skal være en selvstendig modul som ikke krever nye AI-genereringer for å bruke eksisterende materiale.

- **Kilde:** Kap. 29 (l. 1220-1221) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P0 · **Fase:** 4
- **Moduler:** EXPORT · **Invarianter:** INV-11
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et prosjekt uten AI-leverandør konfigurert, så kan eksisterende materiale eksporteres uten feil og uten AI-kall.
- **Tester:**
  - integrasjon: eksport med AI-adaptere deaktivert
- **Implementering:** src/engine/export/animatic.ts

#### REQ-0417 – Filmeksport av ulike omfang
Brukeren skal kunne eksportere: én scene, valgte scener, en del av filmen, hele hovedfilmen, en spinoff, og en trailer eller pitchfilm.

- **Kilde:** Kap. 29.1 (l. 1222-1229) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** EXPORT, TIMELINE
- **Avhengigheter:** REQ-0416
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et prosjekt, så kan brukeren eksportere hvert av de seks omfangene, og eksportert varighet samsvarer med valgt omfang.
- **Tester:**
  - import/eksport: eksport per omfang
  - e2e: eksporter valgte scener
- **Implementering:** src/core/assembly/film.ts, src/app/assembly/ExportAnimaticDialog.tsx, src/app/project/use-production.tsx, src/app/projects/ProductionDialog.tsx, src/core/assembly/film.ts#filmSelection
- **Merknad:** Spinoff/trailer-eksport avhenger av fase 7.

#### REQ-0418 – Hybrid eksport av blandet materiale
Eksportmotoren skal kunne kombinere: lokal 2D-animasjon, AI-generert film, importert ferdig film, stillbilder, dialog, musikk og lydeffekter.

- **Kilde:** Kap. 29.2 (l. 1230-1238) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** EXPORT, COMPOSE, AUDIO
- **Avhengigheter:** REQ-0416
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en tidslinje med alle sju materialtyper, så produserer eksporten én sammenhengende fil med korrekt rekkefølge og lydmiks.
- **Tester:**
  - import/eksport: hybrid eksport
  - visuell: kontroller overganger
- **Implementering:** src/engine/export/animatic.ts, src/app/assembly/ExportAnimaticDialog.tsx, src/engine/export/film-video.ts

#### REQ-0419 – Manuseksport med valgt nummerering
Systemet skal eksportere korrekt formatert manus med nummereringsmetode valgt ved hver eksport.

- **Kilde:** Kap. 29.3 (l. 1239-1240) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** EXPORT, SCRIPT · **Invarianter:** INV-02
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt manuseksport, så må brukeren velge nummereringsmetode ved hver eksport, og interne scene-ID-er er uendret etterpå.
- **Tester:**
  - import/eksport: manuseksport med to nummereringsmetoder
  - dataintegritet: ID-er uendret
- **Implementering:** src/app/script/ExportDialog.tsx, src/core/screenplay/numbering.ts
- **Merknad:** Jf. kap. 5.2 og prinsipp 4.

#### REQ-0420 – Språkeksport av film og manus
Systemet skal eksportere film og manus på valgte språk.

- **Kilde:** Kap. 29.4 (l. 1241-1242) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** EXPORT, L10N
- **Avhengigheter:** REQ-0416
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt norsk og engelsk språkversjon, så kan film og manus eksporteres på hvert valgt språk.
- **Tester:**
  - import/eksport: eksport per språk
- **Implementering:** src/core/translation/index.ts, src/core/commands/apply.ts (AddTranslations, UpdateTranslations, SetTranslationsRemoved), db/migrations/0016_translations.sql, src/core/language/index.ts, src/core/audio/index.ts (clipLanguage, playsIn, filmAudio med språk), src/core/commands/apply.ts (language, languageImages, SetTakeAudioLanguage), db/migrations/0017_language_versions.sql, src/app/assembly/ExportAnimaticDialog.tsx, src/app/script/ExportDialog.tsx

#### REQ-0421 – Plakateksport i trykk- og digitalformater
Systemet skal eksportere kinopitch-plakater og karakterkart i relevante trykk- og digitalformater.

- **Kilde:** Kap. 29.5 (l. 1243-1244) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** EXPORT, PRESENT
- **Avhengigheter:** REQ-0384
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en plakat og et karakterkart, så kan begge eksporteres i minst ett trykkformat og ett digitalformat.
- **Tester:**
  - import/eksport: plakat i trykk- og digitalformat
- **Implementering:** src/engine/export/poster-pdf.ts, src/engine/export/poster-canvas.ts

#### REQ-0422 – Eksportkontroll før eksport
Før eksport skal programmet kontrollere: aktiv sceneorden, skjulte scener, aktivt filmmateriale, manglende mediefiler, uavklarte manusavvik, relevante språkspor, total varighet og teknisk kompatibilitet.

- **Kilde:** Kap. 29.6 (l. 1245-1254) · **Opprinnelse:** mandat · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** EXPORT, VERSION
- **Avhengigheter:** REQ-0416
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et prosjekt med en manglende mediefil og et uavklart avvik, når brukeren starter eksport, så rapporteres begge før eksporten kjøres, sammen med resultatet av de øvrige kontrollene.
- **Tester:**
  - enhet: hver kontroll
  - e2e: eksportkontroll-rapport
- **Implementering:** src/app/assembly/ExportAnimaticDialog.tsx

#### REQ-0423 – Eksport tross avvik etter varsel
Brukeren skal kunne velge å eksportere selv om enkelte avvik er uavklarte, etter et tydelig varsel.

- **Kilde:** Kap. 29.6 (l. 1255) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** EXPORT, UI · **Invarianter:** INV-08
- **Avhengigheter:** REQ-0422
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt uavklarte avvik, så vises et tydelig varsel, og brukeren kan bekrefte og eksportere likevel.
- **Tester:**
  - e2e: eksport etter bekreftet varsel
- **Implementering:** src/app/assembly/ExportAnimaticDialog.tsx

### Kapittel 30

#### REQ-0424 – Helhetlig profesjonell visuell identitet
Animatic Studio skal ha en helhetlig profesjonell visuell identitet.

- **Kilde:** Kap. 30 (l. 1257-1258) · **Opprinnelse:** mandat · **Type:** design · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Alle skjermbilder bruker samme designsystem (farger, typografi, komponenter).
- **Tester:**
  - visuell: designgjennomgang på tvers av moduler
- **Implementering:** src/styles.css, docs/design/DESIGN_SYSTEM.md, src/app/projects/ProjectOverview.tsx
- **Merknad:** Alle skjermer bruker de samme tokenene i styles.css, men ingen automatisk test kontrollerer at designsystemet brukes overalt.

#### REQ-0425 – Foretrukket visuelt uttrykk
Det visuelle uttrykket skal fortrinnsvis ha: mørk eller dempet filmatisk arbeidsflate, god kontrast, tydelig typografisk hierarki, diskré og konsekvent fargebruk, velorganiserte paneler, profesjonelle tidslinjer, tydelig statusinformasjon og rolige og presise interaksjoner.

- **Kilde:** Kap. 30.1 (l. 1259-1268) · **Opprinnelse:** mandat · **Type:** design · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Designsystemet har mørk/dempet arbeidsflate, kontrast som oppfyller WCAG AA for tekst, definert typografisk skala og konsistente statusindikatorer.
- **Tester:**
  - visuell: kontrastmåling
  - manuell: designgjennomgang mot de åtte punktene
- **Implementering:** src/styles.css, docs/design/DESIGN_SYSTEM.md
- **Merknad:** Mørk flate og kontrast (AA, beregnet i DESIGN_SYSTEM.md) er på plass, men ingen automatisk kontrasttest finnes.

#### REQ-0426 – Unngå leketøy- eller AI-demo-uttrykk
Unngå et visuelt uttrykk som minner om et leketøy eller en tilfeldig AI-demo.

- **Kilde:** Kap. 30.1 (l. 1269) · **Opprinnelse:** mandat · **Type:** design · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Manuell designgjennomgang bekrefter at grensesnittet fremstår som et profesjonelt produksjonsverktøy.
- **Tester:**
  - manuell: designgjennomgang
- **Implementering:** docs/design/DESIGN_SYSTEM.md, src/styles.css, src/app/design/icons/AiGlyph.tsx

#### REQ-0427 – Logisk tilgang til hovedområder
Applikasjonen bør ha logisk tilgang til: 1) prosjektoversikt, 2) produksjonsvelger, 3) manus, 4) ressursbibliotek, 5) karakterkontinuitet, 6) sceneeditor, 7) kamera og tidslinje, 8) lyd og dialog, 9) AI-generering, 10) renderingskø, 11) overordnet filmmontering, 12) plakater og presentasjoner, 13) eksport, 14) prosjektinnstillinger.

- **Kilde:** Kap. 30.2 (l. 1270-1285) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Hvert av de 14 områdene kan nås fra hovednavigasjonen eller en logisk overordnet visning.
- **Tester:**
  - e2e: naviger til hvert område
- **Implementering:** src/app/shell/ProjectNav.tsx, src/app/projects/ProjectOverview.tsx, src/app/project/use-production.tsx
- **Merknad:** Alle 14 områdene kan nås (flere samlet på oversikten, i biblioteket og i monteringen), men ingen test går gjennom navigasjonen til hvert område.

#### REQ-0428 – Hovedområder som funksjonelle moduler, ikke faner
Hovedområdene er funksjonelle moduler, ikke nødvendigvis én separat navigasjonsfane for hver funksjon.

- **Kilde:** Kap. 30.2 (l. 1286) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** UI
- **Avhengigheter:** REQ-0427
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Informasjonsarkitekturen kan samle flere områder i én visning uten å bryte tilgangen til hvert område.
- **Tester:**
  - manuell: IA-gjennomgang
- **Implementering:** src/app/shell/ProjectNav.tsx, src/app/projects/ProjectOverview.tsx
- **Merknad:** Oversikten samler format, AI-jobber, budsjett og produksjoner i én visning; kravet er en designregel uten egen test.

#### REQ-0429 – Foreslå informasjonsarkitektur som reduserer kompleksitet
Utviklingspartneren skal foreslå en gjennomarbeidet informasjonsarkitektur som reduserer kompleksiteten for brukeren.

- **Kilde:** Kap. 30.2 (l. 1287) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** UI, PROCESS
- **Avhengigheter:** REQ-0427
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Et dokumentert IA-forslag (navigasjonsstruktur med begrunnelse) foreligger før UI-implementering av hovednavigasjonen.
- **Tester:**
  - manuell: IA-forslag gjennomgått av bruker

#### REQ-0430 – Norske funksjonsnavn i grensesnittet
Brukergrensesnittet skal kunne bruke norske funksjonsnavn som: Generer scene, Bruk denne, Ressursbibliotek, Manus, Sceneeditor, Filmtidslinje, Produksjonsoversikt, Eksporter, Spinoff, Godkjenn eksisterende film, Oppdater scene og Angre endring.

- **Kilde:** Kap. 30.3 (l. 1288-1301) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** UI, L10N
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Med norsk UI-språk vises de tolv angitte betegnelsene der funksjonene finnes.
- **Tester:**
  - enhet: norsk språkfil inneholder betegnelsene
  - visuell: UI-tekster

#### REQ-0431 – Engelske tekniske betegnelser internt
Engelske tekniske betegnelser kan brukes internt der det er hensiktsmessig.

- **Kilde:** Kap. 30.3 (l. 1302) · **Opprinnelse:** mandat · **Type:** ux · **Prioritet:** P3 · **Fase:** –
- **Moduler:** UI, PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Interne kode-/modulnavn kan være engelske uten at brukervendte tekster påvirkes.
- **Tester:**
  - manuell: kodegjennomgang
- **Merknad:** Tillatelse, ikke pålegg.

### Kapittel 31

#### REQ-0432 – Tydelig domeneseparasjon i arkitekturen
Utviklingen skal bygge på en tydelig separasjon mellom domener. Det skal foreslås og videreutvikles en arkitektur med minst de logiske komponentene i kap. 31. Modulene kan implementeres på ulike måter, men deres ansvarsområder bør være tydelig skilt.

- **Kilde:** Kap. 31 (l. 1304-1306, 1351) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** CORE, SCRIPT, TIMELINE, LIBRARY, CONTINUITY, COMPOSE, CAMERA, AUDIO, PROMPT, PROVIDER, QUALITYCOST, QUEUE, VERSION, L10N, PRESENT, EXPORT, SECURITY
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Arkitekturdokumentasjonen har én komponent per modul i kap. 31 med definert ansvarsområde og grensesnitt.
  - Ingen modul har direkte avhengighet til en annen moduls interne data utenom definerte grensesnitt.
- **Tester:**
  - manuell: arkitekturgjennomgang
  - enhet: avhengighetsregler (f.eks. lint/import-regler)
- **Implementering:** src/core/, src/adapters/, src/app/
- **Merknad:** Jf. kap. 1.2 og prinsipp 28.

#### REQ-0433 – Modul: Project Core
Arkitekturen skal ha en logisk komponent «Project Core» med ansvarsområdet: Prosjekter, produksjoner, identiteter og relasjoner.

- **Kilde:** Kap. 31 (l. 1307-1309) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** CORE
- **Avhengigheter:** REQ-0432
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Arkitekturdokumentasjonen definerer Project Core med ansvar for: prosjekter, produksjoner, identiteter og relasjoner, og dette ansvaret ligger ikke i andre moduler.
- **Tester:**
  - manuell: arkitekturgjennomgang av ansvarsgrenser
- **Implementering:** src/core/, docs/architecture/ARCHITECTURE.md, src/core/model.ts, src/core/ids.ts, src/core/commands/apply.ts, src/core/invariants.ts
- **Merknad:** Linje 1307/1308 duplikat.

#### REQ-0434 – Modul: Screenplay Engine
Arkitekturen skal ha en logisk komponent «Screenplay Engine» med ansvarsområdet: Import, parsing, strukturert manus, formatering, paginering, versjonering og eksport.

- **Kilde:** Kap. 31 (l. 1310-1312) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT
- **Avhengigheter:** REQ-0432
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Arkitekturdokumentasjonen definerer Screenplay Engine med ansvar for: import, parsing, strukturert manus, formatering, paginering, versjonering og eksport, og dette ansvaret ligger ikke i andre moduler.
- **Tester:**
  - manuell: arkitekturgjennomgang av ansvarsgrenser
- **Implementering:** docs/architecture/ARCHITECTURE.md, src/core/screenplay/parse.ts, src/core/screenplay/paginate.ts, src/core/screenplay/versions.ts, src/engine/import/pdf-lines.ts, src/engine/import/docx-lines.ts, src/engine/export/screenplay-pdf.ts, src/engine/export/screenplay-docx.ts
- **Merknad:** Linje 1310/1311 duplikat.

#### REQ-0435 – Modul: Timeline & Assembly Engine
Arkitekturen skal ha en logisk komponent «Timeline & Assembly Engine» med ansvarsområdet: Sceneforekomster, filmrekkefølge, tidskoder, klipp og sammenstilling.

- **Kilde:** Kap. 31 (l. 1313-1314) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** TIMELINE
- **Avhengigheter:** REQ-0432
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Arkitekturdokumentasjonen definerer Timeline & Assembly Engine med ansvar for: sceneforekomster, filmrekkefølge, tidskoder, klipp og sammenstilling, og dette ansvaret ligger ikke i andre moduler.
- **Tester:**
  - manuell: arkitekturgjennomgang av ansvarsgrenser
- **Implementering:** src/core/assembly/film.ts, docs/architecture/ARCHITECTURE.md, src/core/time.ts, src/core/views.ts, src/core/assembly/edit.ts

#### REQ-0436 – Modul: Resource Library
Arkitekturen skal ha en logisk komponent «Resource Library» med ansvarsområdet: Karakterer, objekter, miljøer, mediefiler og stilprofiler.

- **Kilde:** Kap. 31 (l. 1315-1317) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** LIBRARY
- **Avhengigheter:** REQ-0432
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Arkitekturdokumentasjonen definerer Resource Library med ansvar for: karakterer, objekter, miljøer, mediefiler og stilprofiler, og dette ansvaret ligger ikke i andre moduler.
- **Tester:**
  - manuell: arkitekturgjennomgang av ansvarsgrenser
- **Implementering:** src/core/library/, src/core/generation/style.ts, src/app/library/
- **Merknad:** Linje 1315/1316 duplikat.

#### REQ-0437 – Modul: Continuity Engine
Arkitekturen skal ha en logisk komponent «Continuity Engine» med ansvarsområdet: Narrativ kronologi, karaktertilstander, utseendeendringer og konsekvensanalyse.

- **Kilde:** Kap. 31 (l. 1318-1320) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** CONTINUITY
- **Avhengigheter:** REQ-0432
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Arkitekturdokumentasjonen definerer Continuity Engine med ansvar for: narrativ kronologi, karaktertilstander, utseendeendringer og konsekvensanalyse, og dette ansvaret ligger ikke i andre moduler.
- **Tester:**
  - manuell: arkitekturgjennomgang av ansvarsgrenser
- **Implementering:** src/core/continuity/index.ts, src/core/continuity/analysis.ts, src/core/library/impact.ts
- **Merknad:** Linje 1318/1319 duplikat.

#### REQ-0438 – Modul: 2D Composition Engine
Arkitekturen skal ha en logisk komponent «2D Composition Engine» med ansvarsområdet: Lag, transformasjoner, keyframes, multiplan-effekter og lokal avspilling.

- **Kilde:** Kap. 31 (l. 1321-1322) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** COMPOSE
- **Avhengigheter:** REQ-0432
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Arkitekturdokumentasjonen definerer 2D Composition Engine med ansvar for: lag, transformasjoner, keyframes, multiplan-effekter og lokal avspilling, og dette ansvaret ligger ikke i andre moduler.
- **Tester:**
  - manuell: arkitekturgjennomgang av ansvarsgrenser
- **Implementering:** docs/architecture/ARCHITECTURE.md, src/core/composition/render.ts, src/core/composition/animate.ts, src/core/composition/fields.ts, src/engine/compositor/canvas.ts

#### REQ-0439 – Modul: Camera & Motion Engine
Arkitekturen skal ha en logisk komponent «Camera & Motion Engine» med ansvarsområdet: Kamerautsnitt, baner, Bézier-kontroller og easing.

- **Kilde:** Kap. 31 (l. 1323-1324) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** CAMERA
- **Avhengigheter:** REQ-0432
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Arkitekturdokumentasjonen definerer Camera & Motion Engine med ansvar for: kamerautsnitt, baner, bézier-kontroller og easing, og dette ansvaret ligger ikke i andre moduler.
- **Tester:**
  - manuell: arkitekturgjennomgang av ansvarsgrenser
- **Implementering:** docs/architecture/ARCHITECTURE.md, src/core/composition/path.ts, src/core/composition/camera-handoff.ts, src/core/composition/animate.ts, src/core/composition/render.ts, src/app/scene-editor/CameraPanel.tsx

#### REQ-0440 – Modul: Audio Engine
Arkitekturen skal ha en logisk komponent «Audio Engine» med ansvarsområdet: Dialog, språkspor, musikk, lydeffekter og synkronisering.

- **Kilde:** Kap. 31 (l. 1325-1327) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** AUDIO
- **Avhengigheter:** REQ-0432
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Arkitekturdokumentasjonen definerer Audio Engine med ansvar for: dialog, språkspor, musikk, lydeffekter og synkronisering, og dette ansvaret ligger ikke i andre moduler.
- **Tester:**
  - manuell: arkitekturgjennomgang av ansvarsgrenser
- **Implementering:** src/engine/audio/mixer.ts, docs/architecture/ARCHITECTURE.md, src/core/audio/index.ts
- **Merknad:** Linje 1325/1326 duplikat.

#### REQ-0441 – Modul: Prompt Orchestration Engine
Arkitekturen skal ha en logisk komponent «Prompt Orchestration Engine» med ansvarsområdet: Automatisk sammensetting av engelskspråklige, modellspesifikke genereringsinstruksjoner.

- **Kilde:** Kap. 31 (l. 1328-1330) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** PROMPT
- **Avhengigheter:** REQ-0432
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Arkitekturdokumentasjonen definerer Prompt Orchestration Engine med ansvar for: automatisk sammensetting av engelskspråklige, modellspesifikke genereringsinstruksjoner, og dette ansvaret ligger ikke i andre moduler.
- **Tester:**
  - manuell: arkitekturgjennomgang av ansvarsgrenser
- **Implementering:** src/core/generation/image-prompt.ts, src/core/generation/scene-prompt.ts, docs/architecture/ARCHITECTURE.md, src/core/generation/prompt.ts, src/core/generation/model-prompt.ts, src/core/generation/prompt-writer.ts, src/core/generation/style.ts
- **Merknad:** Linje 1328/1329 duplikat.

#### REQ-0442 – Modul: Provider Adapters
Arkitekturen skal ha en logisk komponent «Provider Adapters» med ansvarsområdet: Integrasjoner med ulike AI-leverandører.

- **Kilde:** Kap. 31 (l. 1331-1333) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** PROVIDER
- **Avhengigheter:** REQ-0432
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Arkitekturdokumentasjonen definerer Provider Adapters med ansvar for: integrasjoner med ulike ai-leverandører, og dette ansvaret ligger ikke i andre moduler.
- **Tester:**
  - manuell: arkitekturgjennomgang av ansvarsgrenser
- **Implementering:** docs/architecture/ARCHITECTURE.md, src/adapters/ai/providers.server.ts, src/adapters/ai/gateway.ts, src/core/generation/providers.ts
- **Merknad:** Linje 1331/1332 duplikat.

#### REQ-0443 – Modul: Quality & Cost Engine
Arkitekturen skal ha en logisk komponent «Quality & Cost Engine» med ansvarsområdet: Modellvalg, kvalitetsprofiler, budsjettgrenser og kostnadsestimering.

- **Kilde:** Kap. 31 (l. 1334-1335) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** QUALITYCOST
- **Avhengigheter:** REQ-0432
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Arkitekturdokumentasjonen definerer Quality & Cost Engine med ansvar for: modellvalg, kvalitetsprofiler, budsjettgrenser og kostnadsestimering, og dette ansvaret ligger ikke i andre moduler.
- **Tester:**
  - manuell: arkitekturgjennomgang av ansvarsgrenser
- **Implementering:** src/core/generation/cost.ts, src/core/generation/providers.ts, src/adapters/ai/ai-gate.server.ts, src/app/ai/AiPanel.tsx

#### REQ-0444 – Modul: Render Queue
Arkitekturen skal ha en logisk komponent «Render Queue» med ansvarsområdet: Vedvarende genereringsjobber, status og feilhåndtering.

- **Kilde:** Kap. 31 (l. 1336-1337) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** QUEUE
- **Avhengigheter:** REQ-0432
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Arkitekturdokumentasjonen definerer Render Queue med ansvar for: vedvarende genereringsjobber, status og feilhåndtering, og dette ansvaret ligger ikke i andre moduler.
- **Tester:**
  - manuell: arkitekturgjennomgang av ansvarsgrenser
- **Implementering:** docs/architecture/ARCHITECTURE.md, src/core/generation/queue.ts, src/adapters/ai/queue.functions.ts, src/adapters/ai/video-followup.server.ts, src/routes/api/public/cron/ai-jobs.ts, db/migrations/0025_ai_queue.sql

#### REQ-0445 – Modul: Version & Dependency Engine
Arkitekturen skal ha en logisk komponent «Version & Dependency Engine» med ansvarsområdet: Versjonering, avviksdeteksjon, endringsanalyse og ikke-destruktive oppdateringer.

- **Kilde:** Kap. 31 (l. 1338-1339) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** VERSION
- **Avhengigheter:** REQ-0432
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Arkitekturdokumentasjonen definerer Version & Dependency Engine med ansvar for: versjonering, avviksdeteksjon, endringsanalyse og ikke-destruktive oppdateringer, og dette ansvaret ligger ikke i andre moduler.
- **Tester:**
  - manuell: arkitekturgjennomgang av ansvarsgrenser
- **Implementering:** src/core/commands/apply.ts, db/migrations/0001_core.sql, docs/architecture/ARCHITECTURE.md, src/core/screenplay/versions.ts, src/core/assembly/discrepancy.ts, src/core/library/impact.ts, src/core/production/promote.ts
- **Merknad:** Versjoner defineres i fase 1; avviksdeteksjon/endringsanalyse i fase 6.

#### REQ-0446 – Modul: Localization Engine
Arkitekturen skal ha en logisk komponent «Localization Engine» med ansvarsområdet: Flerspråklig manus, dialog, undertekster og produksjonsvarianter.

- **Kilde:** Kap. 31 (l. 1340-1342) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** L10N
- **Avhengigheter:** REQ-0432
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Arkitekturdokumentasjonen definerer Localization Engine med ansvar for: flerspråklig manus, dialog, undertekster og produksjonsvarianter, og dette ansvaret ligger ikke i andre moduler.
- **Tester:**
  - manuell: arkitekturgjennomgang av ansvarsgrenser
- **Implementering:** src/core/translation/index.ts, src/core/commands/apply.ts (AddTranslations, UpdateTranslations, SetTranslationsRemoved), db/migrations/0016_translations.sql
- **Merknad:** Linje 1340/1341 duplikat.

#### REQ-0447 – Modul: Presentation Engine
Arkitekturen skal ha en logisk komponent «Presentation Engine» med ansvarsområdet: Plakater, karakterkart og annet presentasjonsmateriell.

- **Kilde:** Kap. 31 (l. 1343-1344) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** PRESENT
- **Avhengigheter:** REQ-0432
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Arkitekturdokumentasjonen definerer Presentation Engine med ansvar for: plakater, karakterkart og annet presentasjonsmateriell, og dette ansvaret ligger ikke i andre moduler.
- **Tester:**
  - manuell: arkitekturgjennomgang av ansvarsgrenser
- **Implementering:** src/core/presentation/poster.ts, src/core/presentation/relations.ts, src/core/presentation/metrics.ts, src/core/presentation/document.ts, src/engine/export/poster-pdf.ts, docs/architecture/ARCHITECTURE.md

#### REQ-0448 – Modul: Export Engine
Arkitekturen skal ha en logisk komponent «Export Engine» med ansvarsområdet: Film, manus, lyd, plakater og prosjektbackup.

- **Kilde:** Kap. 31 (l. 1345-1347) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** EXPORT
- **Avhengigheter:** REQ-0432
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Arkitekturdokumentasjonen definerer Export Engine med ansvar for: film, manus, lyd, plakater og prosjektbackup, og dette ansvaret ligger ikke i andre moduler.
- **Tester:**
  - manuell: arkitekturgjennomgang av ansvarsgrenser
- **Implementering:** docs/architecture/ARCHITECTURE.md
- **Merknad:** Linje 1345/1346 duplikat. Grunnleggende manuseksport i fase 2, filmeksport fase 4.

#### REQ-0449 – Modul: Security & Storage
Arkitekturen skal ha en logisk komponent «Security & Storage» med ansvarsområdet: Tilgangskontroll, API-nøkler, medielagring og dataintegritet.

- **Kilde:** Kap. 31 (l. 1348-1350) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** SECURITY
- **Avhengigheter:** REQ-0432
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Arkitekturdokumentasjonen definerer Security & Storage med ansvar for: tilgangskontroll, api-nøkler, medielagring og dataintegritet, og dette ansvaret ligger ikke i andre moduler.
- **Tester:**
  - manuell: arkitekturgjennomgang av ansvarsgrenser
- **Implementering:** db/migrations/0001_core.sql, docs/architecture/ARCHITECTURE.md, src/adapters/storage/commands.functions.ts, src/adapters/ai/key-vault.server.ts
- **Merknad:** Linje 1348/1349 duplikat. «Tilgangskontroll» – flerbruker registreres separat.

### Kapittel 32

#### REQ-0450 – Faseinndelt utvikling
Funksjonene skal ikke nødvendigvis implementeres samtidig. Utviklingen skal deles i realistiske, teknisk sammenhengende faser.

- **Kilde:** Kap. 32 (l. 1353-1355) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Det foreligger en faseplan der hver fase er teknisk sammenhengende og bygger på foregående faser.
- **Tester:**
  - manuell: gjennomgang av faseplan

### Kapittel Fase 1

#### REQ-0451 – Fase 1: Arkitektur og datamodell
Fase 1: Arkitektur og datamodell skal definere prosjekt, produksjon, scene, manusblokk, sceneforekomst, scenevariant, ressurs, medieklipp, filmmontering, versjoner og identitetsrelasjoner.

- **Kilde:** Kap. Fase 1 (l. 1356-1368) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** PROCESS
- **Avhengigheter:** REQ-0450
- **Status:** Under arbeid
- **Akseptansekriterier:**
  - Når fase 1 avsluttes, er alle listede leveranser ferdige med testbare akseptansekriterier, og de bygger på leveransene i foregående fase.
- **Tester:**
  - manuell: fasegjennomgang/milepælsrevisjon
- **Implementering:** src/core/, db/migrations/0001_core.sql
- **Merknad:** Prosesskrav (rekkefølge); de enkelte funksjonene er spesifisert som funksjonskrav i sine fagkapitler. Fase 1 sier «Definer» (datamodell), ikke «Implementer».

#### REQ-0452 – Fundament uten omfattende omskriving
Fundamentet fra fase 1 skal støtte videreutvikling uten omfattende omskriving.

- **Kilde:** Kap. Fase 1 (l. 1369) · **Opprinnelse:** mandat · **Type:** arkitektur · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** CORE, PROCESS
- **Avhengigheter:** REQ-0451
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Datamodellen fra fase 1 inneholder alle objekttyper som senere faser trenger (inkl. sceneforekomst, scenevariant og produksjon), slik at fase 7 ikke krever migrering av kjerneobjekter.
- **Tester:**
  - manuell: arkitekturgjennomgang mot fase 2–8
  - dataintegritet: migreringstester ved nye faser
- **Implementering:** src/core/, docs/architecture/ARCHITECTURE.md

### Kapittel Fase 2

#### REQ-0453 – Fase 2: Manus og prosjektoversikt
Fase 2: Manus og prosjektoversikt skal implementere manusimport, scenedeteksjon, originaltro manusvisning, redigering, sceneidentiteter, en enkel produksjonsoversikt, varighetsestimering og grunnleggende manuseksport.

- **Kilde:** Kap. Fase 2 (l. 1370-1379) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** PROCESS
- **Avhengigheter:** REQ-0451
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Når fase 2 avsluttes, er alle listede leveranser ferdige med testbare akseptansekriterier, og de bygger på leveransene i foregående fase.
- **Tester:**
  - manuell: fasegjennomgang/milepælsrevisjon
- **Merknad:** Prosesskrav (rekkefølge); de enkelte funksjonene er spesifisert som funksjonskrav i sine fagkapitler.

### Kapittel Fase 3

#### REQ-0454 – Fase 3: Ressursbibliotek og 2D-sceneeditor
Fase 3: Ressursbibliotek og 2D-sceneeditor skal implementere karakterer, objekter, miljøer, lagbasert komposisjon, kamera, keyframes og enkel lokal animatic-avspilling.

- **Kilde:** Kap. Fase 3 (l. 1380-1388) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** PROCESS
- **Avhengigheter:** REQ-0453
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Når fase 3 avsluttes, er alle listede leveranser ferdige med testbare akseptansekriterier, og de bygger på leveransene i foregående fase.
- **Tester:**
  - manuell: fasegjennomgang/milepælsrevisjon
- **Merknad:** Prosesskrav (rekkefølge); de enkelte funksjonene er spesifisert som funksjonskrav i sine fagkapitler.

### Kapittel Fase 4

#### REQ-0455 – Fase 4: Tidslinje, lyd og filmmontering
Fase 4: Tidslinje, lyd og filmmontering skal implementere toveis manussynkronisering, dialogkoblinger, lydspor, overordnet filmtidslinje og enkel hybrid avspilling og eksport.

- **Kilde:** Kap. Fase 4 (l. 1389-1395) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** PROCESS
- **Avhengigheter:** REQ-0454
- **Status:** Under arbeid
- **Akseptansekriterier:**
  - Når fase 4 avsluttes, er alle listede leveranser ferdige med testbare akseptansekriterier, og de bygger på leveransene i foregående fase.
- **Tester:**
  - manuell: fasegjennomgang/milepælsrevisjon
- **Implementering:** src/app/assembly/
- **Merknad:** Prosesskrav (rekkefølge); de enkelte funksjonene er spesifisert som funksjonskrav i sine fagkapitler.

### Kapittel Fase 5

#### REQ-0456 – Fase 5: Genereringsmotor og AI-integrasjoner
Fase 5: Genereringsmotor og AI-integrasjoner skal implementere modelladaptere, promptmotor, synlige og redigerbare prompter, kostnadsestimering, genereringsversjoner, automatisk segmentering og renderingskø.

- **Kilde:** Kap. Fase 5 (l. 1396-1404) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** PROCESS
- **Avhengigheter:** REQ-0455
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Når fase 5 avsluttes, er alle listede leveranser ferdige med testbare akseptansekriterier, og de bygger på leveransene i foregående fase.
- **Tester:**
  - manuell: fasegjennomgang/milepælsrevisjon
- **Merknad:** Prosesskrav (rekkefølge); de enkelte funksjonene er spesifisert som funksjonskrav i sine fagkapitler.

### Kapittel Fase 6

#### REQ-0457 – Fase 6: Avansert produksjonskontroll
Fase 6: Avansert produksjonskontroll skal implementere avviksdeteksjon, kontinuitetsanalyse, karaktertilstander, ressursavhengigheter, sammenligning av versjoner og sikker oppdatering og regenerering.

- **Kilde:** Kap. Fase 6 (l. 1405-1412) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P2 · **Fase:** 6
- **Moduler:** PROCESS
- **Avhengigheter:** REQ-0456
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Når fase 6 avsluttes, er alle listede leveranser ferdige med testbare akseptansekriterier, og de bygger på leveransene i foregående fase.
- **Tester:**
  - manuell: fasegjennomgang/milepælsrevisjon
- **Merknad:** Prosesskrav (rekkefølge); de enkelte funksjonene er spesifisert som funksjonskrav i sine fagkapitler.

### Kapittel Fase 7

#### REQ-0458 – Fase 7: Flerspråklighet og avledede produksjoner
Fase 7: Flerspråklighet og avledede produksjoner skal implementere engelsk manus, språkkoblinger, alternative lydspor, spinoffer, lokale scenevarianter og tilbakeføring av forbedringer.

- **Kilde:** Kap. Fase 7 (l. 1413-1420) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P2 · **Fase:** 7
- **Moduler:** PROCESS
- **Avhengigheter:** REQ-0457
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Når fase 7 avsluttes, er alle listede leveranser ferdige med testbare akseptansekriterier, og de bygger på leveransene i foregående fase.
- **Tester:**
  - manuell: fasegjennomgang/milepælsrevisjon
- **Merknad:** Prosesskrav (rekkefølge); de enkelte funksjonene er spesifisert som funksjonskrav i sine fagkapitler.

### Kapittel Fase 8

#### REQ-0459 – Fase 8: Presentasjonsmodul og videre kvalitetssystem
Fase 8: Presentasjonsmodul og videre kvalitetssystem skal implementere pitchplakater, karakterkart, stilharmonisering, global publisering av stilvarianter, avanserte kvalitetsprofiler og utvidede eksporter.

- **Kilde:** Kap. Fase 8 (l. 1421-1428) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P3 · **Fase:** 8
- **Moduler:** PROCESS
- **Avhengigheter:** REQ-0458
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Når fase 8 avsluttes, er alle listede leveranser ferdige med testbare akseptansekriterier, og de bygger på leveransene i foregående fase.
- **Tester:**
  - manuell: fasegjennomgang/milepælsrevisjon
- **Merknad:** Prosesskrav (rekkefølge); de enkelte funksjonene er spesifisert som funksjonskrav i sine fagkapitler.

#### REQ-0460 – Fasene er utgangspunkt – vurder avhengigheter
Fasene er et utgangspunkt. Utviklingspartneren skal vurdere tekniske avhengigheter og anbefale justeringer når det er nødvendig.

- **Kilde:** Kap. Fase 8 (l. 1429) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Avhengigheter:** REQ-0450
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Faseplanen inneholder en eksplisitt avhengighetsvurdering, og avvik fra fase-rekkefølgen er begrunnet.
- **Tester:**
  - manuell: gjennomgang av avhengighetsanalyse
- **Merknad:** Står under overskriften Fase 8, men gjelder hele kap. 32.

#### REQ-0461 – Grunnarkitektur foran isolerte funksjoner
Det er viktigere å bygge riktig grunnarkitektur enn å implementere mange isolerte funksjoner raskt.

- **Kilde:** Kap. Fase 8 (l. 1430) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Avhengigheter:** REQ-0450
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Hver ny funksjon dokumenteres med hvordan den bygger på felles datamodell; funksjoner uten slik forankring godtas ikke.
- **Tester:**
  - manuell: kodegjennomgang
- **Merknad:** Står under overskriften Fase 8, men gjelder hele kap. 32.

### Kapittel 33

#### REQ-0462 – Aktiv, selvstendig og kritisk utviklingspartner
Claude skal opptre som en aktiv, selvstendig og kritisk utviklingspartner.

- **Kilde:** Kap. 33 (l. 1432-1433) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Claude tar initiativ til forslag og påpeker problemer/risikoer uten å bli spurt.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser

#### REQ-0463 – Vurdere helhetspåvirkning før forslag og kode
Før nye funksjoner foreslås eller kode skrives, skal det vurderes hvordan løsningen påvirker: felles datamodell, manus- og filmsynkronisering, permanente identiteter, versjonering, spinoffer, kontinuitet, språkversjoner, kostnader og portabilitet.

- **Kilde:** Kap. 33.1 (l. 1434-1444) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Hvert funksjonsforslag inneholder en vurdering av påvirkning på alle ni områdene.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser

#### REQ-0464 – Ingen lokale løsninger som bryter prinsippene
Det skal ikke implementeres lokale løsninger som bryter med de overordnede prinsippene.

- **Kilde:** Kap. 33.1 (l. 1445) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P0 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Ingen implementasjon bryter prinsippene i kap. 34; avvik avdekkes i gjennomgang før levering.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser

#### REQ-0465 – Strukturert definisjon av nye utviklingsområder
Når et nytt utviklingsområde påbegynnes, skal det normalt defineres: 1) målet, 2) brukerens arbeidsflyt, 3) nødvendige dataobjekter, 4) relasjoner og avhengigheter, 5) grensesnittet, 6) teknisk implementering, 7) feilsituasjoner, 8) testbare akseptansekriterier, 9) hvordan funksjonen passer inn i Lovable, 10) eventuelle begrensninger eller fremtidige migreringsbehov.

- **Kilde:** Kap. 33.2 (l. 1446-1457) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Hver ny områdebeskrivelse inneholder alle ti punktene (eller begrunnelse for utelatelse).
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser
- **Merknad:** «normalt».

#### REQ-0466 – Presise, kopierbare Lovable-instruksjoner
Når brukeren ber om hjelp til utvikling i Lovable, skal Claude kunne utforme presise, komplette og praktisk gjennomførbare instruksjoner som kan kopieres inn i Lovable.

- **Kilde:** Kap. 33.3 (l. 1458-1459) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Instruksjonene kan limes direkte inn i Lovable uten omskriving.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser

#### REQ-0467 – Innhold i Lovable-instruksjoner
Lovable-instruksjonene skal beskrive: hvilke komponenter som skal opprettes, hvordan de skal fungere, hvilke data de skal lese og skrive, hvilke tilstander som skal håndteres, hvordan brukerinteraksjonene skal fungere og hvordan løsningen passer inn i eksisterende arkitektur.

- **Kilde:** Kap. 33.3 (l. 1460-1466) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Avhengigheter:** REQ-0466
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Hver Lovable-instruksjon dekker alle seks punktene.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser

#### REQ-0468 – Ikke hele applikasjonen i ett steg
Det skal ikke foreslås å bygge hele applikasjonen i ett eneste stort utviklingssteg.

- **Kilde:** Kap. 33.3 (l. 1467) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Avhengigheter:** REQ-0466
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Hver Lovable-instruksjon avgrenser ett håndterbart utviklingssteg.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser

#### REQ-0469 – Ikke påstå uverifisert funksjonalitet
Claude skal ikke hevde at en modell, API-tjeneste eller Lovable har funksjonalitet som ikke er verifisert.

- **Kilde:** Kap. 33.4 (l. 1468-1469) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Påstander om tredjepartsfunksjonalitet er kildebelagt eller eksplisitt merket som uverifisert.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser

#### REQ-0470 – Beskrive teknisk usikkerhet
Når tekniske muligheter er usikre, skal usikkerheten beskrives.

- **Kilde:** Kap. 33.4 (l. 1470-1471) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Ved usikre tekniske muligheter inneholder svaret: beskrive teknisk usikkerhet.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser

#### REQ-0471 – Foreslå arkitektur ved usikkerhet
Når tekniske muligheter er usikre, skal det foreslås en egnet arkitektonisk løsning.

- **Kilde:** Kap. 33.4 (l. 1472) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Ved usikre tekniske muligheter inneholder svaret: foreslå arkitektur ved usikkerhet.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser

#### REQ-0472 – Skille MVP og fremtidig funksjonalitet
Når tekniske muligheter er usikre, skal det skilles mellom MVP og fremtidig funksjonalitet.

- **Kilde:** Kap. 33.4 (l. 1473) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Ved usikre tekniske muligheter inneholder svaret: skille mvp og fremtidig funksjonalitet.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser

#### REQ-0473 – Unngå udokumenterte egenskaper
Når tekniske muligheter er usikre, skal avhengighet av udokumenterte egenskaper unngås.

- **Kilde:** Kap. 33.4 (l. 1474) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Ved usikre tekniske muligheter inneholder svaret: unngå udokumenterte egenskaper.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser

#### REQ-0474 – Forklare forenkling eller utsettelse av krav
Prosjektmandatet representerer samlede produktbeslutninger. Hvis et krav bør forenkles, utsettes eller gjennomføres annerledes, skal Claude forklare hvorfor.

- **Kilde:** Kap. 33.5 (l. 1475-1477) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Hver foreslått forenkling/utsettelse har en eksplisitt begrunnelse.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser

#### REQ-0475 – Ikke stille bort krav i stillhet
Viktige krav skal ikke stilles bort i stillhet.

- **Kilde:** Kap. 33.5 (l. 1478) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P0 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Sporbarhetsmatrisen viser status for alle krav; ingen krav forsvinner uten registrert beslutning.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser
- **Merknad:** P0 fordi det beskytter hele kravsettet.

#### REQ-0476 – Steg-for-steg utvikling
Applikasjonen skal utvikles steg for steg.

- **Kilde:** Kap. 33.6 (l. 1479-1480) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Utviklingen leveres i avgrensede inkrementer med egen verifikasjon.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser

#### REQ-0477 – Anbefalinger og konsekvensvurderinger ved arkitekturbeslutninger
Ved større arkitekturbeslutninger skal Claude bidra med tydelige anbefalinger og konsekvensvurderinger.

- **Kilde:** Kap. 33.6 (l. 1481) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Hver større arkitekturbeslutning har en dokumentert anbefaling og konsekvensvurdering.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser

#### REQ-0478 – Hele systemet forblir konsistent
Målet er ikke bare at en enkelt funksjon virker, men at hele systemet forblir konsistent etter hvert som nye funksjoner legges til.

- **Kilde:** Kap. 33.6 (l. 1482) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Regresjonstester for kjerneinvarianter kjøres ved hver ny funksjon og passerer.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser

### Kapittel 34

#### REQ-0479 – Prinsipp 1: Produktet heter Animatic Studio
Produktet heter Animatic Studio, ikke AI Animatic Studio.

- **Kilde:** Kap. 34 (l. 1486-1487) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** –
- **Moduler:** UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Søk i UI-tekster, metadata og eksportfiler finner ikke «AI Animatic Studio».
- **Tester:**
  - manuell: verifiseres mot underliggende funksjonskrav
- **Implementering:** src/routes/__root.tsx, src/engine/export/screenplay-pdf.ts, src/engine/export/poster-pdf.ts
- **Merknad:** Ingen treff på «AI Animatic Studio» i kode og eksport i dag, men ingen automatisk test søker etter det.

#### REQ-0480 – Prinsipp 2: Manus og film alltid strukturelt synkronisert
Manus og film skal alltid være strukturelt synkronisert. De skal bygge på samme prosjektmodell.

- **Kilde:** Kap. 34 (l. 1488-1490) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** CORE, SCRIPT, TIMELINE · **Invarianter:** INV-01
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Etter enhver strukturell operasjon (flytt, deaktiver, splitt) er aktiv scenestruktur i manus og film identisk.
- **Tester:**
  - dataintegritet: egenskapsbaserte tester på strukturell synk
- **Implementering:** src/core/views.ts
- **Merknad:** Oppsummerer kap. 2, 2.1, 3.4, 6, 15.2. Linje 1488/1489 duplikat.

#### REQ-0481 – Prinsipp 3: Scenenummer aldri permanent identitet
Scenenummer skal aldri brukes som permanent identitet. Alle scener og ressurser skal ha stabile interne identifikatorer.

- **Kilde:** Kap. 34 (l. 1491-1492) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** CORE · **Invarianter:** INV-02, INV-03
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Alle relasjoner refererer interne ID-er; omnummerering endrer ingen relasjon.
- **Tester:**
  - enhet: ID-stabilitet ved flytting/omnummerering
- **Implementering:** src/core/ids.ts, src/core/model.ts, src/core/screenplay/numbering.ts
- **Merknad:** Oppsummerer kap. 3.1, 3.2, 8.2.

#### REQ-0482 – Prinsipp 4: Eksportnummerering velges av brukeren hver gang
Eksportnummerering bestemmes av brukeren hver gang. Eksport skal ikke endre interne identiteter.

- **Kilde:** Kap. 34 (l. 1493-1495) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 2
- **Moduler:** EXPORT, SCRIPT · **Invarianter:** INV-02
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Hver manuseksport krever nummereringsvalg; interne ID-er er uendret etter eksport.
- **Tester:**
  - manuell: verifiseres mot underliggende funksjonskrav
- **Implementering:** src/app/script/ExportDialog.tsx, src/app/script/ExportDialog.tsx, src/core/screenplay/numbering.ts#exportNumbering
- **Merknad:** Bare skjermbilde som bevis; mangler test som kontrollerer valget/eksporten.

#### REQ-0483 – Prinsipp 5: Norsk er hovedmanus
Norsk er hovedmanus. Engelsk er en tilknyttet språkversjon.

- **Kilde:** Kap. 34 (l. 1496-1498) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 2
- **Moduler:** SCRIPT, L10N · **Invarianter:** INV-05, INV-06
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Endringer i engelsk versjon endrer ikke norsk hovedmanus automatisk.
- **Tester:**
  - manuell: verifiseres mot underliggende funksjonskrav
- **Implementering:** src/core/translation/index.ts, src/core/model.ts#PRIMARY_LANGUAGE
- **Merknad:** Oppsummerer kap. 23.1, 23.2, 23.3. Linje 1496/1497 duplikat.

#### REQ-0484 – Prinsipp 6: Mange produksjonsversjoner per scene
En scene kan ha mange produksjonsversjoner. Tidligere versjoner skal bevares.

- **Kilde:** Kap. 34 (l. 1499-1501) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** VERSION, CORE · **Invarianter:** INV-13
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En scene med flere versjoner beholder alle tidligere versjoner etter at ny aktiv versjon velges.
- **Tester:**
  - manuell: verifiseres mot underliggende funksjonskrav
- **Implementering:** src/core/model.ts, src/core/commands/apply.ts
- **Merknad:** Oppsummerer kap. 3.3, 15.3, 16.4, 17.4, 21.5. Linje 1499/1500 duplikat.

#### REQ-0485 – Prinsipp 7: Manusendringer flagger berørt materiale
Manusendringer skal flagge berørt materiale. De skal ikke automatisk overskrive eksisterende film.

- **Kilde:** Kap. 34 (l. 1502-1504) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 6
- **Moduler:** VERSION, SCRIPT · **Invarianter:** INV-07
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Etter manusendring er berørt materiale flagget og filmfilene uendret.
- **Tester:**
  - manuell: verifiseres mot underliggende funksjonskrav
- **Implementering:** src/core/assembly/discrepancy.ts, src/core/commands/apply.ts (AcceptScriptChanges, SetProducedFrom), db/migrations/0014_ai_control.sql (compositions.produced_from, takes.accepted_from), src/app/assembly/ScriptChanges.tsx, src/app/assembly/FilmTimeline.tsx (merker), src/app/script/ScriptPageView.tsx (merker), src/app/scene-editor/SceneEditorWorkspace.tsx (varsel)
- **Merknad:** Oppsummerer kap. 2.1, 2.2, 21.1, 21.4. Linje 1502/1503 duplikat.

#### REQ-0486 – Prinsipp 8: Godkjenne avvik, oppdatere eller angre
Brukeren skal kunne godkjenne avvik, oppdatere materiale eller angre endringen.

- **Kilde:** Kap. 34 (l. 1505-1506) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 6
- **Moduler:** VERSION, UI · **Invarianter:** INV-08
- **Status:** Verifisert
- **Akseptansekriterier:**
  - For hvert flagget avvik tilbys de tre valgene, og hvert valg gir forventet tilstand.
- **Tester:**
  - manuell: verifiseres mot underliggende funksjonskrav
- **Implementering:** src/core/assembly/discrepancy.ts, src/core/commands/apply.ts (AcceptScriptChanges, SetProducedFrom), db/migrations/0014_ai_control.sql (compositions.produced_from, takes.accepted_from), src/app/assembly/ScriptChanges.tsx, src/app/assembly/FilmTimeline.tsx (merker), src/app/script/ScriptPageView.tsx (merker), src/app/scene-editor/SceneEditorWorkspace.tsx (varsel)
- **Merknad:** Oppsummerer kap. 21.2, 2.2. Linje 1505/1506 duplikat.

#### REQ-0487 – Prinsipp 9: Animatics uten generativ AI
Animatics skal kunne spilles av og eksporteres uten generativ AI.

- **Kilde:** Kap. 34 (l. 1507-1508) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 3
- **Moduler:** COMPOSE, EXPORT · **Invarianter:** INV-11
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Med alle AI-adaptere deaktivert kan en animatic spilles av og eksporteres.
- **Tester:**
  - integrasjon: avspilling/eksport uten nettverk til AI
- **Implementering:** src/engine/export/animatic.ts, src/engine/compositor/film.ts, src/core/composition/render.ts
- **Merknad:** Bare skjermbilde som bevis; mangler test som kontrollerer valget/eksporten.

#### REQ-0488 – Prinsipp 10: Lagbasert multiplan-inspirert 2D-editor
2D-editoren skal være lagbasert og inspirert av tradisjonell multiplan-animasjon.

- **Kilde:** Kap. 34 (l. 1509-1510) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 3
- **Moduler:** COMPOSE, CAMERA
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En scene kan bygges av flere lag med dybde, og kamerabevegelse gir parallakse mellom lag.
- **Tester:**
  - manuell: verifiseres mot underliggende funksjonskrav
- **Implementering:** src/core/composition/render.ts, src/core/composition/index.ts, src/engine/compositor/canvas.ts
- **Merknad:** Oppsummerer kap. 11, 11.1. Linje 1509/1510 duplikat.

#### REQ-0489 – Prinsipp 11: Modellagnostisk AI med synlige prompter
AI-generering skal være modellagnostisk og basert på presise, synlige og redigerbare prompter.

- **Kilde:** Kap. 34 (l. 1511) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 5
- **Moduler:** PROMPT, PROVIDER
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Samme genereringsforespørsel kan sendes til minst to leverandører via adaptere; prompten vises og kan redigeres før sending.
- **Tester:**
  - manuell: verifiseres mot underliggende funksjonskrav
- **Implementering:** src/app/ai/SentPrompts.tsx, src/app/assembly/AiUpdateSection.tsx
- **Merknad:** Oppsummerer kap. 17.1, 17.3, 19.2.

#### REQ-0490 – Prinsipp 12: Engelske AI-instruksjoner og prompter
AI-systeminstruksjoner og genereringsprompter skal som hovedregel være på engelsk.

- **Kilde:** Kap. 34 (l. 1512) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 5
- **Moduler:** PROMPT
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Genererte prompter er på engelsk med mindre brukeren eksplisitt overstyrer.
- **Tester:**
  - manuell: verifiseres mot underliggende funksjonskrav
- **Implementering:** src/core/generation/scene-prompt.ts#buildScenePrompt, src/core/generation/image-prompt.ts#buildContextImagePrompt, src/core/generation/prompt-writer.ts#PROMPT_WRITER_SYSTEM
- **Merknad:** Oppsummerer kap. 1.3, 17.2.

#### REQ-0491 – Prinsipp 13: Brukeren kontrollerer kvalitet, modell og kostnad
Brukeren skal kontrollere kvalitetsnivå, modellvalg og kostnader.

- **Kilde:** Kap. 34 (l. 1513) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 5
- **Moduler:** QUALITYCOST, PROVIDER · **Invarianter:** INV-12
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Ingen betalt generering starter uten at brukeren har valgt/godkjent modell, kvalitetsnivå og kostnadsestimat.
- **Tester:**
  - manuell: verifiseres mot underliggende funksjonskrav
- **Implementering:** src/app/ai/EffortPicker.tsx
- **Merknad:** Oppsummerer kap. 19.3, 19.5, 19.6.

#### REQ-0492 – Prinsipp 14: Produksjonsteknisk deling av lange scener
Lange scener skal kunne deles produksjonsteknisk uten å endre manusstrukturen.

- **Kilde:** Kap. 34 (l. 1514) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 5
- **Moduler:** PROMPT, TIMELINE, CORE · **Invarianter:** INV-10
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Etter segmentering er scene-ID, scenenummer og manusstruktur uendret.
- **Tester:**
  - manuell: verifiseres mot underliggende funksjonskrav
- **Implementering:** src/core/generation/scene-prompt.ts#planSegments, src/core/commands/apply.ts
- **Merknad:** Oppsummerer kap. 18, 18.1, 18.4.

#### REQ-0493 – Prinsipp 15: Import av ferdig film koblet til manus
Ferdig film skal kunne importeres og knyttes til bestemte manuspassasjer.

- **Kilde:** Kap. 34 (l. 1515-1516) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 4
- **Moduler:** TIMELINE, SCRIPT
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En importert filmfil kan knyttes til en bestemt manuspassasje og spilles av i tidslinjen.
- **Tester:**
  - manuell: verifiseres mot underliggende funksjonskrav
- **Implementering:** src/app/assembly/LongFilmImportDialog.tsx, src/app/assembly/film-import.ts, src/core/assembly/film.ts#filmClips, src/core/commands/apply.ts
- **Merknad:** Oppsummerer kap. 16, 16.1. Linje 1515/1516 duplikat.

#### REQ-0494 – Prinsipp 16: Kontinuerlig beregning av spilletid
Filmens estimerte og faktiske spilletid skal beregnes kontinuerlig.

- **Kilde:** Kap. 34 (l. 1517-1518) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 2
- **Moduler:** TIMELINE, SCRIPT
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Estimert og faktisk spilletid oppdateres umiddelbart etter endring i manus eller tidslinje.
- **Tester:**
  - manuell: verifiseres mot underliggende funksjonskrav
- **Implementering:** src/core/screenplay/duration.ts#estimateProduction, src/core/assembly/status.ts#productionStatus, src/app/projects/DurationOverview.tsx
- **Merknad:** Oppsummerer kap. 7.1, 7.2, 27.1. Linje 1517/1518 duplikat.

#### REQ-0495 – Prinsipp 17: Varighet på egen oversiktsside
Varighetsinformasjon skal primært vises på en egen oversiktsside, ikke inne i manuslayouten.

- **Kilde:** Kap. 34 (l. 1519) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 2
- **Moduler:** UI, SCRIPT
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Ordinær manusvisning viser ikke varighetsdata; oversiktssiden gjør det.
- **Tester:**
  - manuell: verifiseres mot underliggende funksjonskrav
- **Implementering:** src/app/projects/DurationOverview.tsx
- **Merknad:** Oppsummerer kap. 7.3, 6.3.

#### REQ-0496 – Prinsipp 18: Tidsstyrte utseendeendringer for karakterer
Karakterer skal kunne ha tidsstyrte utseendeendringer. Dette inkluderer blant annet at Maja klipper håret midt i filmen.

- **Kilde:** Kap. 34 (l. 1520-1522) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 6
- **Moduler:** CONTINUITY, LIBRARY · **Invarianter:** INV-09
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Maja har langt hår før og kort hår etter klippehendelsen i fortellingstid, også ved flashback.
- **Tester:**
  - manuell: verifiseres mot underliggende funksjonskrav
- **Implementering:** src/core/continuity/index.ts, src/core/commands/apply.ts (AddContinuityEvents, UpdateContinuityEvents, SetContinuityEventsRemoved), db/migrations/0015_continuity.sql, src/app/library/ContinuityPanel.tsx, src/app/scene-editor/LayerInspector.tsx, src/app/scene-editor/SceneAssetsPanel.tsx
- **Merknad:** Oppsummerer kap. 9.1, 10, 10.1, 10.3, 10.5, 10.7. Linje 1520/1521 duplikat.

#### REQ-0497 – Prinsipp 19: Separate segmenter ved endring midt i scene
Ved en utseendeendring midt i en scene skal systemet kunne foreslå separate produksjonssegmenter. Det skal ikke endre sceneidentiteten eller scenenummeret.

- **Kilde:** Kap. 34 (l. 1523-1524) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 6
- **Moduler:** CONTINUITY, TIMELINE · **Invarianter:** INV-10
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Ved utseendeendring midt i scene foreslås segmenter, og scene-ID og scenenummer er uendret.
- **Tester:**
  - manuell: verifiseres mot underliggende funksjonskrav
- **Implementering:** src/core/generation/scene-prompt.ts (planSegments, continuityCuts), src/app/assembly/GenerateSceneDialog.tsx
- **Merknad:** Oppsummerer kap. 10.6, 18.

#### REQ-0498 – Prinsipp 20: Delte ressurser, uavhengig manus og montering
Hovedfilm og spinoffer skal kunne dele ressurser, men ha uavhengig manus og filmmontering.

- **Kilde:** Kap. 34 (l. 1525-1526) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 7
- **Moduler:** CORE, LIBRARY, TIMELINE · **Invarianter:** INV-04
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En ressurs brukes i begge produksjoner; omorganisering i én endrer ikke den andres manus/montering.
- **Tester:**
  - manuell: verifiseres mot underliggende funksjonskrav
- **Implementering:** src/core/production/index.ts
- **Merknad:** Oppsummerer kap. 3.3, 8.1, 24.2, 24.3. Linje 1525/1526 duplikat.

#### REQ-0499 – Prinsipp 21: Spinoffer med egne nye scener
Spinoffer skal kunne inneholde egne nye scener. Disse skal ikke automatisk legges til hovedfilmen.

- **Kilde:** Kap. 34 (l. 1527-1529) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 7
- **Moduler:** CORE, SCRIPT · **Invarianter:** INV-04
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En ny spinoff-scene finnes ikke i hovedfilmen før eksplisitt overføring.
- **Tester:**
  - manuell: verifiseres mot underliggende funksjonskrav
- **Implementering:** src/core/production/index.ts
- **Merknad:** Oppsummerer kap. 24.4. Linje 1527/1528 duplikat.

#### REQ-0500 – Prinsipp 22: Tilbakeføring krever godkjenning
Forbedringer fra spinoffer skal kunne foreslås tilbakeført til hovedfilmen. Brukeren må godkjenne overføringen.

- **Kilde:** Kap. 34 (l. 1530-1531) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 7
- **Moduler:** VERSION, CORE · **Invarianter:** INV-08
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Tilbakeføring skjer kun etter eksplisitt brukergodkjenning.
- **Tester:**
  - manuell: verifiseres mot underliggende funksjonskrav
- **Implementering:** src/core/production/promote.ts, src/core/commands/apply.ts (ForkVariant.sourceVariantId, TransferScene, SetContinuityEventDisabled), src/app/projects/PromotionDialog.tsx
- **Merknad:** Oppsummerer kap. 24.5, 25, 25.2.

#### REQ-0501 – Prinsipp 23: Plakater som selvstendige redigerbare eksportprodukter
Plakater og karakterkart skal være selvstendige, redigerbare eksportprodukter.

- **Kilde:** Kap. 34 (l. 1532-1533) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 8
- **Moduler:** PRESENT, EXPORT
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En lagret plakat kan gjenåpnes, redigeres element for element og eksporteres separat.
- **Tester:**
  - manuell: verifiseres mot underliggende funksjonskrav
- **Implementering:** src/core/presentation/poster.ts, src/core/presentation/relations.ts, src/core/presentation/metrics.ts, src/core/presentation/document.ts, src/app/release/PosterWorkspace.tsx
- **Merknad:** Oppsummerer kap. 26, 26.6, 29.5. Linje 1532/1533 duplikat.

#### REQ-0502 – Prinsipp 24: Plakater 70 × 100 cm og flere informasjonsnivåer
Plakater skal støtte 70 × 100 cm og flere informasjonsnivåer.

- **Kilde:** Kap. 34 (l. 1534-1535) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 8
- **Moduler:** PRESENT
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Plakat kan eksporteres i 70 × 100 cm med valgbart informasjonsnivå.
- **Tester:**
  - manuell: verifiseres mot underliggende funksjonskrav
- **Implementering:** src/core/presentation/poster.ts
- **Merknad:** Oppsummerer kap. 26.1, 26.3. Linje 1534/1535 duplikat.

#### REQ-0503 – Prinsipp 25: Publisering av harmoniserte bilder etter godkjenning
Harmoniserte karakterbilder skal kunne publiseres til globalt ressursbibliotek etter godkjenning.

- **Kilde:** Kap. 34 (l. 1536-1537) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 8
- **Moduler:** LIBRARY, PRESENT · **Invarianter:** INV-13
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Et harmonisert bilde publiseres kun etter godkjenning, som ny versjonert stilvariant.
- **Tester:**
  - manuell: verifiseres mot underliggende funksjonskrav
- **Merknad:** Oppsummerer kap. 9.2, 9.3, 26.7. Linje 1536/1537 duplikat.

#### REQ-0504 – Prinsipp 26: Jobber og status bevares mellom økter
Renderingsjobber og prosjektstatus skal bevares mellom arbeidsøkter.

- **Kilde:** Kap. 34 (l. 1538-1539) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 5
- **Moduler:** QUEUE, CORE
- **Status:** Implementert – ikke verifisert
- **Akseptansekriterier:**
  - Etter lukking og gjenåpning vises alle jobber med korrekt status, og pågående jobber kan gjenopptas.
- **Tester:**
  - manuell: verifiseres mot underliggende funksjonskrav
- **Implementering:** src/adapters/ai/video-followup.server.ts
- **Merknad:** Oppsummerer kap. 20.2, 20.4, 27.3. Linje 1538/1539 duplikat.

#### REQ-0505 – Prinsipp 27: Aldri destruktive endringer uten beslutning
Eksisterende produksjonsmateriale skal aldri endres destruktivt uten brukerens eksplisitte beslutning.

- **Kilde:** Kap. 34 (l. 1540-1541) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** VERSION, CORE, SECURITY · **Invarianter:** INV-07, INV-13, INV-14
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Ingen operasjon sletter eller overskriver produksjonsmateriale uten eksplisitt brukerbekreftelse; alt er reverserbart.
- **Tester:**
  - dataintegritet: regresjonstester for ikke-destruktivitet
- **Implementering:** src/core/commands/apply.ts, db/migrations/0001_core.sql, src/core/invariants.ts
- **Merknad:** Oppsummerer kap. 2.2, 21.5, 24.5, 25.2, 28.1. Linje 1540/1541 duplikat.

#### REQ-0506 – Prinsipp 28: Portabel arkitektur fra Lovable til desktop
Arkitekturen skal kunne videreutvikles fra Lovable til macOS- og Windows-applikasjoner.

- **Kilde:** Kap. 34 (l. 1542) · **Opprinnelse:** mandat · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 1
- **Moduler:** CORE, PROCESS
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Domene-/datamodell og produksjonslogikk har ingen avhengighet til Lovable-spesifikke API-er og kan kjøres utenfor nettleser.
- **Tester:**
  - manuell: arkitekturgjennomgang av plattformbindinger
- **Implementering:** src/core/
- **Merknad:** Oppsummerer kap. 1.2, 31, 28.2.

### Kapittel 35

#### REQ-0507 – Ikke implementere alt umiddelbart
Claude skal ikke forsøke å implementere hele Animatic Studio umiddelbart.

- **Kilde:** Kap. 35 (l. 1545) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Første leveranse er analyse og plan, ikke full implementasjon.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser

#### REQ-0508 – Mandatet er samlet produktspesifikasjon
Dokumentet skal behandles som prosjektets samlede produktspesifikasjon.

- **Kilde:** Kap. 35 (l. 1546) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P0 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Alle krav i mandatet er registrert og sporbare i kravsettet.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser

#### REQ-0509 – Første oppgave 1: Identifisere arkitektoniske avhengigheter
Som del av første oppgave skal Claude: Identifisere de viktigste arkitektoniske avhengighetene mellom modulene.

- **Kilde:** Kap. 35 (l. 1548) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Et avhengighetskart mellom modulene i kap. 31 foreligger.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser
- **Merknad:** Punkt 1 av 8 i kap. 35.

#### REQ-0510 – Første oppgave 2: Foreslå robust intern datamodell
Som del av første oppgave skal Claude: Foreslå en robust intern datamodell som støtter både manus, sceneidentiteter, produksjoner, spinoffer, medieklipp og versjonering.

- **Kilde:** Kap. 35 (l. 1549) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Datamodellforslaget dekker manus, sceneidentiteter, produksjoner, spinoffer, medieklipp og versjonering.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser
- **Merknad:** Punkt 2 av 8 i kap. 35.

#### REQ-0511 – Første oppgave 3: Foreslå arkitektur for første versjon i Lovable
Som del av første oppgave skal Claude: Foreslå en realistisk teknisk arkitektur for første versjon i Lovable.

- **Kilde:** Kap. 35 (l. 1550) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Et arkitekturforslag for Lovable-versjonen foreligger.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser
- **Merknad:** Punkt 3 av 8 i kap. 35.

#### REQ-0512 – Første oppgave 4: Skille nettleser, backend og medietjenester
Som del av første oppgave skal Claude: Skille tydelig mellom funksjoner som bør implementeres i nettleseren, i en backend og eventuelt i egne medie- eller renderingtjenester.

- **Kilde:** Kap. 35 (l. 1551) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Hver hovedfunksjon er plassert i nettleser, backend eller medie-/renderingtjeneste med begrunnelse.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser
- **Merknad:** Punkt 4 av 8 i kap. 35.

#### REQ-0513 – Første oppgave 5: Anbefale prioritert MVP
Som del av første oppgave skal Claude: Anbefale en konkret, prioritert MVP som gir et fungerende grunnprodukt uten å blokkere de mer avanserte funksjonene senere.

- **Kilde:** Kap. 35 (l. 1552) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - MVP-forslaget er prioritert og viser at avanserte funksjoner ikke blokkeres.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser
- **Merknad:** Punkt 5 av 8 i kap. 35.

#### REQ-0514 – Første oppgave 6: Utviklingsplan med milepæler
Som del av første oppgave skal Claude: Definere en utviklingsplan med tydelige milepæler og testbare akseptansekriterier.

- **Kilde:** Kap. 35 (l. 1553) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Utviklingsplanen har milepæler med testbare akseptansekriterier.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser
- **Merknad:** Punkt 6 av 8 i kap. 35.

#### REQ-0515 – Første oppgave 7: Peke på tekniske risikoer
Som del av første oppgave skal Claude: Peke på tekniske risikoer, særlig knyttet til manusformatering, mediebehandling, tidslinjesynkronisering, AI-integrasjoner og datakonsistens.

- **Kilde:** Kap. 35 (l. 1554) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Risikolisten dekker minst manusformatering, mediebehandling, tidslinjesynkronisering, AI-integrasjoner og datakonsistens.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser
- **Merknad:** Punkt 7 av 8 i kap. 35.

#### REQ-0516 – Første oppgave 8: Første presise Lovable-instruksjon
Som del av første oppgave skal Claude: Foreslå den første presise utviklingsinstruksjonen vi bør gi Lovable.

- **Kilde:** Kap. 35 (l. 1555) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - En første Lovable-instruksjon foreligger og oppfyller kravene i kap. 33.3.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser
- **Merknad:** Punkt 8 av 8 i kap. 35.

#### REQ-0517 – Ikke redusere til enkel AI-videogenerator
Produktvisjonen skal ikke reduseres til en enkel AI-videogenerator.

- **Kilde:** Kap. 35 (l. 1556) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P0 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Planer og MVP inkluderer manus, 2D-animatic, lyd og montering uavhengig av AI.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser

#### REQ-0518 – Sporbarhet til felles prosjektstruktur
Animatic Studio skal bygges som en sammenhengende, profesjonell filmproduksjonsapplikasjon, der manus, visuelt materiale, lyd, produksjonsvarianter og endelig film alltid kan spores tilbake til den samme gjennomarbeidede prosjektstrukturen.

- **Kilde:** Kap. 35 (l. 1557) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P0 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - For ethvert medieklipp, lydspor og eksport kan man spore tilbake til scene-ID, produksjon og manusversjon.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser
- **Merknad:** Gjentar kap. 2 / INV-01 som overordnet mål.

#### REQ-0519 – Overordnet mål: kreativ kontroll og teknisk automatisering
Det overordnede målet er å gi filmskaperen full kreativ kontroll fra manus til ferdig film, samtidig som programmet automatiserer det tekniske arbeidet som ellers gjør produksjonen tungvint, kostbar og vanskelig å holde oversikt over.

- **Kilde:** Kap. 35 (l. 1558-1559) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Funksjonsforslag vurderes mot både kreativ kontroll (brukerstyrt) og reduksjon av teknisk arbeid.
- **Tester:**
  - manuell: gjennomgang av arbeidsleveranser
- **Merknad:** Linje 1558/1559 duplikat. Overordnet mål, vanskelig å teste direkte.

### Tillegg etter mandatet (brukerbeslutninger og tekniske anbefalinger)

#### REQ-0520 – Flere brukere per prosjekt
Et prosjekt skal kunne ha flere brukere (prosjektmedlemmer) som arbeider i det samme prosjektet.

- **Kilde:** Beslutning DEC-0003 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** COLLAB, CORE, SECURITY · **Invarianter:** INV-C2
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et prosjekt med eier A, når B blir medlem, så ser både A og B det samme prosjektet, de samme produksjonene og det samme manuset.
- **Tester:**
  - integrasjon: to testbrukere med medlemskap leser samme prosjekt; tredje bruker uten medlemskap får avslag
- **Implementering:** db/migrations/0001_core.sql
- **Merknad:** Ikke nevnt i mandatet v14. Lagt til av Mars 2026-10-08 som viktig for arbeidsdeling og arbeidsflyt.

#### REQ-0521 – Invitere brukere inn i prosjekt
Brukeren som oppretter et prosjekt skal kunne invitere andre brukere inn i prosjektet.

- **Kilde:** Beslutning DEC-0003 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** COLLAB, SECURITY, UI
- **Avhengigheter:** REQ-0520
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt prosjekteier A, når A inviterer en e-postadresse og mottakeren aksepterer, så blir mottakeren medlem av prosjektet.
  - En invitasjon gir aldri tilgang til andre prosjekter enn det den gjelder.
- **Tester:**
  - e2e: eier inviterer, mottaker aksepterer, medlem ser prosjektet
  - integrasjon: invitasjonstoken for prosjekt X gir ikke tilgang til prosjekt Y
- **Implementering:** db/migrations/0001_core.sql#create_invitation, src/app/projects/ProjectOverview.tsx, src/routes/invitasjon.tsx

#### REQ-0522 – Flere brukere på samme manus
Flere prosjektmedlemmer skal kunne arbeide på det samme manuset uten at hverandres endringer går tapt.

- **Kilde:** Beslutning DEC-0003 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** COLLAB, SCRIPT, VERSION · **Invarianter:** INV-01, INV-03, INV-C1
- **Avhengigheter:** REQ-0520; REQ-0526
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt to medlemmer som redigerer ulike manusblokker samtidig, så bevares begge endringene.
  - Gitt to medlemmer som redigerer samme manusblokk samtidig, så tapes ingen av endringene i stillhet; konflikten vises og kan løses.
- **Tester:**
  - integrasjon: samtidig redigering av ulike blokker – begge bevart
  - integrasjon: samtidig redigering av samme blokk – konflikt oppdages, ingen stille overskriving
- **Implementering:** src/core/commands/apply.ts, src/app/project/use-commands.ts
- **Merknad:** Begge kriteriene håndheves i kjernen og databasen (testet), men ingen test viser at konflikten vises i grensesnittet, og den avviste endringen må skrives inn på nytt.

#### REQ-0523 – Prosjektroller
Prosjektmedlemskap skal ha en rolle som styrer hva medlemmet kan gjøre. Foreslåtte roller er eier, redaktør, kommentator og leser.

- **Kilde:** Beslutning DEC-0010 · **Opprinnelse:** teknisk-anbefaling · **Type:** sikkerhet · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** COLLAB, SECURITY · **Invarianter:** INV-C2
- **Avhengigheter:** REQ-0520
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En leser kan ikke endre manus, ressurser, produksjoner eller innstillinger.
  - Bare eier kan endre roller, fjerne eier eller slette prosjektet.
- **Tester:**
  - integrasjon: rollematrise – hver rolle prøver hver skriveoperasjon mot backend
- **Implementering:** db/migrations/0001_core.sql
- **Merknad:** Teknisk utledning av DEC-0003 (bekreftet). Selve løsningen er teknisk anbefaling (DEC-0010). Rollesettet er Claudes anbefaling, ikke vedtatt av Mars. Kan justeres.

#### REQ-0524 – Tilgangskontroll håndheves i backend
Tilgang til alle prosjektdata og mediefiler skal håndheves i backend (radnivåsikkerhet og lagringsregler), ikke bare i grensesnittet.

- **Kilde:** Beslutning DEC-0010 · **Opprinnelse:** teknisk-anbefaling · **Type:** sikkerhet · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** COLLAB, SECURITY, CORE · **Invarianter:** INV-C2
- **Avhengigheter:** REQ-0520
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En innlogget bruker uten medlemskap får ingen rader og ingen mediefiler fra prosjektet ved direkte API-kall.
- **Tester:**
  - integrasjon: direkte databasekall som ikke-medlem returnerer tomt / avslag for alle prosjekttabeller
  - integrasjon: signert medie-URL kan ikke genereres av ikke-medlem
- **Implementering:** db/migrations/0001_core.sql
- **Merknad:** Teknisk utledning av DEC-0003 (bekreftet). Selve løsningen er teknisk anbefaling (DEC-0010). Sikkerhetskritisk; nødvendig for REQ-0521.

#### REQ-0525 – Endringer registreres med bruker
Alle vesentlige endringer og beslutninger (godkjenning av avvik, aktiv versjon, publisering, kostnadsgodkjenning) skal registreres med hvilken bruker som utførte dem og når.

- **Kilde:** Beslutning DEC-0010 · **Opprinnelse:** teknisk-anbefaling · **Type:** data · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** COLLAB, VERSION · **Invarianter:** INV-08
- **Avhengigheter:** REQ-0520
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Historikken for en scene viser hvem som gjorde hver endring.
- **Tester:**
  - dataintegritet: alle versjonsposter har forfatter-ID og tidspunkt
- **Implementering:** db/migrations/0001_core.sql#change_log
- **Merknad:** Teknisk utledning av DEC-0003 (bekreftet). Selve løsningen er teknisk anbefaling (DEC-0010).

#### REQ-0526 – Samtidighet uten datatap
Systemet skal oppdage samtidige endringer på samme objekt og aldri overskrive en annens endring i stillhet. Medlemmene skal kunne se hvem som arbeider hvor i prosjektet.

- **Kilde:** Beslutning DEC-0010 · **Opprinnelse:** teknisk-anbefaling · **Type:** arkitektur · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** COLLAB, CORE, VERSION · **Invarianter:** INV-13, INV-C1
- **Avhengigheter:** REQ-0520
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En skriving basert på en utdatert versjon av et objekt avvises eller flettes kontrollert, aldri overskrives blindt.
  - Når to medlemmer har samme scene åpen, ser begge at den andre er der.
- **Tester:**
  - integrasjon: optimistisk versjonskontroll – skriving med gammel revisjon avvises
  - e2e: tilstedeværelse vises for to samtidige brukere
- **Implementering:** src/core/commands/apply.ts, db/migrations/0001_core.sql#apply_changes
- **Merknad:** Teknisk utledning av DEC-0003 (bekreftet). Selve løsningen er teknisk anbefaling (DEC-0010).

#### REQ-0527 – Angre per bruker
Angre og gjør om skal gjelde brukerens egne endringer og ikke reversere andre medlemmers uavhengige endringer.

- **Kilde:** Beslutning DEC-0010 · **Opprinnelse:** teknisk-anbefaling · **Type:** ux · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** COLLAB, VERSION, UI · **Invarianter:** INV-08
- **Avhengigheter:** REQ-0522
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt at A og B har endret ulike blokker, når A angrer, så reverseres bare A sin endring.
- **Tester:**
  - integrasjon: angre for bruker A berører ikke B sine endringer
- **Implementering:** src/core/commands/apply.ts, src/app/project/use-commands.ts
- **Merknad:** Angrelisten er lokal per bruker og bruker inverser med revisjonskontroll, men ingen test viser at A sin angring lar B sin endring stå.

#### REQ-0528 – Kostnadsgodkjenning er rollestyrt
Eiere og redaktører kan starte betalte AI-genereringer innenfor prosjektets budsjett og kostnadstaket for nøkkelen; kommentatorer og lesere kan ikke. Bare eieren kan endre AI-budsjettet, og bare nøkkeleieren kan endre kostnadstaket (DEC-0077, Mars' beslutning).

- **Kilde:** Beslutning DEC-0010, DEC-0018 · **Opprinnelse:** teknisk-anbefaling · **Type:** sikkerhet · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** COLLAB, QUALITYCOST, SECURITY · **Invarianter:** INV-12, INV-C3
- **Avhengigheter:** REQ-0523
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En kommentator eller leser får ikke startet en betalt jobb; forsøket gir tydelig melding.
  - En redaktør kan starte en betalt jobb innenfor budsjett og kostnadstak, men kan ikke endre budsjettet.
- **Tester:**
  - integrasjon: backend avviser betalt jobb fra medlem uten kostnadsrett
- **Implementering:** src/adapters/ai/generate-image.functions.ts, src/adapters/ai/generate-image.functions.ts (budsjettport), src/core/commands/apply.ts (SetAiBudget), src/adapters/storage/commands.functions.ts (bare eier)
- **Merknad:** Teknisk utledning av DEC-0003 (bekreftet). Selve løsningen er teknisk anbefaling (DEC-0010). Hvem som eier API-nøklene i et delt prosjekt er et åpent spørsmål (OPEN_QUESTIONS Q-01, DEC-0018 – midlertidig antakelse). DEC-0021: Mars betaler alle API-kostnader i testfasen; kostnadsdeling avtales utenfor appen.

#### REQ-0529 – Fjerning av medlem er ikke-destruktiv
Når et medlem fjernes eller en invitasjon trekkes tilbake, skal medlemmets tidligere bidrag og historikk bevares i prosjektet.

- **Kilde:** Beslutning DEC-0010 · **Opprinnelse:** teknisk-anbefaling · **Type:** data · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** COLLAB, VERSION · **Invarianter:** INV-13
- **Avhengigheter:** REQ-0520
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Etter at B er fjernet, finnes alle scener og versjoner B laget fortsatt, med B som forfatter i historikken.
- **Tester:**
  - dataintegritet: fjerning av medlem sletter ingen prosjektdata
- **Implementering:** db/migrations/0023_member_removal_planned.sql#remove_member, src/app/projects/MembersSection.tsx
- **Merknad:** Teknisk utledning av DEC-0003 (bekreftet). Selve løsningen er teknisk anbefaling (DEC-0010).

### Kapittel 1

#### REQ-0530 – Claudes rolle i prosjektet
Claude skal være Mars' langsiktige tekniske arkitekt, produktdesigner, UX-designer, systemutvikler og kreative utviklingspartner i arbeidet med å utvikle Animatic Studio.

- **Kilde:** Kap. 1 (l. 6) · **Opprinnelse:** mandat · **Type:** prosess · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROCESS
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Hver arbeidsøkt følger CLAUDE.md: leser relevante krav og beslutninger før endringer og oppdaterer handover etterpå.
- **Tester:**
  - manuell: milepælsrevisjon kontrollerer at arbeidsprosessen er fulgt
- **Merknad:** Tilføyd etter automatisk linjedekningskontroll.

### Tillegg etter mandatet (brukerbeslutninger og tekniske anbefalinger)

#### REQ-0531 – Vis kun valgt scene i manusvisningen
Manusvisningen skal ha en avkrysningsboks «Vis kun valgt scene». Når den er krysset av, viser manussidene bare scenen som er valgt i scenelisten. Dette er bare et visningsvalg og endrer ikke produksjonens aktive innhold.

- **Kilde:** Beslutning DEC-0027 · **Opprinnelse:** brukerbeslutning · **Type:** ux · **Prioritet:** P2 · **Fase:** 2
- **Moduler:** SCRIPT, UI · **Invarianter:** INV-14
- **Avhengigheter:** REQ-0075
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt at scene 13 er valgt og boksen er krysset av, så viser manussidene bare scene 13, med samme sidetall som i hele manuset.
  - Når en annen scene velges, vises den i stedet; når boksen tas av, vises hele manuset igjen.
  - Filmens aktive innhold, scenerekkefølge og eksport er uendret (REQ-0075).
- **Tester:**
  - enhet: filtrering av sider på valgt scene
  - visuell: skjermbilde med boksen avkrysset
- **Implementering:** src/core/screenplay/filter.ts#filterPages, src/app/script/ScriptWorkspace.tsx
- **Merknad:** Ikke i mandatet v14. Lagt til av Mars 2026-10-09 («I denne visningen av manus ønsker jeg en avkrysningsboks som sier vis kun valgte scene»).

#### REQ-0532 – Rekkefølge og synlighet endres bare i redigeringsmodus
Scenerekkefølgen og om en scene er aktiv eller deaktivert skal bare kunne endres når brukeren har slått på en egen bryter «Endre rekkefølge og synlighet». Bryteren er av som standard.

- **Kilde:** Beslutning DEC-0029 · **Opprinnelse:** brukerbeslutning · **Type:** ux · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT, UI
- **Avhengigheter:** REQ-0062
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Når bryteren er av, kan scener ikke dras eller flyttes med tastaturet, og aktiv/deaktivert kan ikke endres.
  - Når bryteren er på, kan scener flyttes og slås av og på som før.
  - Bryteren endrer ikke filmen; den gjelder bare redigeringen.
- **Tester:**
  - visuell: scenelisten uten håndtak og brytere når redigeringsmodus er av
- **Implementering:** src/app/script/SceneNavigator.tsx, src/app/script/Inspector.tsx#ScenePanel
- **Merknad:** Ikke i mandatet v14. Lagt til av Mars 2026-10-09 («det er litt for enkelt å endre rekkefølge på scener … en funksjon som bør slåes på»).

#### REQ-0533 – Flyttede scener markeres til ny versjon er lagret
Scener som er flyttet siden siste lagrede manusversjon, skal ha en annen bakgrunnsfarge i scenelisten til en ny versjon er lagret.

- **Kilde:** Beslutning DEC-0029 · **Opprinnelse:** brukerbeslutning · **Type:** ux · **Prioritet:** P2 · **Fase:** 2
- **Moduler:** SCRIPT, UI
- **Avhengigheter:** REQ-0078
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en lagret versjon, når scene 12 flyttes, så får scene 12 (og bare den) en annen bakgrunnsfarge.
  - Når en ny versjon lagres, forsvinner markeringen.
  - Finnes ingen lagret versjon, markeres ingen scener.
- **Tester:**
  - enhet: flyttede scener mot siste versjon
  - visuell: markert scene i scenelisten
- **Implementering:** src/core/screenplay/versions.ts#movedOccurrences, src/app/script/SceneNavigator.tsx
- **Merknad:** Ikke i mandatet v14. Lagt til av Mars 2026-10-09 («scener som er flyttet på bør også ha en litt annen bakgrunnsfarge inntill de er lagret i ny versjon»).

#### REQ-0534 – Sammenligning viser hva som er endret
Sammenligningen av manusversjoner skal vise hva som faktisk er endret i hver scene: endrede linjer med tekst før og etter, nye og fjernede linjer, og for flyttede scener hvor scenen sto før og står nå.

- **Kilde:** Beslutning DEC-0029 · **Opprinnelse:** brukerbeslutning · **Type:** ux · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT, UI
- **Avhengigheter:** REQ-0078
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Når en replikk er endret, vises gammel og ny tekst med de endrede ordene uthevet.
  - Når en scene er flyttet, vises gammel og ny plassering (for eksempel «fra plass 12 til plass 4, etter scene 3»).
  - Nye og fjernede linjer vises med tekst.
- **Tester:**
  - enhet: linjeforskjeller per scene
- **Implementering:** src/core/screenplay/versions.ts#sceneLineChanges, src/core/screenplay/versions.ts#wordDiff, src/app/script/VersionsDialog.tsx
- **Merknad:** Ikke i mandatet v14. Lagt til av Mars 2026-10-09 («beskrivelsen om hva som er endret er litt kort»).

#### REQ-0535 – Notater på ord, setninger og scener
Brukeren skal kunne legge inn frie notater festet til et ord eller en setning i manuset, eller som en nål på scenen.

- **Kilde:** Beslutning DEC-0031 · **Opprinnelse:** brukerbeslutning · **Type:** ux · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT, UI
- **Avhengigheter:** REQ-0070
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Når brukeren merker «den blå vasen» og legger inn et notat, markeres de ordene og notatet vises i inspektøren.
  - En nål på scenen vises ved sceneoverskriften.
  - Endres teksten, finnes de markerte ordene igjen; er de borte, sier notatet det.
- **Tester:**
  - enhet: notater på tekst og scene, ny plassering etter tekstendring
  - visuell: markert notat og nytt notat fra markert tekst
- **Implementering:** src/core/notes/index.ts, src/core/commands/apply.ts#AddAnnotations, src/app/script/NotesPanel.tsx, src/app/script/ScriptWorkspace.tsx
- **Merknad:** Ikke i mandatet v14. Lagt til av Mars 2026-10-09 (notater i manus).

#### REQ-0536 – Notater stemples med hvem og når
Hvert notat skal vise i hjørnet, med liten tekst, hvem som la det inn og når.

- **Kilde:** Beslutning DEC-0031 · **Opprinnelse:** brukerbeslutning · **Type:** ux · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT, UI
- **Avhengigheter:** REQ-0535
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Et notat Mars skriver kl. 14.32 viser «Mars · 9. okt. 2026 kl. 14:32» i hjørnet.
- **Tester:**
  - visuell: stempel i hjørnet
- **Implementering:** src/core/notes/index.ts#formatStamp, src/app/script/NotesPanel.tsx
- **Merknad:** Ikke i mandatet v14. Lagt til av Mars 2026-10-09 (notater i manus).

#### REQ-0537 – Sletting av notat med advarsel
Notater skal enkelt kunne slettes, med en liten advarsel før sletting.

- **Kilde:** Beslutning DEC-0031 · **Opprinnelse:** brukerbeslutning · **Type:** ux · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT, UI
- **Avhengigheter:** REQ-0535
- **Status:** Verifisert
- **Akseptansekriterier:**
  - «Slett» viser en bekreftelse; «Avbryt» lar notatet stå.
  - Sletting kan angres.
- **Tester:**
  - enhet: sletting og angre
- **Implementering:** src/app/script/NotesPanel.tsx, src/core/commands/apply.ts#SetAnnotationRemoved
- **Merknad:** Ikke i mandatet v14. Lagt til av Mars 2026-10-09 (notater i manus).

#### REQ-0538 – Vis eller skjul notater
Grensesnittet skal ha en avkrysningsboks for å vise eller skjule notater i manuset.

- **Kilde:** Beslutning DEC-0031 · **Opprinnelse:** brukerbeslutning · **Type:** ux · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT, UI
- **Avhengigheter:** REQ-0535
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Når «Vis notater» er tatt av, vises ingen notatmarkeringer eller symboler på sidene.
- **Tester:**
  - visuell: notater vist
- **Implementering:** src/app/script/ScriptWorkspace.tsx, src/core/notes/index.ts#pageDecorations
- **Merknad:** Ikke i mandatet v14. Lagt til av Mars 2026-10-09 (notater i manus).

#### REQ-0539 – Søk i notater
Søkefunksjonen skal også gi treff i notatene.

- **Kilde:** Beslutning DEC-0031 · **Opprinnelse:** brukerbeslutning · **Type:** ux · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT, UI
- **Avhengigheter:** REQ-0073
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Søk etter et ord som bare står i et notat, viser scenen med notatet.
- **Tester:**
  - enhet: søk treffer notater
- **Implementering:** src/core/screenplay/filter.ts#matchingOccurrences, src/core/notes/index.ts#searchHits
- **Merknad:** Ikke i mandatet v14. Lagt til av Mars 2026-10-09 (notater i manus).

#### REQ-0540 – Notater i eksport og ny import
Notater skal kunne tas med i eksporten (av som standard), slik at en ny import av dokumentet gjenskaper notatene på samme sted med samme navn og tidspunkt.

- **Kilde:** Beslutning DEC-0031 · **Opprinnelse:** brukerbeslutning · **Type:** ux · **Prioritet:** P1 · **Fase:** 2
- **Moduler:** SCRIPT, EXPORT, UI
- **Avhengigheter:** REQ-0087; REQ-0088; REQ-0535
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Eksport til Word med «Ta med notater» gir Word-kommentarer på riktig tekst.
  - Eksport til PDF gir PDF-merknader.
  - Import av filen lager de samme notatene igjen.
  - Uten avkrysning har eksporten ingen notater.
- **Tester:**
  - enhet: rundtur Word og PDF med notater
- **Implementering:** src/core/notes/transfer.ts, src/engine/export/screenplay-docx.ts, src/engine/export/screenplay-pdf.ts, src/engine/import/docx-lines.ts#docxToLinesAndNotes, src/engine/import/pdf-lines.ts#pdfToLinesAndNotes, src/app/script/ExportDialog.tsx, src/app/script/ImportDialog.tsx
- **Merknad:** Ikke i mandatet v14. Lagt til av Mars 2026-10-09 (notater i manus).

#### REQ-0541 – Søketreff vises tydelig, men diskret
Søket skal vise hva det traff, tydelig men diskret: treffene markeres i manuset, og scenelisten sier hva som ble truffet.

- **Kilde:** Beslutning DEC-0031 · **Opprinnelse:** brukerbeslutning · **Type:** ux · **Prioritet:** P2 · **Fase:** 2
- **Moduler:** SCRIPT, UI
- **Avhengigheter:** REQ-0073
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Søk etter «vasen» markerer ordet på sidene og viser «Treff: handling» ved scenen.
- **Tester:**
  - enhet: hva søket traff
  - visuell: søketreff
- **Implementering:** src/core/notes/index.ts#searchHits, src/app/script/ScriptPageView.tsx, src/app/script/SceneNavigator.tsx
- **Merknad:** Ikke i mandatet v14. Lagt til av Mars 2026-10-09.

#### REQ-0542 – Scenelisten følger manuset når du blar
Når brukeren blar i manuset, skal scenelisten til venstre vise hvilken scene som vises.

- **Kilde:** Beslutning DEC-0031 · **Opprinnelse:** brukerbeslutning · **Type:** ux · **Prioritet:** P2 · **Fase:** 2
- **Moduler:** SCRIPT, UI
- **Avhengigheter:** REQ-0217
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Når scene 11 står øverst i visningen, er scene 11 markert i listen og synlig der.
- **Tester:**
  - visuell: blaing i manus
- **Implementering:** src/app/script/ScriptWorkspace.tsx#updateInView, src/app/script/SceneNavigator.tsx
- **Merknad:** Ikke i mandatet v14. Lagt til av Mars 2026-10-09.

#### REQ-0543 – Valgt scene vises øverst
Når brukeren klikker en scene i scenelisten, skal sceneoverskriften vises øverst i manusvisningen.

- **Kilde:** Beslutning DEC-0031 · **Opprinnelse:** brukerbeslutning · **Type:** ux · **Prioritet:** P2 · **Fase:** 2
- **Moduler:** SCRIPT, UI
- **Avhengigheter:** REQ-0217
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Klikk på scene 3 i listen gir scene 3 sin overskrift øverst i visningen.
- **Tester:**
  - visuell: valgt scene øverst
- **Implementering:** src/app/script/ScriptWorkspace.tsx#scrollTo, src/app/script/ScriptPageView.tsx
- **Merknad:** Ikke i mandatet v14. Lagt til av Mars 2026-10-09 («det bør være i toppen»).

#### REQ-0544 – Ryddige karakternavn i forslag
Karakterforslag fra manuset skal ha ryddige navn: replikknavn med tall, grupper («X OG Y»), «X TIL Y» og beskrivelser («OLA SMILENDE») ryddes, og nesten like skrivemåter slås sammen som mulig skrivefeil.

- **Kilde:** Beslutning DEC-0034 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** LIBRARY, SCRIPT, UI
- **Avhengigheter:** REQ-0128
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt replikknavnene «OLA 2», «OLA SMILENDE» og «OLA TIL KARI», når forslagene lages, så foreslås ett navn «OLA»; «X OG Y» gir to karakterer.
  - Gitt to nesten like skrivemåter, så slås de sammen til ett forslag og den andre skrivemåten vises som mulig skrivefeil.
- **Tester:**
  - enhet: rydding av replikknavn (cleanSpeaker)
  - enhet: sammenslåing av skrivefeil (mergeTypos)
- **Implementering:** src/core/library/suggest.ts#cleanSpeaker, src/core/library/suggest.ts#mergeTypos
- **Merknad:** Ikke i mandatet v14. Lagt til av Mars 2026-10-09 (gratis regelbasert gjenkjenning av ressurser i manuset).

#### REQ-0545 – Navngitte ting uten replikk foreslås
Navngitte ting som aldri har replikk skal foreslås: navn med stor forbokstav midt i setning som forekommer minst to ganger i minst to scener; eieform av kjente navn utelates. Typen er en gjetning som brukeren velger.

- **Kilde:** Beslutning DEC-0034 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** LIBRARY, SCRIPT, UI
- **Avhengigheter:** REQ-0128
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et navn med stor forbokstav midt i setning som står minst to ganger i minst to scener, så foreslås det, og brukeren velger type.
  - Gitt eieform av et kjent navn (f.eks. «Olas»), så foreslås det ikke som egen ting.
- **Tester:**
  - enhet: forslag av navngitte ting uten replikk
- **Implementering:** src/core/library/suggest.ts
- **Merknad:** Ikke i mandatet v14. Lagt til av Mars 2026-10-09 (gratis regelbasert gjenkjenning av ressurser i manuset).

#### REQ-0546 – Lokasjoner slås sammen i forslag
Lokasjoner med preposisjon, annen bøyning eller sammensatt sted skal slås sammen til én lokasjon i forslagene («PÅ TUNET», «KJØKKENET», «GÅRD, TUNET» gir TUNET og KJØKKEN).

- **Kilde:** Beslutning DEC-0034 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** LIBRARY, SCRIPT, UI
- **Avhengigheter:** REQ-0128
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt «PÅ TUNET», «TUNET» og «GÅRD, TUNET» i scenoverskrifter, så foreslås lokasjonen TUNET én gang.
  - Gitt «KJØKKENET» og «KJØKKEN», så foreslås KJØKKEN én gang.
- **Tester:**
  - enhet: sammenslåing av lokasjoner
- **Implementering:** src/core/library/suggest.ts
- **Merknad:** Ikke i mandatet v14. Lagt til av Mars 2026-10-09 (gratis regelbasert gjenkjenning av ressurser i manuset).

#### REQ-0547 – Objekter og rekvisitter foreslås som usikre
Objekter og rekvisitter som går igjen i handlingen (substantiv etter en/ei/et eller foran sin/hans, i minst 3 scener) skal foreslås som usikre forslag.

- **Kilde:** Beslutning DEC-0034 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** LIBRARY, SCRIPT, UI
- **Avhengigheter:** REQ-0128
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et substantiv etter «en», «ei» eller «et», eller foran «sin»/«hans», i minst tre scener, så foreslås det som usikkert objekt.
  - Gitt et substantiv i færre enn tre scener, så foreslås det ikke.
- **Tester:**
  - enhet: forslag av objekter og rekvisitter
- **Implementering:** src/core/library/suggest.ts
- **Merknad:** Ikke i mandatet v14. Lagt til av Mars 2026-10-09 (gratis regelbasert gjenkjenning av ressurser i manuset).

#### REQ-0548 – Forslag viser bevis og kan skjules
Forslagene skal vise bevis (scenenumre og andre skrivemåter); usikre forslag skal ikke være valgt på forhånd; skrivemåtene blir alternative navn; og forslag kan skjules per bruker.

- **Kilde:** Beslutning DEC-0034 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** LIBRARY, SCRIPT, UI
- **Avhengigheter:** REQ-0128
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt et forslag, så vises scenenumre og andre skrivemåter som bevis.
  - Gitt et usikkert forslag, så er det ikke avkrysset på forhånd.
  - Når forslaget godtas, lagres skrivemåtene som alternative navn.
  - Når brukeren skjuler et forslag, forsvinner det for den brukeren.
- **Tester:**
  - visuell: forslagsdialog med bevis
- **Implementering:** src/app/library/SuggestionsDialog.tsx
- **Merknad:** Ikke i mandatet v14. Lagt til av Mars 2026-10-09 (gratis regelbasert gjenkjenning av ressurser i manuset).

#### REQ-0549 – Ressursene i scenen kan dras inn i sceneeditoren
Når en scene er åpnet i sceneeditoren, skal karakterene, stedene, objektene og andre ressurser fra biblioteket som er brukt i scenen vises med bilde. De skal kunne dras inn på lerretet som nye lag øverst, og et klikk skal åpne ressursen i biblioteket der bilder legges inn.

- **Kilde:** Beslutning DEC-0037 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** COMPOSE, LIBRARY, UI
- **Avhengigheter:** REQ-0171
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt en scene der Maja har replikk og Maja finnes i biblioteket, så vises Maja under «I denne scenen».
  - Når Maja dras inn på lerretet, får scenen et nytt lag øverst der hun slippes.
  - Når navnet klikkes, åpnes Maja i Ressursbiblioteket.
- **Tester:**
  - enhet: assetsInScene
  - visuell: dra ressurs inn på lerretet
- **Implementering:** src/core/library/index.ts#assetsInScene, src/app/scene-editor/SceneAssetsPanel.tsx, src/app/scene-editor/Stage.tsx (onDrop), src/routes/prosjekt.$projectId.bibliotek.tsx (?asset=)
- **Merknad:** Ikke i mandatet v14. Generering av bilder fra biblioteket kommer med AI-fasen (M5).

#### REQ-0550 – Justerbare paneler som huskes
Der løsningen har paneler som ruller hver for seg, skal brukeren kunne endre bredden (eller høyden) ved å dra i rammen, og størrelsen skal huskes når brukeren går rundt i løsningen.

- **Kilde:** Beslutning DEC-0038 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 3
- **Moduler:** UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Når scenelisten i manuset gjøres bredere og brukeren går til biblioteket og tilbake, har scenelisten samme bredde.
  - Dobbeltklikk på rammen gir standardbredden.
- **Tester:**
  - visuell: justert panel huskes
- **Implementering:** src/app/shell/pane-size.tsx
- **Merknad:** Ikke i mandatet v14. Størrelsene lagres i nettleseren (KI-47).

#### REQ-0551 – Bildeformat og bildefrekvens for hele prosjektet
Bildeformat og bildefrekvens skal settes på prosjektoversikten og gjelde alle scener. Ved endring skal alle 2D-scener tilpasses i én endring som kan angres.

- **Kilde:** Beslutning DEC-0039 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** COMPOSE, TIMELINE, UI
- **Avhengigheter:** REQ-0183
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Gitt prosjektet i 1920 × 1080 og 25 bilder/s, når det endres til 3840 × 2160 og 24 bilder/s, så får alle 2D-scener nytt format, lag og kamera skaleres og tider regnes om.
  - Når endringen angres, er alt som før.
- **Tester:**
  - enhet: formatMapping, SetProjectFormat og angre
  - database: prosjektraden endres med revisjonskontroll
- **Implementering:** src/core/composition/format.ts, src/core/commands/apply.ts (SetProjectFormat, UndoSetProjectFormat), db/migrations/0008_project_format.sql, src/app/projects/ProjectFormat.tsx
- **Merknad:** Ikke i mandatet v14 som eget punkt; presiserer 12.1 (format) for hele prosjektet.

#### REQ-0552 – Sammenleggbar meny
Menyen til venstre skal kunne legges sammen til en smal stripe med ikoner, og valget skal huskes.

- **Kilde:** Beslutning DEC-0040 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 3
- **Moduler:** UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Når knappen øverst i menyen trykkes, vises bare ikonene, og valget står seg når brukeren går til en annen arbeidsflate.
- **Tester:**
  - visuell: sammenslått meny
- **Implementering:** src/app/shell/ProjectNav.tsx, src/app/shell/pane-size.tsx#useStoredFlag
- **Merknad:** Ikke i mandatet v14.

#### REQ-0553 – Scenevelger med søk i sceneeditoren
Sceneeditoren skal velge scene med en nedtrekksliste med søk (nummer, sted, tid) og knapper for forrige og neste scene, i stedet for en fast sceneliste.

- **Kilde:** Beslutning DEC-0040 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** UI, COMPOSE
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Når brukeren skriver «fjøset» i scenevelgeren, vises bare scenene på fjøset, og Enter åpner den markerte.
- **Tester:**
  - visuell: scenevelger med søk
- **Implementering:** src/app/scene-editor/ScenePicker.tsx
- **Merknad:** Ikke i mandatet v14.

#### REQ-0554 – Forhåndsvisning av ferdig utsnitt
Sceneeditoren skal ha et eget vindu som viser det ferdige utsnittet (kamera, parallakse og animerte lag) på gjeldende bilde. Det kan vises manuelt eller automatisk ved avspilling («Automatisk visning»).

- **Kilde:** Beslutning DEC-0040 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** COMPOSE, CAMERA, UI
- **Avhengigheter:** REQ-0197
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Når «Forhåndsvisning» er på, viser vinduet bildet slik det blir i filmen på gjeldende bilde.
  - Når «Automatisk visning» er på og scenen spilles av, vises vinduet uten at det er slått på manuelt.
- **Tester:**
  - visuell: forhåndsvisning med kamera
- **Implementering:** src/app/scene-editor/PreviewWindow.tsx, src/app/scene-editor/SceneEditorWorkspace.tsx
- **Merknad:** Ikke i mandatet v14 som eget punkt; utdyper 12.5 (visuell forhåndsvisning).

#### REQ-0555 – Forhåndsvisning: flytt, størrelse fra hjørnet og zoom
Forhåndsvisningen av ferdig utsnitt skal kunne flyttes, endres i størrelse fra hjørnene og vises med zoom «Tilpass», 25 %, 50 %, 1:1 og 200 %. Størrelse, plassering og zoom huskes når vinduet lukkes og åpnes igjen, også automatisk ved avspilling.

- **Kilde:** Beslutning DEC-0041 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** COMPOSE, UI
- **Avhengigheter:** REQ-0554
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Å dra i et hjørne endrer størrelsen med bildets sideforhold, og zoom går til «Tilpass».
  - Å velge 1:1 viser ett bildepunkt per skjermpunkt og gjør vinduet så stort som bildet (eller rullbart).
  - Etter lukking og ny visning (manuelt eller ved avspilling) står vinduet på samme plass og i samme størrelse.
- **Tester:**
  - visuell: forhåndsvisning flyttet, endret og zoomet; plassering husket
- **Implementering:** src/app/scene-editor/PreviewWindow.tsx, src/app/shell/pane-size.tsx
- **Merknad:** Utdyper 12.5 (visuell forhåndsvisning).

#### REQ-0556 – Forhåndsvisning i eget vindu (flere skjermer)
Forhåndsvisningen skal kunne åpnes i et eget vindu som kan legges på en annen skjerm. Vinduets plassering, størrelse og zoom huskes, og det kan legges tilbake i redigeringsvinduet.

- **Kilde:** Beslutning DEC-0041 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 3
- **Moduler:** COMPOSE, UI
- **Avhengigheter:** REQ-0554
- **Status:** Verifisert
- **Akseptansekriterier:**
  - «Åpne i eget vindu» viser det ferdige utsnittet i et eget vindu som følger avspillingen.
  - Neste gang det åpnes, får det samme størrelse og (der nettleseren tillater det) samme plassering.
  - Mellomrom i det egne vinduet starter og stopper avspillingen.
- **Tester:**
  - visuell: eget vindu, gjenåpnet med husket størrelse
- **Implementering:** src/app/scene-editor/PreviewWindow.tsx, src/app/scene-editor/SceneEditorWorkspace.tsx
- **Merknad:** Plassering på en annen skjerm avhenger av nettleseren (KI-50). Selve flyttingen mellom skjermer kan ikke testes automatisk (hodeløs nettleser).

#### REQ-0557 – Forhåndsvisningen kan flyttes fritt over hele programmet
Det flytende forhåndsvisningsvinduet i sceneeditoren skal kunne flyttes hvor som helst i programvinduet (også over menyen og panelene), ikke bare innenfor lerretet. Plasseringen huskes.

- **Kilde:** Beslutning DEC-0042 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** COMPOSE, UI
- **Avhengigheter:** REQ-0555
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Vinduet kan dras over menyen til venstre og panelene til høyre, og holdes innenfor programvinduet.
  - Plasseringen er den samme etter at vinduet er lukket og åpnet igjen.
- **Tester:**
  - visuell: forhåndsvisning dratt helt til venstre
- **Implementering:** src/app/scene-editor/PreviewWindow.tsx

#### REQ-0558 – Lyd spilles også der animasjonen ikke er laget
Lyd i en scene skal spilles av og eksporteres selv om scenen ikke har 2D-scene ennå. En scene uten satt lengde skal være minst så lang som lyden i den.

- **Kilde:** Beslutning DEC-0044 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** AUDIO, TIMELINE
- **Avhengigheter:** REQ-0208; REQ-0240
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Lyd i en scene med tittelkort høres ved avspilling og er med i eksportert video.
  - En scene uten satt lengde varer minst til den siste lyden i scenen slutter.
- **Tester:**
  - enhet: lengde forlenges av lyd
- **Implementering:** src/core/assembly/film.ts, src/core/composition/animate.ts, src/app/audio/use-audio-playback.ts

#### REQ-0559 – Dobbeltklikk på et lag: velg, last opp eller generer bilde
Dobbeltklikk på et lag i sceneeditoren skal åpne et vindu der brukeren kan velge et annet bilde laget for samme ressurs (alle varianter og versjoner), laste opp et nytt bilde, eller starte AI-generering av et nytt bilde for ressursen.

- **Kilde:** Beslutning DEC-0044 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** COMPOSE, LIBRARY, UI
- **Avhengigheter:** REQ-0557
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Dobbeltklikk på laget i lerretet eller lagslisten åpner bildevalget for laget.
  - Et valgt bilde brukes på laget med én gang; et opplastet bilde blir ny versjon i biblioteket.
  - AI-generering krever kostnadsgodkjenning før noe sendes (kommer med M5).
- **Tester:**
  - visuell: bildevalg for lag
- **Implementering:** src/app/scene-editor/LayerImageDialog.tsx, src/app/scene-editor/Stage.tsx, src/app/scene-editor/LayersPanel.tsx, src/app/library/GenerateImagePanel.tsx, src/adapters/ai/generate-image.functions.ts
- **Merknad:** AI-delen henger sammen med REQ for genereringsmotor og kostnadsport (fase 5).

#### REQ-0560 – Lyd i scenene rundt: bla og bruk i scenen
Når brukeren jobber med en scene, skal lydressursene som er brukt i scenen før, scenen før der osv. (og scenene etter) være lett synlige. Brukeren kan bla bakover og framover, lytte, og velge «Bruk i scenen» for å legge samme lyd inn i scenen.

- **Kilde:** Beslutning DEC-0045 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** AUDIO, COMPOSE, UI
- **Avhengigheter:** REQ-0555
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Panelet viser lyden i forrige scene som standard (neste scene for første scene).
  - Pilene blar scene for scene gjennom filmen.
  - «Bruk i scenen» legger inn samme lyd med spor, volum, toninger og volumpunkter fra starten av scenen; lyd som allerede finnes, merkes «I bruk».
- **Tester:**
  - enhet: lyd i scenene rundt
  - visuell: 52-scene-lyd
- **Implementering:** src/app/scene-editor/NearbyAudioPanel.tsx, src/core/audio/index.ts

#### REQ-0561 – Lyd som løper videre over flere scener
Et lydklipp (f.eks. et musikkstykke) forankres med starten i én scene og kan merkes «løper videre», slik at det fortsetter over de neste scenene. Slike klipp vises i en egen varmgul farge. Klipp uten merket stopper ved slutten av scenen sin.

- **Kilde:** Beslutning DEC-0045 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** AUDIO, TIMELINE, UI
- **Avhengigheter:** REQ-0555
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Lyd uten «løper videre» kuttes ved slutten av scenen den er festet til; en scene uten 2D-scene blir minst så lang som slik lyd.
  - Lyd med «løper videre» spilles og eksporteres videre inn i scenene etter, og gjør ikke scenen sin lengre.
  - Klippene og navnet deres vises varmgult i monteringen og sceneeditoren; ingen lydtype bruker den fargen.
  - Lyd som løper inn fra en tidligere scene vises i sceneeditoren for scenen den høres i.
- **Tester:**
  - enhet: lyd som løper videre
  - visuell: 50-montering-lyd, 55-scene-lyd-inn
- **Implementering:** src/core/audio/index.ts, src/app/assembly/AudioTracks.tsx, src/app/assembly/AudioClipPanel.tsx, db/migrations/0010_audio_flow_generation.sql

#### REQ-0562 – Lydprofil og volumpunkter
Hvert lydklipp skal kunne åpnes i et vindu som viser lydprofilen (bølgeformen) i stort format med tidslinjal, slik at hendelser kan times mot lyden. Volumet skal kunne trekkes opp og ned med punkter på en kurve, som i After Effects.

- **Kilde:** Beslutning DEC-0045 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** AUDIO, UI
- **Avhengigheter:** REQ-0555
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Dobbeltklikk på et lydklipp (montering eller sceneeditor) eller knappen i panelet åpner lydprofilen.
  - Klikk på kurven legger til et punkt, dra flytter, dobbeltklikk eller Delete fjerner; piltaster justerer.
  - Kurven (−60 til +12 dB, rett linje mellom punktene) ganges med klippets volum og toninger og brukes både i avspilling og eksport.
  - Punktene lagres med klippet og kan angres.
- **Tester:**
  - enhet: volumpunkter
  - visuell: 53-lydprofil
- **Implementering:** src/app/audio/AudioClipEditor.tsx, src/engine/audio/mixer.ts, src/core/commands/apply.ts

#### REQ-0563 – Lydbølger i sceneeditorens tidslinje
Sceneeditorens tidslinje skal vise lyden i scenen som bølgeformer under lagene, på samme tidsakse som nøkkelbilder og kamerautsnitt, slik at bevegelser kan times mot lyden.

- **Kilde:** Beslutning DEC-0045 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** AUDIO, COMPOSE, UI
- **Avhengigheter:** REQ-0562
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Scenens lyd og lyd som løper inn fra tidligere scener vises som egne rader.
  - Klikk går til starten av klippet; dobbeltklikk åpner lydprofilen.
- **Tester:**
  - visuell: 52-scene-lyd
- **Implementering:** src/app/scene-editor/SceneAudioRows.tsx, src/app/scene-editor/Timeline.tsx

#### REQ-0564 – Aktivt kamerautsnitt er varmgult
Bildeutsnittet kameraet viser i øyeblikket skal skifte farge fra grått til varmgult, både på lerretet og i kamerasporet i tidslinjen.

- **Kilde:** Beslutning DEC-0045 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 4
- **Moduler:** CAMERA, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Utsnittet under avspillingshodet tegnes varmgult på lerretet, også når det faller sammen med start- eller sluttrammen.
  - Kamerautsnittet under avspillingshodet får varmgul ramme i kamerasporet.
- **Tester:**
  - visuell: 52-scene-lyd
- **Implementering:** src/app/scene-editor/camera-overlay.ts, src/app/scene-editor/Timeline.tsx, src/styles.css

#### REQ-0565 – AI-bildegenerering med Lovable-kreditter (testfase)
Brukeren skal kunne generere et nytt bilde av en ressurs med AI fra bildevalget for et lag. I testfasen brukes Lovable AI Gateway og Lovable-arbeidsområdets egne kreditter. Beskrivelsen (prompten) bygges fra ressurs, variant og stil, vises og kan endres før sending, og hver generering må bekreftes.

- **Kilde:** Beslutning DEC-0045 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** PROVIDER, PROMPT, QUALITYCOST, LIBRARY, SECURITY
- **Avhengigheter:** REQ-0559
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Beskrivelsen vises i et redigerbart felt og er på engelsk.
  - Ingenting sendes før brukeren har bekreftet at genereringen bruker kreditter.
  - Bare redaktører og eiere kan generere; grenser per bruker per time og per prosjekt per døgn.
  - Hver generering logges (modell, prompt, forbilde, status, feil) i generation_jobs.
  - Resultatet blir en ny versjon i biblioteket og tas i bruk på laget; det kan angres.
  - Nøkkelen finnes bare på serveren.
- **Tester:**
  - enhet: AI-beskrivelse
  - db: generation_jobs (0010)
  - visuell: 54-ai-generering
- **Implementering:** src/adapters/ai/generate-image.functions.ts, src/core/generation/prompt.ts, src/app/library/GenerateImagePanel.tsx, src/app/scene-editor/LayerImageDialog.tsx, db/migrations/0010_audio_flow_generation.sql
- **Merknad:** Prøvd av Mars mot den ekte Lovable AI Gateway 13.10.2026.

#### REQ-0566 – Brukerne kobler egne AI-tjenester senere
Etter testfasen skal brukerne kunne koble Animatic Studio til ulike AI-tjenesters API-er (egne nøkler) som applikasjonen legger til rette for.

- **Kilde:** Beslutning DEC-0045 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** PROVIDER, SECURITY
- **Avhengigheter:** REQ-0565; REQ-0269
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Brukeren kan velge leverandør og legge inn egen nøkkel på en sikker måte (REQ-0413).
- **Tester:**
  - planlagt
- **Implementering:** src/core/generation/providers.ts, src/app/ai/ProvidersDialog.tsx, src/adapters/ai/provider-keys.functions.ts
- **Merknad:** Adapterne er ikke prøvd mot de ekte tjenestene (KI-153).

#### REQ-0567 – Slett prosjekt (bare eier)
Eieren skal kunne slette et prosjekt fra prosjektlisten. Et alvorlig vindu sier at handlingen ikke kan angres, viser hva som slettes og hvor mange som mister tilgangen, og krever at prosjektnavnet skrives inn. Ressursene (bilder og lyd) slettes ikke sammen med prosjektet.

- **Kilde:** Beslutning DEC-0046 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** UI, SECURITY, COLLAB
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Bare eieren ser og kan bruke «Slett prosjekt …»; serveren og databasen kontrollerer eierskapet på nytt.
  - Knappen er låst til prosjektnavnet er skrevet inn riktig.
  - Manus, versjoner, scener, 2D-scener, lydklipp, notater, historikk, importerte manusfiler og importert film slettes; andre medlemmer mister tilgangen.
  - Ressursene og loggen over AI-genereringer bevares hos eierne; ingen kan skrive i prosjektet etterpå.
- **Tester:**
  - db: 0011 sletting
  - visuell: 56/57
- **Implementering:** db/migrations/0011_project_delete_film.sql, src/adapters/storage/project-admin.functions.ts, src/app/projects/ProjectDangerDialogs.tsx, src/app/projects/ProjectsScreen.tsx
- **Merknad:** Mandatets vern av produsert materiale og historikk (INV-07, INV-13) gjelder i et prosjekt som er i bruk; sletting av hele prosjektet er en bevisst handling fra eieren (DEC-0046).

#### REQ-0568 – Forlat prosjekt
Den som er invitert inn i et prosjekt, skal kunne forlate det fra prosjektlisten, med et vindu som sier at det ikke kan angres. En eier kan bare forlate prosjektet når det finnes en annen eier.

- **Kilde:** Beslutning DEC-0046 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** UI, COLLAB, SECURITY
- **Status:** Verifisert
- **Akseptansekriterier:**
  - «Forlat prosjekt …» vises for inviterte (og for eiere når det finnes en annen eier).
  - Etter at man har forlatt prosjektet, ser man det ikke lenger; prosjektet og innholdet består.
  - Eneste eier får beskjed om å slette prosjektet eller gjøre en annen til eier.
- **Tester:**
  - db: 0011 forlat
  - visuell: 58
- **Implementering:** db/migrations/0011_project_delete_film.sql, src/app/projects/ProjectDangerDialogs.tsx

#### REQ-0569 – Last ned ressurser som zip
Prosjektets ressurser skal kunne lastes ned som én zip-fil, per kategori (karakterer, objekter, lokasjoner, lyd, importert film …) eller alt samlet, før sletting, fra et slettet prosjekt og fra ressursbiblioteket.

- **Kilde:** Beslutning DEC-0046 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** LIBRARY, EXPORT, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Én mappe per kategori, ressurs og variant; alle versjoner med originalt filnavn; godkjent versjon merket.
  - Kategorier kan velges bort; antall filer og størrelse vises.
  - Store filer skrives rett til disk der nettleseren støtter det; filer som ikke kan hentes, listes i MANGLER.txt.
  - Over 3,8 GB må det lastes ned i flere omganger.
- **Tester:**
  - enhet: zip med ressurser
  - visuell: 62 (med nedlasting og innholdskontroll)
- **Implementering:** src/core/library/zip.ts, src/engine/export/zip.ts, src/app/library/AssetZip.tsx

#### REQ-0570 – Slett ressursene fra et slettet prosjekt i egen operasjon
Ressursene i et slettet prosjekt skal bare kunne slettes for godt i en egen operasjon, av eieren, med eget vindu og navnebekreftelse.

- **Kilde:** Beslutning DEC-0046 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** LIBRARY, SECURITY, UI
- **Avhengigheter:** REQ-0567
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Ressursene vises under «Ressurser fra slettede prosjekter» med «Last ned …» og «Slett for godt …».
  - Sletting for godt fjerner alle bilder og lydfiler, versjoner, AI-logg og prosjektet; filer i lagringen under prosjektets mappe slettes.
  - Kan ikke gjøres før prosjektet er slettet.
- **Tester:**
  - db: 0011 purge
  - visuell: 59
- **Implementering:** db/migrations/0011_project_delete_film.sql, src/adapters/storage/project-admin.functions.ts, src/app/projects/ProjectDangerDialogs.tsx

#### REQ-0571 – Globale ressurser på tvers av prosjekter
Ressurser (alle typer) skal kunne gjøres globale, slik at de kan brukes i flere prosjekter. Ressurser fra slettede prosjekter skal kunne flyttes dit.

- **Kilde:** Beslutning DEC-0046 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** LIBRARY, SECURITY
- **Avhengigheter:** REQ-0570
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - En ressurs kan gjøres global og brukes i et annet prosjekt uten kopiering av filer.
  - Tilgang og sletting av globale ressurser er tydelig og trygg.
- **Tester:**
  - planlagt

#### REQ-0572 – Forhåndsvisning av monteringen i eget vindu
Forhåndsvisningen i monteringen (animatic) skal kunne åpnes i et eget nettleservindu, som i sceneeditoren.

- **Kilde:** Beslutning DEC-0050 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** TIMELINE, UI
- **Avhengigheter:** REQ-0556
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Monteringen har en knapp som åpner forhåndsvisningen i eget vindu; avspilling og avspillingshode følger hovedvinduet.
- **Tester:**
  - planlagt
- **Implementering:** src/app/assembly/FilmPopout.tsx, src/app/scene-editor/PreviewWindow.tsx

#### REQ-0573 – Svart-hvitt for hele filmen
Hele animaticen skal kunne vises og eksporteres i svart-hvitt med én global kontroll.

- **Kilde:** Beslutning DEC-0050 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 4
- **Moduler:** TIMELINE, EXPORT, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Global svart-hvitt slår om visningen i monteringen.
  - Eksporten kan lages i svart-hvitt.
- **Tester:**
  - planlagt
- **Implementering:** src/engine/compositor/film.ts, src/app/assembly/AssemblyWorkspace.tsx, src/app/assembly/ExportAnimaticDialog.tsx, src/engine/export/animatic.ts

#### REQ-0574 – Svart-hvitt per scene
En scene skal kunne settes til svart-hvitt. Valget gjelder både visning og eksport, uten egen varsling.

- **Kilde:** Beslutning DEC-0050 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 4
- **Moduler:** TIMELINE, COMPOSE, EXPORT
- **Avhengigheter:** REQ-0573
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En scene satt til svart-hvitt vises og eksporteres i svart-hvitt; andre scener påvirkes ikke.
- **Tester:**
  - planlagt
- **Implementering:** src/core/commands/apply.ts, src/app/assembly/ClipPanel.tsx, src/engine/compositor/film.ts

#### REQ-0575 – Flere overgangstyper
Overgangene skal minst omfatte kutt, overtoning, via svart, via hvitt, tørk (wipe), skyv (push) og iris, hver med lengde.

- **Kilde:** Beslutning DEC-0050 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** TIMELINE, EXPORT
- **Avhengigheter:** REQ-0223
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Hver type kan velges for en overgang og vises likt i avspilling og eksport.
- **Tester:**
  - planlagt
- **Implementering:** src/core/assembly/film.ts, src/engine/compositor/film.ts, src/app/assembly/TransitionEditor.tsx

#### REQ-0576 – Overgang med overlapp
En overgang skal kunne la scenene overlappe, slik at filmen blir kortere med overgangens lengde (som i klippeprogrammer).

- **Kilde:** Beslutning DEC-0050 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** TIMELINE
- **Avhengigheter:** REQ-0575
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Med overlapp blir filmens lengde kortere med overgangens lengde; uten overlapp er lengden uendret.
- **Tester:**
  - planlagt
- **Implementering:** src/core/assembly/film.ts

#### REQ-0577 – Standard overgang for prosjektet
Prosjektet skal ha en standard overgang (type og lengde) som gjelder der ingen egen overgang er valgt, og hver overgang skal kunne overstyres enkeltvis.

- **Kilde:** Beslutning DEC-0050 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** TIMELINE, UI
- **Avhengigheter:** REQ-0575
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Endring av prosjektets standard endrer alle overganger uten eget valg, ikke de som er overstyrt.
- **Tester:**
  - planlagt
- **Implementering:** src/core/commands/apply.ts, src/core/patch.ts, src/app/assembly/AssemblyWorkspace.tsx

#### REQ-0578 – Naboscener i sceneeditorens avspilling
I sceneeditoren skal forrige og neste scene kunne vises som ferdige filmsnutter før og etter scenen, med lyd og overganger, slik at avspillingshodet kan stå og spilles i dem. Lagene i naboscenene vises ikke og kan ikke endres.

- **Kilde:** Beslutning DEC-0050 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** COMPOSE, TIMELINE, AUDIO
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Med «vis forrige/neste scene» på kan avspillingshodet flyttes inn i naboscenen og spilles i kontinuitet med lyd og overgang.
  - Lagvelgeren viser bare lagene i scenen som redigeres.
- **Tester:**
  - planlagt
- **Implementering:** src/app/scene-editor/NeighbourScenes.tsx, src/core/assembly/film.ts#neighbourRange, clipFrameToComposition

#### REQ-0579 – Bildeskifte i et lag
Et lag i en 2D-scene skal kunne bytte til et annet bilde (hvilket som helst bilde) på et tidspunkt i scenen. Skiftet er et hardt kutt og vises som et punkt på lagets linje i tidslinjen som kan dras.

- **Kilde:** Beslutning DEC-0050 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** COMPOSE, LIBRARY, UI
- **Avhengigheter:** REQ-0174
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Et lag med to bilder viser tydelig de to delene i tidslinjen; skiftepunktet kan dras og angres.
- **Tester:**
  - planlagt
- **Implementering:** src/core/composition/render.ts#layerImageAt, layerVersion, layerSize, src/app/scene-editor/LayerSwaps.tsx, src/app/scene-editor/Timeline.tsx (merker som kan dras), db/migrations/0013_transitions_monochrome.sql (image_swaps)

#### REQ-0580 – Frilegge bilde (fjerne bakgrunn)
Et opplastet eller generert bilde skal kunne friklippes uten kostnad, med en pensel for å legge til og fjerne manuelt. Resultatet lagres som ny versjon; originalen beholdes.

- **Kilde:** Beslutning DEC-0050 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 5
- **Moduler:** LIBRARY, COMPOSE, UI
- **Avhengigheter:** REQ-0175
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Frilegging fra bildevinduet gir en ny versjon med gjennomsiktig bakgrunn uten betalt kall.
  - Penselen kan legge til og fjerne, og hvert strøk kan angres.
- **Tester:**
  - planlagt
- **Implementering:** src/core/cutout/index.ts, src/app/library/CutoutDialog.tsx

#### REQ-0581 – Tegne bevegelsesbane for et lag
Bevegelsen til et lag skal kunne tegnes på frihånd (med «Glatt ut») eller lages som rette linjer og Bézier-kurver, som kamerabanene.

- **Kilde:** Beslutning DEC-0050 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** COMPOSE, CAMERA, UI
- **Avhengigheter:** REQ-0188; REQ-0189
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En frihåndstegnet bane blir lagets bevegelse; «Glatt ut» gir en redigerbar kurve.
- **Tester:**
  - planlagt
- **Implementering:** src/core/composition/path.ts, src/core/composition/render.ts#pathSegments, pathPointAt, src/app/scene-editor/LayerMotion.tsx, src/app/scene-editor/Stage.tsx (tegning, punkter)

#### REQ-0582 – Tempo i bevegelser
Tempoet i en bevegelse skal kunne styres med ease inn/ut med justerbar styrke, og med en tempokurve der punkter kan dras (som midtpunktet i nivåer i Photoshop) slik at bevegelsen går ulikt før og etter punktet.

- **Kilde:** Beslutning DEC-0050 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** COMPOSE, CAMERA, UI
- **Avhengigheter:** REQ-0581
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Å dra et punkt i tempokurven endrer hvor raskt laget beveger seg før og etter punktet, uten å endre banen.
- **Tester:**
  - planlagt
- **Implementering:** src/core/composition/render.ts#easeStrength, tempoAt, pathProgress, src/core/composition/animate.ts#setKeyframeEase, src/app/scene-editor/LayerMotion.tsx (ease og tempokurve), src/app/scene-editor/Timeline.tsx (ease inn/ut på nøkkelbilder)

#### REQ-0583 – Lydopptak i sceneeditoren
Brukeren skal kunne ta opp lyd direkte (mikrofon) i sceneeditoren. Opptaket blir en lydressurs og et lydklipp i scenen som kan klippes ikke-destruktivt.

- **Kilde:** Beslutning DEC-0050 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 4
- **Moduler:** AUDIO, COMPOSE, UI
- **Avhengigheter:** REQ-0207
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Opptak startes og stoppes i sceneeditoren og legges ved avspillingshodet.
  - Opptaket kan kuttes og utvides igjen uten at filen endres.
- **Tester:**
  - planlagt
- **Implementering:** src/app/scene-editor/RecordAudioDialog.tsx

#### REQ-0584 – «Bruk aktivt utsnitt» i kamerautsnitt
Start- og sluttrammen i et kamerautsnitt skal kunne hente utsnittet kameraet har når scenen rett før slutter (knappen «Bruk aktivt utsnitt»), så overgangen mellom scenene henger sammen.

- **Kilde:** Beslutning DEC-0062 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 3
- **Moduler:** COMPOSE, UI
- **Avhengigheter:** REQ-0174
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Knappen finnes ved både startrammen (blå) og sluttrammen (rød).
  - Den kopierer sluttrammen i det siste kamerautsnittet i forrige aktive scene (hele formatet hvis den ikke har noe), omregnet til scenens format.
  - Knappen er deaktivert i første scene og når scenen før ikke har en 2D-scene. Endringen kan angres.
- **Tester:**
  - tests/unit/camera-handoff.test.ts
- **Implementering:** src/core/composition/camera-handoff.ts, src/app/scene-editor/CameraPanel.tsx

#### REQ-0585 – Lag i grupper med dra og slipp, fjerning av lag og justerbar lagliste
I laglisten skal et lag kunne fjernes fra scenen (ressursen blir i biblioteket), dras inn på en gruppe for å bli med i den og dras ut igjen. Når en gruppe velges, lyser lagene i den opp i listen og i scenen. Skillelinjen under laglisten kan dras, så brukeren bestemmer hvor mange lag som vises.

- **Kilde:** Beslutning DEC-0062 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 3
- **Moduler:** COMPOSE, UI
- **Avhengigheter:** REQ-0174
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Hver rad har «Fjern fra scenen»; en gruppe fjernes uten at lagene i den hopper. Kan angres.
  - Slipp på midten av en grupperad legger laget i gruppen uten at det flytter seg i bildet; slipp ved siden av et lag utenfor gruppen tar det ut. Knappen «Ta ut av gruppen» gjør det samme uten mus.
  - Valgt gruppe: lagene i den markeres i listen og får omriss i scenen.
  - Høyden på laglisten huskes.
- **Tester:**
  - tests/visual/screens.mjs (67)
- **Implementering:** src/app/scene-editor/LayersPanel.tsx, src/app/scene-editor/Stage.tsx (drawMemberOutline), src/app/shell/pane-size.tsx (edge bottom)

#### REQ-0586 – Endre rolle etter invitasjon
Prosjektets eier skal kunne endre rollen til et medlem etter at det er invitert inn (eier, redaktør, kommentator, leser), og endre rollen i eller trekke tilbake en invitasjon som ikke er tatt imot. Prosjektet skal alltid ha minst én eier.

- **Kilde:** Beslutning DEC-0063 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 1
- **Moduler:** COLLAB, UI
- **Avhengigheter:** REQ-0520; REQ-0521
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Eieren velger ny rolle for et medlem i listen på prosjektoversikten; endringen gjelder straks i databasen.
  - Andre enn eieren kan ikke endre roller; den eneste eieren kan ikke miste eierrollen.
  - Ventende invitasjoner vises for eieren med rolle som kan endres, og kan trekkes tilbake.
- **Tester:**
  - tests/db/run-db-tests.ts (0020 DEC-0063)
- **Implementering:** db/migrations/0020_member_roles.sql, src/app/projects/MembersSection.tsx

#### REQ-0587 – Tilbake til forrige vindu
En global «Tilbake»-funksjon skal ta brukeren tilbake til arbeidsflaten (vinduet) hun kom fra, med samme valg som da hun forlot den.

- **Kilde:** Beslutning DEC-0063 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** 1
- **Moduler:** UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Knappen «Tilbake til …» i toppstripen viser navnet på forrige flate og går dit med samme valg (scene, ressurs, replikk).
  - Valg inne i samme flate gir ikke nye steg; flere trykk går videre bakover.
- **Tester:**
  - tests/unit/back-stack.test.ts
- **Implementering:** src/app/shell/back-stack.ts, src/app/shell/back-navigation.tsx, src/app/shell/AppHeader.tsx

#### REQ-0588 – Bilder i fullskjerm, nedlasting med prosjektnavn og opplasting igjen
Dobbeltklikk på et bilde i biblioteket skal vise det i fullskjerm med zoom og panorering og mulighet til å laste det ned. Nedlastede bilder skal hete som i prosjektet (ressurs, variant og løpenummer). Lastes en fil med samme navn opp igjen, skal programmet spørre om den skal erstatte bildet (og brukes i alle scener der det er brukt) eller legges til som et nytt bilde med eget navn.

- **Kilde:** Beslutning DEC-0064 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 3
- **Moduler:** LIBRARY, UI
- **Avhengigheter:** REQ-0135
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Dobbeltklikk åpner fullskjerm med zoom (rullehjul og knapper), panorering, bla mellom versjoner og nedlasting.
  - Nedlastet fil heter «Ressurs - Variant - vN.<filtype>»; zip-nedlastingen bruker samme navn.
  - Opplasting med samme navn gir valget Erstatt / Legg til / Hopp over; Erstatt flytter godkjenning, lag og plakater til den nye versjonen, og den gamle tas vare på.
  - Legg til gir ny versjon med eget løpenummer og merknad om opphavet.
- **Tester:**
  - tests/unit/reupload.test.ts
- **Implementering:** src/core/library/file-names.ts, src/core/library/reupload.ts, src/app/library/ImageViewer.tsx, src/app/library/ReuploadDialog.tsx

#### REQ-0589 – Filmens visuelle stil og bildebeskrivelser med sammenheng
Prosjektet skal ha en beskrivelse av filmens visuelle stil (handling, verden, stil, teknikk, farger, lys, stemning, regler for figurer og omgivelser, hva som skal unngås, egne AI-instrukser og forbildebilder). Beskrivelsen som sendes til en bildemodell, skal settes sammen av denne stilen, ressursen og bruken, scenene den er med i (sted, tid på døgnet, årstid, lys, hvem som er der, handlingen, utseendet i scenen) og godkjente bilder i filmen.

- **Kilde:** Beslutning DEC-0065 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 5
- **Moduler:** PROMPT, LIBRARY, UI
- **Avhengigheter:** REQ-0245; REQ-0147
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Filmens visuelle stil kan fylles ut, foreslås fra prosjektet og forhåndsvises som beskrivelse.
  - Bildebeskrivelsen har seksjonene FILM, VISUAL STYLE, THIS IMAGE, WHERE IT APPEARS, CONSISTENCY og AVOID (og PROJECT INSTRUCTIONS når det finnes).
  - Fra sceneeditoren brukes scenen laget hører til (sted, inne/ute, tid på døgnet med lys).
  - Beskrivelsen vises og kan endres før noe sendes.
  - «Skriv beskrivelsen med AI» lar en språkmodell skrive beskrivelsen ut fra alt over og bildene som sendes med; resultatet vises og kan endres før et bilde genereres, kallet logges og teller ikke i bildebudsjettet (DEC-0066).
  - Dagens bilde (beholdes) og filmens godkjente bilder (bare stil: forbildene i stilen og godkjente figurer/steder i de samme scenene) sendes med til bildemodellen, og beskrivelsen sier hva hvert bilde er (DEC-0066).
- **Tester:**
  - tests/unit/style-prompt.test.ts
  - tests/unit/prompt-writer.test.ts
- **Implementering:** src/core/generation/style.ts, src/core/generation/image-prompt.ts, src/app/projects/StyleGuideSection.tsx, src/app/library/GenerateImagePanel.tsx, db/migrations/0021_style_profiles.sql, src/core/generation/prompt-writer.ts, src/adapters/ai/write-prompt.functions.ts, src/adapters/ai/generate-image.functions.ts, src/adapters/ai/gateway.ts, db/migrations/0022_ai_prompt_writer.sql

#### REQ-0590 – Egne AI-leverandører med veiledning, sikre nøkler og overordnet kostnadstak
Løsningen skal vise en liste over de mest brukte AI-leverandørene. Brukeren kan koble til én, flere eller alle; de som er koblet til, blir tilgjengelige for å generere enkeltbilder, videoer og lyder. Ved klikk på en leverandør skal en dialog gi lenker til å opprette konto og abonnement, til stedet der API-nøkkelen hentes, og et felt for å legge inn nøkkelen. Nøkkelen skal sikres etter beste praksis, og det skal være mulig å sette et tak på AI-kostnaden på overordnet nivå.

- **Kilde:** Beslutning DEC-0069 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** PROVIDER, SECURITY, QUALITYCOST, UI
- **Avhengigheter:** REQ-0270; REQ-0271; REQ-0282
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Dialogen «AI-leverandører» viser OpenAI, Google Gemini, fal.ai, Runway og ElevenLabs (og innebygd Lovable AI) med hva de kan lage og status.
  - Hver leverandør har steg på norsk og lenker til konto, betaling, API-nøkkel og priser; nøkkelen prøves hos tjenesten før den lagres.
  - Nøkkelen lagres kryptert (AES-256-GCM, bundet til bruker, leverandør og rad), kan aldri leses tilbake fra nettleseren, og bare de fire siste tegnene vises; fjerning sletter den.
  - Brukeren kan sette et tak i USD per måned for alt som genereres med nøklene; taket kontrolleres før og etter hver jobb og kan ikke nullstilles ved å slette et prosjekt.
  - Bilder (biblioteket og sceneeditoren), video («Generer scene») og lyd (lydressurser) kan lages med tilkoblede leverandører; kostnaden vises og bekreftes først.
- **Tester:**
  - tests/unit/ai-providers.test.ts
  - tests/unit/ai-gate.test.ts
  - tests/unit/ai-video.test.ts
  - tests/unit/ai-sound.test.ts
- **Implementering:** src/core/generation/providers.ts, src/core/generation/video.ts, src/core/generation/sound.ts, src/app/ai/ProvidersDialog.tsx, src/app/assembly/SceneVideoSection.tsx, src/app/library/GenerateSoundPanel.tsx, src/adapters/ai/key-vault.server.ts, src/adapters/ai/providers.server.ts, src/adapters/ai/provider-keys.functions.ts, src/adapters/ai/ai-gate.server.ts, src/adapters/ai/video.functions.ts, src/adapters/ai/sound.functions.ts, db/migrations/0024_ai_providers.sql

#### REQ-0591 – Arbeidsliste for oppdaterte ressurser
Når en ressurs er oppdatert, skal brukeren kunne få opp en arbeidsliste over scenene som er berørt, og scene for scene velge om den nye versjonen skal brukes i stedet for den gamle.

- **Kilde:** Beslutning DEC-0072 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 6
- **Moduler:** LIBRARY, COMPOSE, UI
- **Avhengigheter:** REQ-0130; REQ-0132; REQ-0134; REQ-0257
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Listen viser 2D-lag, stillbilder og AI-video som fortsatt viser eller er laget med en eldre versjon enn den godkjente.
  - For hver scene kan brukeren velge «Bruk ny versjon her» (2D-lag og stillbilder) eller «Behold»; ingenting endres uten valget, og valget kan angres.
  - AI-video lages aldri på nytt automatisk; «Lag ny video …» åpner bare scenen.
  - Listen åpnes fra ressursen i biblioteket og fra prosjektoversikten.
- **Tester:**
  - tests/unit/worklist.test.ts
- **Implementering:** src/core/library/worklist.ts, src/app/library/AssetWorklistDialog.tsx, src/app/library/AssetDetail.tsx, src/app/projects/WorklistNotice.tsx, db/migrations/0027_review_export.sql

#### REQ-0592 – AI-generering startes alltid av brukeren
Video (og annen AI-generering) skal aldri genereres automatisk. Den startes alltid av brukeren, for én scene, flere scener, hele filmen eller deler av en scene, med kostnad vist og bekreftet først.

- **Kilde:** Beslutning DEC-0072 · **Opprinnelse:** brukerbeslutning · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 5
- **Moduler:** QUEUE, QUALITYCOST
- **Avhengigheter:** REQ-0270; REQ-0291
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Ingen kode starter en generering uten en brukerhandling med bekreftet kostnad; køen sender bare jobber brukeren selv har lagt i kø.
  - Den planlagte bakgrunnsjobben er ikke satt opp (Mars, 12.10.2026).
- **Tester:**
  - tests/unit/ai-queue.test.ts
  - tests/architecture/eksport-uten-ai.test.ts
- **Implementering:** src/adapters/ai/video.functions.ts, src/adapters/ai/video-followup.server.ts, src/core/library/worklist.ts, src/app/ai/video-jobs.ts, src/adapters/ai/queue.functions.ts

#### REQ-0593 – 12 bilder i sekundet og animer på toere
Prosjektet kan ha 12 bilder i sekundet (vanlig i ferdig stop motion). Hver 2D-scene kan animeres på enere, toere, treere eller firere: bevegelse, kamera og bildeskifter oppdateres bare hvert n-te bilde, mens filmen beholder bildefrekvensen.

- **Kilde:** Beslutning DEC-0079 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** COMPOSE, EXPORT
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Bildefrekvensen 12 kan velges på prosjektoversikten.
  - «Animer» på toere gir samme bilde på bilde 2 og 3 i avspilling og eksport; kan angres.
  - Valget lagres i compositions.step (migrasjon 0029).
- **Tester:**
  - tests/unit/funn-2026-10-13.test.ts
  - tests/db/run-db-tests.ts
- **Implementering:** src/core/composition/format.ts, src/core/composition/render.ts, src/app/scene-editor/LayerInspector.tsx, db/migrations/0029_trash_speed_step.sql

#### REQ-0594 – Lydklipp: dra, hastighet og masker for start og slutt
Lydklipp kan dras for å flyttes og kuttes i kantene også i sceneeditorens tidslinje. I lydprofilen kan hastigheten settes fra 25 til 400 % (trinnløst og med faste steg), og masker for start og slutt i lydfilen kan dras eller flyttes med piltaster; ny varighet vises. Tonehøyden følger hastigheten.

- **Kilde:** Beslutning DEC-0079 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** AUDIO, TIMELINE
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Dobbel hastighet halverer lengden og spiller lydfilen dobbelt så fort i avspilling og eksport.
  - Masker gir ny start i lydfilen og ny varighet; volumpunktene følger lyden.
  - Drag i sceneeditoren lagres som én endring som kan angres.
- **Tester:**
  - tests/unit/funn-2026-10-13.test.ts
  - tests/db/run-db-tests.ts
- **Implementering:** src/app/audio/AudioClipEditor.tsx, src/app/scene-editor/SceneAudioRows.tsx, src/engine/audio/mixer.ts, src/core/audio/index.ts, db/migrations/0029_trash_speed_step.sql

#### REQ-0595 – Tydelig hva som er lagt inn i scenen
«I denne scenen» merker ressursene som allerede er lagt inn som lag (merket «I scenen», antall lag). Dobbeltklikk på en ressurs i lista åpner det samme bildevalget som dobbeltklikk på laget i scenen (er den ikke lagt inn, legges den inn først).

- **Kilde:** Beslutning DEC-0079 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** COMPOSE, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Ressurser med lag i 2D-scenen har synlig merke og ramme.
  - Dobbeltklikk i lista åpner bildevalget for laget.
- **Tester:**
  - docs/development/VISUAL_QA_DEC-0079.md
- **Implementering:** src/app/scene-editor/SceneAssetsPanel.tsx, src/app/scene-editor/SceneEditorWorkspace.tsx

#### REQ-0596 – Enkle symboler for alle ressurser
Hver ressurs får et enkelt symbol: fylt form uten omriss, ansikt eller øyne, formen etter type og egen farge per ressurs. Symbolet vises i lister og tegnes i scenen og animaticen for lag som ennå ikke har bilde.

- **Kilde:** Beslutning DEC-0079 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** LIBRARY, COMPOSE, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - To karakterer har ulike farger; formen viser typen.
  - Et lag uten bilde tegnes med ressursens symbol.
- **Tester:**
  - tests/unit/funn-2026-10-13.test.ts
  - docs/development/VISUAL_QA_DEC-0079.md
- **Implementering:** src/core/library/symbol.ts, src/app/library/AssetSymbolIcon.tsx, src/engine/compositor/canvas.ts

#### REQ-0597 – Filmformater og TIFF ved opplasting
Film kan importeres som MP4 (også .m4v), MOV og WebM, også når nettleseren ikke oppgir filtypen; om nettleseren ikke kan spille av kodeken (f.eks. ProRes eller HEVC), forklares det før opplasting. TIFF kan lastes opp som bilde og gjøres om til PNG. Velges en film der det skal være et bilde, forklares hvor film legges inn.

- **Kilde:** Beslutning DEC-0079 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** LIBRARY, TIMELINE
- **Status:** Verifisert
- **Akseptansekriterier:**
  - MP4/M4V/MOV/WebM gjenkjennes fra endelsen.
  - Uavspillbar kodek gir en forståelig melding.
  - TIFF blir PNG i full størrelse.
- **Tester:**
  - tests/unit/funn-2026-10-13.test.ts
- **Implementering:** src/app/assembly/film-import.ts, src/app/library/image-prep.ts, src/app/library/asset-images.ts

#### REQ-0598 – Store bilder skaleres ned – originalen beholdes
Bilder større enn to ganger filmformatets lengste side (minst 2048 px) får en nedskalert arbeidskopi som brukes i scenen; originalen lagres som versjonen før og kan tas i bruk ved å godkjenne den (kan angres). Til AI sendes som standard arbeidsstørrelsen; «Send forbildene i full størrelse» sender originalene (f.eks. karakterkort).

- **Kilde:** Beslutning DEC-0079 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** LIBRARY, PROVIDER
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Et bilde på 6000 × 4000 gir en arbeidskopi på 3840 × 2560 i et HD-prosjekt, og originalen som egen versjon.
  - Valget for full størrelse sender originalens sti.
- **Tester:**
  - tests/unit/funn-2026-10-13.test.ts
- **Implementering:** src/app/library/image-prep.ts, src/app/library/asset-images.ts, src/core/library/index.ts, src/app/library/GenerateImagePanel.tsx

#### REQ-0599 – Zoomknapper i scenen
Scenen har knapper for zoom inn og ut og et valg med faste zoomnivåer (10–1600 %), i tillegg til «Tilpass» og «100 %».

- **Kilde:** Beslutning DEC-0079 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** COMPOSE, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Zoom inn/ut går til neste faste nivå rundt midten av visningen.
- **Tester:**
  - docs/development/VISUAL_QA_DEC-0079.md
- **Implementering:** src/app/scene-editor/Stage.tsx

#### REQ-0600 – Bildedialogen husker siste beskrivelse og har bildestørrelse
Når et nytt bilde skal genereres, er feltet fylt med siste beskrivelse brukt for ressursen («Tilbakestill» gir den automatiske). Bildestørrelse er et eget valg der modellen tar imot det (f.eks. 1K/2K/4K for Nano Banana Pro, med pris), og sendes som tjenestens egen parameter.

- **Kilde:** Beslutning DEC-0079 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** PROMPT, PROVIDER, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Siste beskrivelse settes inn og merkes.
  - Størrelsen påvirker prisanslaget og sendes som image_size til Google.
- **Tester:**
  - tests/unit/funn-2026-10-13.test.ts
  - docs/development/VISUAL_QA_DEC-0079.md
- **Implementering:** src/core/generation/prompt-history.ts, src/core/generation/providers.ts, src/app/library/GenerateImagePanel.tsx, src/adapters/ai/providers.server.ts

#### REQ-0601 – Stor visning og beskrivelsen per bilde
Klikk på et bilde i bildevalget åpner en stor visning med zoom og panorering. Beskrivelsen (prompten) som laget bildet vises ved siden av – den følger bildet og slettes aldri – med «Sett inn denne beskrivelsen» og «Kopier».

- **Kilde:** Beslutning DEC-0079 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** PROMPT, LIBRARY, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Beskrivelsen hentes fra AI-jobbloggen (også eldre enn de siste 300).
  - «Sett inn» fyller genereringsfeltet.
- **Tester:**
  - tests/unit/funn-2026-10-13.test.ts
  - docs/development/VISUAL_QA_DEC-0079.md
- **Implementering:** src/app/library/ImageLightbox.tsx, src/adapters/browser/ai.ts, src/app/scene-editor/LayerImageDialog.tsx

#### REQ-0602 – Varsel om utdatert AI-tekst hindrer ikke generering
Er bildene som sendes med endret etter at AI skrev beskrivelsen, varsles det – men brukeren kan likevel generere.

- **Kilde:** Beslutning DEC-0079 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** PROMPT, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - «Generer» er tilgjengelig med varselet synlig.
- **Tester:**
  - docs/development/VISUAL_QA_DEC-0079.md
- **Implementering:** src/app/library/GenerateImagePanel.tsx

#### REQ-0603 – Bildebeskrivelser bygger på manuset
Den automatiske bildebeskrivelsen tar med setningene der manuset omtaler ressursen (handling og andres replikker), i fortellingsrekkefølge, avgrenset i lengde.

- **Kilde:** Beslutning DEC-0079 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** PROMPT
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Det visuelle faktaarket (REQ-0626) brukes når det finnes; ellers tas beskrivelsen og høyst tre handlingssetninger som nevner ressursen med, merket som norsk – aldri replikker.
- **Tester:**
  - tests/unit/funn-2026-10-13.test.ts
  - tests/unit/funn-2026-10-14.test.ts
- **Implementering:** src/core/generation/image-prompt.ts, src/core/generation/brief.ts

#### REQ-0604 – Lokasjon legges nederst
En lokasjon eller et miljø som legges inn i scenen, legges nederst av alle lagene og dekker bildet.

- **Kilde:** Beslutning DEC-0079 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** COMPOSE
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Nytt lag av typen bakgrunn fra en ressurs får laveste plass i lagrekkefølgen.
- **Tester:**
  - tests/unit/composition.test.ts
- **Implementering:** src/core/commands/apply.ts

#### REQ-0605 – Bekreftelsen er alltid synlig
Bekreftelsen («Ja, generer») i bildedialogen står alltid synlig nederst i dialogen og rulles fram når den åpnes.

- **Kilde:** Beslutning DEC-0079 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - «Ja, generer» er synlig uten å rulle.
- **Tester:**
  - docs/development/VISUAL_QA_DEC-0079.md
- **Implementering:** src/app/library/GenerateImagePanel.tsx

#### REQ-0606 – Speilvending og enkel tegning
Et lag kan speilvendes vannrett eller loddrett i scenen (bildet i biblioteket endres ikke). I frileggingen kan bildet speilvendes og det kan tegnes med farge; alt kan angres, og resultatet lagres som ny versjon.

- **Kilde:** Beslutning DEC-0079 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** COMPOSE, LIBRARY
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Speilvending snur skaleringen også i nøkkelbildene.
  - Tegning og speilvending kan angres i frileggingen.
- **Tester:**
  - tests/unit/funn-2026-10-13.test.ts
  - docs/development/VISUAL_QA_DEC-0079.md
- **Implementering:** src/core/composition/index.ts, src/core/cutout/index.ts, src/app/library/CutoutDialog.tsx, src/app/scene-editor/LayerInspector.tsx

#### REQ-0607 – Slettede objekter
Ressurser og enkeltbilder kan slettes fra biblioteket og bildevalget, med en advarsel om hva som skjer. De flyttes til «Slettede objekter», der de kan hentes inn igjen; prosjektets eier kan slette for godt (også filene) når ingenting i filmen bruker dem. Det godkjente bildet kan ikke slettes.

- **Kilde:** Beslutning DEC-0079 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** LIBRARY, SECURITY
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Slettet ressurs vises ikke i lister og lagvalg, men i «Slettede objekter».
  - Sletting for godt avvises så lenge noe bruker ressursen.
  - Bare eieren kan slette for godt; bare via serveren.
- **Tester:**
  - tests/unit/funn-2026-10-13.test.ts
  - tests/db/run-db-tests.ts
- **Implementering:** src/core/commands/apply.ts, src/core/library/index.ts, src/app/library/TrashDialog.tsx, src/adapters/storage/trash.functions.ts, db/migrations/0029_trash_speed_step.sql

#### REQ-0608 – Dialog med AI-stemmer: status, stemmer og avspilling
Dialogen viser tydelig hvilke replikker som har lyd (AI eller opptak) og hvilke som mangler, hvilken stemme hver karakter har og hvem andre som bruker samme stemme (den kan likevel velges). Lyden replikken har kan spilles av i dialogen, og stemmene kan prøvelyttes.

- **Kilde:** Beslutning DEC-0079 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** AUDIO, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Hver replikk har merke «Har lyd» eller «Mangler lyd».
  - Stemmevalget viser «brukes av …».
  - Avspilling og prøve fungerer i dialogen.
- **Tester:**
  - tests/unit/funn-2026-10-13.test.ts
  - docs/development/VISUAL_QA_DEC-0079.md
- **Implementering:** src/app/assembly/AiDialogueDialog.tsx, src/core/generation/speech.ts, src/adapters/ai/providers.server.ts

#### REQ-0609 – Norsk tale blir norsk
Replikker leses inn med en modell som kan norsk (Eleven v3), og språket settes eksplisitt, så norsk ikke leses som dansk.

- **Kilde:** Beslutning DEC-0079 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** AUDIO, PROVIDER
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Kallet til ElevenLabs har model_id eleven_v3 og language_code no.
- **Tester:**
  - tests/unit/ai-speech.test.ts
- **Implementering:** src/core/generation/speech.ts, src/adapters/ai/speech.functions.ts, src/adapters/ai/providers.server.ts

#### REQ-0610 – Bredere lagnavn i tidslinjen
Skillet mellom lagnavnene og tidslinjen i sceneeditoren kan dras, så lange lagnavn kan leses. Bredden huskes i nettleseren; dobbeltklikk gir standard.

- **Kilde:** Beslutning DEC-0080 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** TIMELINE, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Dra i skillet gjør navnekolonnen bredere eller smalere (100–480 px).
  - Sporene og avspillingshodet følger den nye bredden.
- **Tester:**
  - docs/development/VISUAL_QA_DEC-0080.md
- **Implementering:** src/app/scene-editor/Timeline.tsx

#### REQ-0611 – Filmens visuelle stil rett fra bildevalget
Hintet om at filmens visuelle stil ikke er fylt ut, er en lenke som åpner stilen oppå bildevalget. Når den lukkes, er brukeren tilbake i bildevalget der hun var, og beskrivelsen følger den nye stilen.

- **Kilde:** Beslutning DEC-0080 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** PROMPT, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Lenken åpner «Filmens visuelle stil» over bildevalget.
  - Lukk eller lagre gir bildevalget tilbake uendret.
- **Tester:**
  - docs/development/VISUAL_QA_DEC-0080.md
- **Implementering:** src/app/library/GenerateImagePanel.tsx, src/app/scene-editor/LayerImageDialog.tsx, src/app/projects/StyleGuideSection.tsx

#### REQ-0612 – Stor visning: «Tilpass» er standard og stemmer
Stor visning åpner med hele bildet tilpasset vinduet («Tilpass»), også små bilder forstørres. Målene kommer fra bildet når versjonen mangler dem.

- **Kilde:** Beslutning DEC-0080 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** LIBRARY, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Et 1200 × 1600-bilde åpner i ca. 44 % i et vanlig vindu, ikke 100 %.
- **Tester:**
  - docs/development/VISUAL_QA_DEC-0080.md
- **Implementering:** src/app/library/ImageLightbox.tsx

#### REQ-0613 – Dobbeltklikk på bildene i bildevalget
Dobbeltklikk på et bilde i bildevalget åpner det i stor visning.

- **Kilde:** Beslutning DEC-0080 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Dobbeltklikk åpner stor visning for akkurat det bildet.
- **Tester:**
  - docs/development/VISUAL_QA_DEC-0080.md
- **Implementering:** src/app/scene-editor/LayerImageDialog.tsx

#### REQ-0614 – Fjern luften rundt
Etter frilegging kan luften rundt figuren fjernes: bildet beskjæres tett rundt det synlige med litt luft (1 % av lengste side, minst 2 px), som ny versjon. Valget er på som standard i frileggingen og finnes som egen knapp i stor visning. Forhåndsvisningene legger på litt luft, så tett beskårne figurer ikke slår i kanten.

- **Kilde:** Beslutning DEC-0080 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** LIBRARY, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Et frilagt bilde med stor tom kant blir en ny versjon med bare figuren og litt luft.
  - Uten gjennomsiktig kant sies det at det ikke er noe å fjerne.
- **Tester:**
  - tests/unit/funn-2026-10-14.test.ts
  - docs/development/VISUAL_QA_DEC-0080.md
- **Implementering:** src/core/cutout/index.ts, src/app/library/CutoutDialog.tsx, src/app/library/image-actions.ts, src/app/library/ImageLightbox.tsx

#### REQ-0615 – Utsnitt med fri markering og del opp i ruter
I stor visning kan brukeren tegne en fri ramme rundt en del av bildet, gi utsnittet navn og lagre det som nytt bilde i et eksisterende eller nytt objekt (alt utenfor blir gjennomsiktig). «Del opp i ruter» deler et karakterark i like store ruter (kolonner × rader) og lagrer hver rute som nytt bilde, i dette objektet eller som nye objekter; tomme ruter hoppes over.

- **Kilde:** Beslutning DEC-0080 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** LIBRARY, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Utsnittet blir et nytt bilde med gjennomsiktighet utenfor markeringen.
  - 4 × 1 ruter gir fire nye bilder; alt kan angres som én handling.
- **Tester:**
  - tests/unit/funn-2026-10-14.test.ts
  - docs/development/VISUAL_QA_DEC-0080.md
- **Implementering:** src/app/library/ImageLightbox.tsx, src/app/library/image-actions.ts, src/core/cutout/index.ts

#### REQ-0616 – Advarsel når et bilde forstørres over 1:1
Laginspektøren varsler når et bilde tegnes større enn sine egne piksler (over 115 %), regnet fra skalering, gruppe og kamerazoom på bildet som vises og på nøkkelbildene, med knappen «Oppskaler bildet …».

- **Kilde:** Beslutning DEC-0080 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** COMPOSE, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Skalering 300 % gir en advarsel med prosenten.
  - Knappen åpner stor visning med oppskalering fremme.
- **Tester:**
  - tests/unit/funn-2026-10-14.test.ts
  - docs/development/VISUAL_QA_DEC-0080.md
- **Implementering:** src/core/composition/shape.ts, src/app/scene-editor/LayerInspector.tsx, src/app/scene-editor/SceneEditorWorkspace.tsx

#### REQ-0617 – Nullstill format
Ved hver skaleringsverdi i laginspektøren er det en knapp som gir laget bildets egne proporsjoner igjen: ved bredden beholdes bredden, ved høyden beholdes høyden. Speilvendingen beholdes; knappene er bare aktive når laget er skvist.

- **Kilde:** Beslutning DEC-0080 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** COMPOSE, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Skalering 140 % × 90 % blir 140 % × 140 % (behold bredden) eller 90 % × 90 % (behold høyden).
- **Tester:**
  - tests/unit/funn-2026-10-14.test.ts
  - docs/development/VISUAL_QA_DEC-0080.md
- **Implementering:** src/core/composition/shape.ts, src/app/scene-editor/LayerInspector.tsx

#### REQ-0618 – Skvis og strekk med sidehåndtak
Valgt lag har håndtak midt på hver side i tillegg til hjørnene. Et sidehåndtak skviser eller strekker i én retning mens motsatt side står stille; med Alt endres begge sider likt rundt midten. Det virker også når laget er rotert eller speilvendt.

- **Kilde:** Beslutning DEC-0080 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** COMPOSE, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Dra høyre side 50 px ut på et 200 px bredt lag gir 125 % bredde og midten flyttet 25 px.
- **Tester:**
  - tests/unit/funn-2026-10-14.test.ts
  - docs/development/VISUAL_QA_DEC-0080.md
- **Implementering:** src/core/composition/shape.ts, src/app/scene-editor/Stage.tsx

#### REQ-0619 – Frilegging fra stor visning, med zoom
«Frilegg …» finnes i stor visning. Frileggingen kan zoomes (rullehjul, knapper, «Tilpass», 100 %) og flyttes (mellomrom eller midtre museknapp); penselen følger zoomen.

- **Kilde:** Beslutning DEC-0080 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** LIBRARY, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Zoom inn viser bildet forstørret med skarpe piksler; penselen treffer der markøren er.
- **Tester:**
  - docs/development/VISUAL_QA_DEC-0080.md
- **Implementering:** src/app/library/CutoutDialog.tsx, src/app/library/ImageLightbox.tsx

#### REQ-0620 – Speilvending som tweenes mellom nøkkelbilder
«Speilvend» kan virke på hele laget (som før) eller «fra her»: laget snur fra forrige nøkkelbilde (ellers et halvt sekund før) til avspillingshodet, glidende (bildet klemmes smalt og vokser ut speilvendt) eller brått (på ett bilde), og er speilvendt resten av scenen.

- **Kilde:** Beslutning DEC-0080 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** COMPOSE, TIMELINE
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Glidende: skaleringen går fra 1 til -1 gjennom 0.
  - Brått: skaleringen er 1 til bildet før og -1 fra avspillingshodet.
  - Senere nøkkelbilder for samme skalering snus også.
- **Tester:**
  - tests/unit/funn-2026-10-14.test.ts
  - docs/development/VISUAL_QA_DEC-0080.md
- **Implementering:** src/core/composition/shape.ts, src/app/scene-editor/LayerInspector.tsx

#### REQ-0621 – Lesevisning av valgt scene
Med «Vis kun valgt scene» vises scenen rett på siden uten ark: toppjustert, uten sideskift, (MORE), (CONT'D) og sidetall, med manusets innrykk og linjebredde, og den kan rulles. Markering, notater og søk virker som før. «Sort tekst på hvit bakgrunn» gir lys leseflate; valget huskes.

- **Kilde:** Beslutning DEC-0080 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** SCRIPT, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Scenen vises som én sammenhengende tekst fra toppen.
  - Avkrysningen gir sort tekst på hvit bakgrunn.
- **Tester:**
  - tests/unit/funn-2026-10-14.test.ts
  - docs/development/VISUAL_QA_DEC-0080.md
- **Implementering:** src/core/screenplay/flow.ts, src/app/script/ScriptPageView.tsx, src/app/script/ScriptWorkspace.tsx

#### REQ-0622 – Vinkelen et bilde viser
Et bilde kan merkes med vinkelen det viser (forfra, tre kvart forfra, fra siden, tre kvart bakfra, bakfra, portrett, karakterark). Merket kan angres og endrer ikke selve bildet; det lagres i asset_versions.view (migrasjon 0030).

- **Kilde:** Beslutning DEC-0080 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** LIBRARY, VERSION
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Vinkelen lagres og leses tilbake likt; selve bildet kan fortsatt ikke endres (INV-13).
  - Ugyldig vinkel avvises av kjernen og databasen.
- **Tester:**
  - tests/unit/funn-2026-10-14.test.ts
  - tests/db/run-db-tests.ts
- **Implementering:** src/core/library/view.ts, src/core/commands/apply.ts, src/core/patch.ts, db/migrations/0030_views_visual_brief.sql

#### REQ-0623 – Lag andre vinkler med AI
I stor visning kan brukeren velge modell og hvilke vinkler som skal lages av samme karakter eller objekt, som ett karakterark (mest sammenheng, deles opp etterpå) eller ett bilde per vinkel (hver ny vinkel sendes med til neste). Bildet brukeren står i er identiteten; merkede vinkler og to stilforbilder sendes med. Anslaget vises, og ingenting starter før «Ja, generer». Resultatene lagres som nye versjoner merket med vinkel.

- **Kilde:** Beslutning DEC-0080 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** PROMPT, PROVIDER, LIBRARY
- **Status:** Implementert – ikke verifisert
- **Akseptansekriterier:**
  - Arket ber om vinklene i rekkefølge, samme høyde og grunnlinje, nøytral positur.
  - Hver vinkel får identitetsbildet først og tidligere vinkler som referanse.
- **Tester:**
  - tests/unit/funn-2026-10-14.test.ts
  - docs/development/VISUAL_QA_DEC-0080.md
- **Implementering:** src/app/library/ImageAiPanels.tsx, src/core/generation/brief.ts, src/core/generation/image-prompt.ts, src/adapters/ai/generate-image.functions.ts

#### REQ-0624 – Promptmotor per modellfamilie
Bildebeskrivelsen bygges som én strukturert bestilling og skrives i formen modellen forstår best: fortellende avsnitt for Nano Banana og GPT Image (referanser med roller, positive formuleringer), kort og presis med identiteten først og egen negativ beskrivelse for Seedream, Qwen og FLUX. Ingen filmtittel, ingen replikker, nøytralt lys for figurdesign, farger med navn og kode, flat hvit bakgrunn (frilegges etterpå) når modellen ikke kan lage gjennomsiktighet. En norsk oppsummering vises over den engelske beskrivelsen.

- **Kilde:** Beslutning DEC-0080 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** PROMPT, PROVIDER
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Beskrivelsen har ingen skjemaoverskrifter og ingen filmtittel.
  - Fargen #0d1b2a beskrives som «deep navy (#0d1b2a)».
  - Kort form starter med identiteten og har negativ beskrivelse.
- **Tester:**
  - tests/unit/funn-2026-10-14.test.ts
  - docs/development/VISUAL_QA_DEC-0080.md
- **Implementering:** src/core/generation/brief.ts, src/core/generation/image-prompt.ts, src/app/library/GenerateImagePanel.tsx, src/adapters/ai/providers.server.ts

#### REQ-0625 – Stilanalyse av forbildebildene
«Analyser stilen i forbildebildene …» i «Filmens visuelle stil» sender forbildebildene til en bildeforstående språkmodell (bekreftes; koster litt) som beskriver teknikk, strek, formspråk, farger (med koder), lys, tekstur, detaljnivå, komposisjon og hva som bryter stilen – på norsk og engelsk. Brukeren velger hva som legges inn i stilfeltene; ingenting lagres før «Lagre».

- **Kilde:** Beslutning DEC-0080 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** PROMPT, UI
- **Status:** Implementert – ikke verifisert
- **Akseptansekriterier:**
  - Analysen vises med avkrysning per del; valgte deler havner i riktige felt.
- **Tester:**
  - tests/unit/funn-2026-10-14.test.ts
  - docs/development/VISUAL_QA_DEC-0080.md
- **Implementering:** src/core/generation/style-analysis.ts, src/adapters/ai/write-prompt.functions.ts, src/app/projects/StyleGuideSection.tsx

#### REQ-0626 – Visuelt faktaark per ressurs
Hver ressurs kan ha et kort engelsk faktaark med det som synes (alder, kropp, hår, klær, farger, kjennetegn), ett per linje. Et utkast kan lages fra manuset og forsidebildet med AI (bekreftes), rettes og lagres (assets.visual_brief, migrasjon 0030). Faktaarket brukes i bildebeskrivelsene i stedet for manusutdrag.

- **Kilde:** Beslutning DEC-0080 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** LIBRARY, PROMPT
- **Status:** Implementert – ikke verifisert
- **Akseptansekriterier:**
  - Faktaarket lagres, angres og leses tilbake likt.
  - Beskrivelsen bruker faktaarket og tar ikke med manusutdrag.
- **Tester:**
  - tests/unit/funn-2026-10-14.test.ts
  - tests/db/run-db-tests.ts
  - docs/development/VISUAL_QA_DEC-0080.md
- **Implementering:** src/app/library/VisualBriefEditor.tsx, src/core/generation/style-analysis.ts, src/core/commands/apply.ts, db/migrations/0030_views_visual_brief.sql

#### REQ-0627 – Seedream 4.5 og Qwen-Image-Edit
Via fal.ai kan bilder lages med Seedream 4.5 (opptil 10 forbilder, ca. 0,04 USD per bilde) og Qwen-Image-Edit (endrer et bilde, negativ beskrivelse, ca. 0,03 USD per megapiksel). Qwen krever et forbilde; det sjekkes før noe betales.

- **Kilde:** Beslutning DEC-0080 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** PROVIDER
- **Status:** Implementert – ikke verifisert
- **Akseptansekriterier:**
  - Seedream sendes til /edit med image_urls når forbilder finnes.
  - Qwen uten forbilde avvises før kallet.
- **Tester:**
  - tests/unit/funn-2026-10-14.test.ts
- **Implementering:** src/core/generation/providers.ts, src/adapters/ai/providers.server.ts, src/adapters/ai/generate-image.functions.ts

#### REQ-0628 – Oppskalering
Et bilde kan oppskaleres 2× eller 4× via fal.ai: SeedVR2 (skarpere, ca. 0,001 USD per megapiksel) eller Clarity (med AI-detaljer, ca. 0,03 USD per megapiksel). Prisen regnes fra størrelsen på resultatet og vises før «Ja, oppskaler»; resultatet blir en ny versjon (med samme vinkel).

- **Kilde:** Beslutning DEC-0080 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** PROVIDER, LIBRARY
- **Status:** Implementert – ikke verifisert
- **Akseptansekriterier:**
  - Anslaget følger megapikslene i resultatet.
  - Oppskalering uten tilkoblet fal.ai forklares; den innebygde tjenesten kan ikke oppskalere.
- **Tester:**
  - tests/unit/funn-2026-10-14.test.ts
  - docs/development/VISUAL_QA_DEC-0080.md
- **Implementering:** src/app/library/ImageAiPanels.tsx, src/adapters/ai/providers.server.ts, src/adapters/ai/generate-image.functions.ts, src/core/generation/providers.ts

#### REQ-0629 – Tjenesten på norsk og engelsk
Brukeren kan veksle mellom norsk og engelsk som språk i tjenesten. Valget gjøres på hovedsiden (prosjektlisten), huskes og gjelder alle tekster brukeren ser: knapper, menyer, dialoger, meldinger, feilmeldinger, hjelpetekster, verktøytips og skjermlesertekster, også datoer og tall. Norsk er standard. Brukerens eget innhold (manus, notater, navn) oversettes ikke.

- **Kilde:** Beslutning DEC-0081 · **Opprinnelse:** brukerbeslutning · **Type:** ux · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** UI, L10N
- **Avhengigheter:** REQ-0014
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Med engelsk valgt finnes ingen norske ord i synlig tekst, verktøytips eller skjermlesertekster på hovedvisningene.
  - Valget huskes til neste gang og kan endres tilbake.
- **Tester:**
  - enhet: alle brukervendte tekster har norsk og engelsk
  - visuell: engelsk gjennomgang av hovedvisningene
- **Implementering:** src/core/i18n/index.ts, src/app/i18n/language.tsx, src/app/projects/ProjectsScreen.tsx, src/core/i18n/catalog.gen.ts

#### REQ-0630 – All ny brukervendt tekst på begge språk
All videre utvikling skal ha norsk og engelsk for hver ny eller endret brukervendt tekst (også verktøytips og feilmeldinger). En automatisk kontroll stopper tekst som bare finnes på ett språk.

- **Kilde:** Beslutning DEC-0081 · **Opprinnelse:** brukerbeslutning · **Type:** prinsipp · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** UI, L10N
- **Avhengigheter:** REQ-0014
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Kontrollen feiler når en brukervendt tekst mangler engelsk.
- **Tester:**
  - enhet: kontroll av tekster uten engelsk
- **Implementering:** scripts/i18n/check.mjs, docs/development/I18N_GUIDE.md

#### REQ-0631 – Prosjektlisten viser hvert prosjekt som en boks med eier, rolle og filmene i prosjektet
Hovedsiden viser ett felt (boks) per prosjekt. Boksen viser tydelig hvem som eier prosjektet, hvilken rolle brukeren selv har (eier, redaktør, kommentator, leser), antall medlemmer og når prosjektet ble opprettet. Under står hovedfilmen og alle spinoffer, trailere og andre varianter, med avledede produksjoner rykket inn under den de er laget fra. Hver produksjon viser type, dato og notatet om hva den er, og åpner prosjektet med den produksjonen valgt.

- **Kilde:** Beslutning DEC-0082 · **Opprinnelse:** brukerbeslutning · **Type:** ux · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** UI, COLLAB
- **Avhengigheter:** REQ-0353; REQ-0520
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Et prosjekt brukeren er redaktør i viser eierens navn og «Du er redaktør».
  - Spinoffer og varianter vises under hovedfilmen med type, dato og notat.
- **Tester:**
  - visuell: prosjektlisten på norsk og engelsk med to prosjekter og flere varianter
- **Implementering:** src/app/projects/ProjectsScreen.tsx, src/adapters/browser/projects.ts, src/app/project/use-production.tsx

#### REQ-0632 – Notat om hva hver produksjon er
Hver produksjon (hovedfilm, spinoff, trailer …) kan ha et notat på høyst 2000 tegn om hva den er. Notatet skrives når produksjonen lages og kan endres på prosjektoversikten av den som kan redigere. Endringen kan angres og lagres i databasen (migrasjon 0031).

- **Kilde:** Beslutning DEC-0082 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** COLLAB, CORE
- **Avhengigheter:** REQ-0353
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Notatet lagres, leses tilbake likt og kan angres.
  - Notat over 2000 tegn avvises både i kjernen og i databasen.
- **Tester:**
  - db: 0031 notat på produksjonen
- **Implementering:** src/core/commands/apply.ts, src/core/patch.ts, db/migrations/0031_production_note.sql, src/app/projects/ProductionList.tsx, src/app/projects/ProductionDialog.tsx

#### REQ-0633 – Send 2D-scenen til AI-video fra sceneeditoren
En knapp i sceneeditorens verktøylinje sender scenen i fokus til AI-generering. 2D-scenen sendes som video (bare bilde) til en modell som tegner den om til ferdig film, slik at bevegelser, plassering, timing, uttrykk og kamera følger 2D-scenen. Modeller: Kling O3 Edit (fal.ai) og Aleph 2 (Runway) med prosjektets egne nøkler.

- **Kilde:** Beslutning DEC-0083 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** UI, PROVIDER, COMPOSE
- **Avhengigheter:** REQ-0180; REQ-0243
- **Status:** Implementert – ikke verifisert
- **Akseptansekriterier:**
  - Knappen finnes i sceneeditoren og åpner dialogen for scenen i fokus.
  - Det som sendes, er 2D-scenen også når en annen versjon vises i filmen.
- **Tester:**
  - visuell: knapp, dialog og sending med mocket leverandør
  - enhet: forespørselen til fal.ai og Runway
- **Implementering:** src/app/scene-editor/SceneToVideoDialog.tsx, src/core/generation/scene-to-video.ts, src/adapters/ai/providers.server.ts, src/adapters/ai/video.functions.ts, src/adapters/ai/video-followup.server.ts

#### REQ-0634 – Beskrivelsen for AI-video fra 2D-scenen bygges av stil, figurer og instrukser
Beskrivelsen bygges automatisk av filmens visuelle stil, figurene i scenen (beskrivelse, visuelt faktaark og referansebilde for så mange som modellen tar imot, karakterer først), manusets handling og replikker i biten (bare for spill) og scenens egne instrukser. Den vises før sending. Er modellens grense for lengde nådd, tas stilnotater og manusdetaljer bort først; instruksene beholdes.

- **Kilde:** Beslutning DEC-0083 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** PROMPT
- **Avhengigheter:** REQ-0244; REQ-0148
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Instruksene og figurene står i beskrivelsen.
  - Beskrivelsen til Aleph 2 er høyst 1000 tegn og beholder instruksene.
- **Tester:**
  - enhet: beskrivelse for Kling og Aleph
- **Implementering:** src/core/generation/scene-to-video.ts

#### REQ-0635 – Instrukser til AI-video lagres per scene
Hver scene kan ha instrukser til AI-video (høyst 2000 tegn): hva som skal skje og hvordan figurene skal spille. De lagres på scenen, brukes neste gang og kan angres (migrasjon 0032).

- **Kilde:** Beslutning DEC-0083 · **Opprinnelse:** brukerbeslutning · **Type:** data · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** CORE, PROMPT
- **Avhengigheter:** REQ-0633
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Instruksene lagres, leses tilbake likt og kan angres.
  - Over 2000 tegn avvises i kjernen og i databasen.
- **Tester:**
  - enhet: SetSceneVideoInstructions
  - db: 0032
- **Implementering:** src/core/commands/apply.ts, src/core/patch.ts, db/migrations/0032_scene_video_instructions.sql

#### REQ-0636 – AI-video fra 2D-scenen erstatter bare bildet
Modellen bes om å ikke lage lyd, og resultatet legges inn som versjon uten lyd. Scenens egne lydklipp (replikker, effekter og musikk) spilles og eksporteres som før.

- **Kilde:** Beslutning DEC-0083 · **Opprinnelse:** brukerbeslutning · **Type:** prinsipp · **Prioritet:** P0 · **Fase:** 5
- **Moduler:** AUDIO, VERSION
- **Avhengigheter:** REQ-0633
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Versjonen er merket uten lyd og bidrar ikke til filmens lyd.
  - Scenens lydklipp er uendret.
- **Tester:**
  - enhet: bunt brukt i scenen
- **Implementering:** src/app/ai/video-jobs.ts, src/adapters/ai/providers.server.ts

#### REQ-0637 – Brukeren velger hva som viser scenen, og ingenting kastes
Hvert resultat er en ny versjon av scenen. I sceneeditoren velger brukeren hva som viser scenen: 2D-scenen, en AI-video fra 2D-scenen (satt sammen av bitene), en annen AI-video, opplastet film eller et stillbilde. Nye videoer kan lages når som helst; tidligere versjoner beholdes. Valget kan angres.

- **Kilde:** Beslutning DEC-0083 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P0 · **Fase:** 5
- **Moduler:** UI, VERSION, TIMELINE
- **Avhengigheter:** REQ-0233; REQ-0180
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Valget i sceneeditoren endrer det filmen viser, og kan angres.
  - Tidligere versjoner står fortsatt i listen.
- **Tester:**
  - visuell: valg og status i dialogen
  - enhet: batchSceneEdit og batchInUse
- **Implementering:** src/app/scene-editor/SceneToVideoDialog.tsx, src/core/generation/scene-to-video.ts

#### REQ-0638 – Lange scener deles i biter, og prisen må bekreftes
En scene lengre enn modellen tar imot deles i like lange biter innenfor modellens grenser (Kling 3–15 s, Aleph 2–30 s) og settes sammen igjen i rekkefølge. Anslått pris for alle bitene vises og må bekreftes før noe sendes. En scene kortere enn modellens korteste lengde kan ikke sendes.

- **Kilde:** Beslutning DEC-0083 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** QUALITYCOST, PROVIDER
- **Avhengigheter:** REQ-0281; REQ-0633
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Bitene dekker hele scenen uten overlapp.
  - Ingenting sendes før prisen er bekreftet.
- **Tester:**
  - enhet: planScenePieces
  - visuell: bekreftelse før sending
- **Implementering:** src/core/generation/scene-to-video.ts, src/app/scene-editor/SceneToVideoDialog.tsx

#### REQ-0639 – Leverandørnavnet «Lovable» står ikke i grensesnittet
Grensesnittet nevner ikke Lovable (heller ikke i meldinger om databaseoppdatering). Den innebygde AI-tjenesten og databasen omtales nøytralt, så teksten stemmer også når tjenesten kjøres lokalt.

- **Kilde:** Beslutning DEC-0084 · **Opprinnelse:** brukerbeslutning · **Type:** ux · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** UI
- **Avhengigheter:** REQ-0629
- **Status:** Ikke startet
- **Akseptansekriterier:**
  - Ingen brukervendt tekst inneholder «Lovable».
- **Tester:**
  - enhet: søk i brukervendt tekst

#### REQ-0640 – Den globale beskrivelsen er én redigerbar tekst for hele prosjektet
Filmens visuelle stil settes sammen til én tekst som vises i sin helhet. Brukeren kan åpne den for redigering med tydelig melding om at endringen gjelder hele prosjektet. Den redigerte teksten er den ene versjonen og brukes av all AI-generering; «Tilbake til feltene» setter den sammen av feltene igjen.

- **Kilde:** Beslutning DEC-0085 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** PROVIDER
- **Avhengigheter:** REQ-0633
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Redigert tekst brukes i bilde- og videoprompter.
  - Melding om global endring vises ved redigering.
- **Tester:**
  - tests/unit/scene-to-video.test.ts
  - tests/visual/scene-video-ui.mjs
- **Implementering:** src/core/generation/style.ts, src/app/projects/GlobalStyleText.tsx

#### REQ-0641 – Den globale beskrivelsen kan krysses vekk i AI-video av scenen
I «AI-video av scenen» er den globale beskrivelsen med som standard. Brukeren kan krysse den vekk; teksten grås da ut og sendes ikke.

- **Kilde:** Beslutning DEC-0085 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** PROVIDER
- **Avhengigheter:** REQ-0633
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Standard er på.
  - Avkrysset vekk: teksten grås ut og er ikke i prompten.
- **Tester:**
  - tests/visual/scene-video-ui.mjs
- **Implementering:** src/app/scene-editor/SceneToVideoDialog.tsx

#### REQ-0642 – Scenebeskrivelse fra manuset, med «Skriv med AI»
Dialogen har feltet «Scenebeskrivelse» laget fra manuset (sted, tid, figurer, handling, replikker i rekkefølge, kamera og lys) i formen leverandørene anbefaler. Brukeren kan redigere den, hente den fra manuset på nytt eller la AI skrive den. Den lagres per scene.

- **Kilde:** Beslutning DEC-0085 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** PROVIDER
- **Avhengigheter:** REQ-0633
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Teksten lages uten AI fra manuset.
  - «Skriv med AI» viser pris som andre tekstkall.
- **Tester:**
  - tests/unit/scene-to-video.test.ts
- **Implementering:** src/core/generation/scene-to-video.ts, src/app/scene-editor/SceneToVideoDialog.tsx, src/app/ai/write-prompt.functions.ts

#### REQ-0643 – Figurer, bakgrunn og objekter sendes som referansebilder, med samleark
Figurkort, bakgrunn og objekter i scenen sendes som referansebilder. Overskrider de modellens antall, settes de overskytende sammen til ett samleark med navn under hvert bilde. Hver referanse kan velges bort.

- **Kilde:** Beslutning DEC-0085 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** PROVIDER
- **Avhengigheter:** REQ-0633
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Aldri flere bilder enn modellen tar.
  - Samleark når det er for mange.
- **Tester:**
  - tests/unit/scene-to-video.test.ts
- **Implementering:** src/core/generation/scene-to-video.ts, src/app/scene-editor/SceneToVideoDialog.tsx, src/app/ai/video.functions.ts

#### REQ-0644 – Kilden for AI-videoen kan være 2D-scenen, en AI-versjon eller en opplastet video
Brukeren velger hva som sendes: 2D-scenen, en tidligere AI-video av scenen eller en opplastet/annen versjon. Videoen er lik det avspillingen viser, uten undertekster.

- **Kilde:** Beslutning DEC-0085 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** PROVIDER
- **Avhengigheter:** REQ-0633
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Undertekster sendes aldri.
- **Tester:**
  - tests/unit/scene-to-video.test.ts
  - tests/visual/scene-video-ui.mjs
- **Implementering:** src/core/generation/scene-to-video.ts, src/app/scene-editor/SceneToVideoDialog.tsx

#### REQ-0645 – Brukeren velger om lyden sendes; lyd fra AI-videoen blir eget dempet spor
Brukeren velger om scenens lyd sendes med. En ferdig AI-video spilles uten lyd; har den lyd, legges lyden inn som eget dempet lydspor på scenen som kan flyttes og justeres.

- **Kilde:** Beslutning DEC-0085 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** PROVIDER
- **Avhengigheter:** REQ-0633
- **Status:** Verifisert
- **Akseptansekriterier:**
  - AI-video spilles uten lyd.
  - Lydsporet er dempet og flyttbart.
- **Tester:**
  - tests/unit/scene-to-video.test.ts
- **Implementering:** src/app/ai/video-audio.ts, src/app/ai/video-jobs.ts

#### REQ-0646 – Nedlasting med valg av videoformat og undertekster
Nedlastingsvinduet har valg av format (MP4 eller WebM) og undertekster (brent inn, egen SRT- eller VTT-fil, eller ingen). Scenen kan lastes ned fra «AI-video av scenen». ProRes/MOV er planlagt (TODO.md).

- **Kilde:** Beslutning DEC-0085 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** PROVIDER
- **Avhengigheter:** REQ-0633
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Undertekster brennes bare inn når det er valgt.
- **Tester:**
  - tests/visual/export-e2e.mjs
- **Implementering:** src/engine/export/animatic.ts, src/app/assembly/ExportAnimaticDialog.tsx

#### REQ-0647 – Status for AI-genereringer i toppfeltet
Toppfeltet viser en liten status i prosjektet: hvor mange genereringer som lages og står i kø, og hva som nylig ble ferdig eller feilet. Et klikk viser listen med lenke til scenen.

- **Kilde:** Beslutning DEC-0085 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** PROVIDER
- **Avhengigheter:** REQ-0633
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Vises bare når prosjektet har genereringer.
- **Tester:**
  - tests/visual/scene-video-ui.mjs
- **Implementering:** src/app/ai/GenerationStatus.tsx, src/app/shell/AppHeader.tsx

#### REQ-0648 – Sceneeditoren kan spille av versjonen som er valgt for scenen
Avspillingen i sceneeditoren kan vise versjonen som er valgt for scenen (AI-video eller opplastet film) i stedet for 2D-scenen. Valget slås av og på i visningsvalgene. Hvilken versjon som brukes og opplasting av video velges i «AI-video av scenen».

- **Kilde:** Beslutning DEC-0085 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** PROVIDER
- **Avhengigheter:** REQ-0633
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Valgt versjon vises synkront med avspillingen.
- **Tester:**
  - tests/visual/scene-video-ui.mjs
- **Implementering:** src/app/scene-editor/SceneEditorWorkspace.tsx, src/app/scene-editor/PreviewWindow.tsx

#### REQ-0649 – En ferdig AI-video hentes inn selv om prosjektet var lukket i timevis
Leverandøren spørres alltid om videoen før en jobb regnes som tapt. En videojobb merkes «Betalt, ikke lagret» først når leverandøren sier at den feilet, eller etter sju dager uten resultat. «Hent videoen igjen» spør leverandøren på nytt med lagret jobb-ID, uten å bestille noe på nytt.

- **Kilde:** Beslutning DEC-0086 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** QUEUE, PROVIDER
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En video ferdig mens prosjektet var lukket i fire timer, lagres.
  - «Hent videoen igjen» bestiller ingenting på nytt; bare redaktører.
- **Tester:**
  - tests/unit/verifisering3-ai-server.test.ts
- **Implementering:** src/adapters/ai/video-followup.server.ts, src/adapters/ai/video.functions.ts, src/app/ai/RefetchVideoButton.tsx, src/core/generation/cost.ts

#### REQ-0650 – Adminside bare for administrator; oystein@gutu.no er fast administrator
Adminsiden viser alle brukerne med navn, e-post, når kontoen ble laget, sist aktiv, status, prosjektene (bare navn og rolle) og AI-forbruk. Tilgangen kontrolleres på serveren. oystein@gutu.no er fast administrator og kan aldri blokkeres, slettes eller nedgraderes. Administrator kan gjøre andre til administrator. Administrator ser aldri innholdet i prosjektene.

- **Kilde:** Beslutning DEC-0086 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** SECURITY
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Vanlige brukere får ingen oversikt.
  - Den faste administratoren kan ikke endres.
- **Tester:**
  - tests/unit/account-admin.test.ts
  - tests/db/run-db-tests.ts
  - tests/visual/account-admin-ui.mjs
- **Implementering:** db/migrations/0033_accounts_admin_privacy.sql, src/adapters/account/admin.functions.ts, src/app/admin/AdminPage.tsx, src/routes/admin.tsx

#### REQ-0651 – Blokkering og sletting av brukere (30 dager, bare administrator låser opp)
Administrator kan blokkere (innloggingen sperres) og oppheve blokkering. Brukeren kan slette seg selv ved å skrive e-posten sin; administrator kan også slette. En slettet konto låses i 30 dager og kan i den tiden bare låses opp av administrator; deretter anonymiseres den (e-post, navn, nøkler, innlogging og medlemskap fjernes; historikken står som «Slettet bruker»). Prosjekter slettes ikke.

- **Kilde:** Beslutning DEC-0086 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** SECURITY
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Feil e-post sletter ingenting.
  - Etter 30 dager anonymiseres kontoen; eierskap står til prosjektet får ny eier.
- **Tester:**
  - tests/unit/account-admin.test.ts
  - tests/visual/account-admin-ui.mjs
- **Implementering:** src/adapters/account/account.functions.ts, src/adapters/account/admin.functions.ts, src/app/account/AccountPage.tsx

#### REQ-0652 – Låste prosjekter og ny eier
Er eieren blokkert, låst for sletting eller slettet, er prosjektet låst for alle: ingen kan skrive (håndhevet i databasen), og medlemmene ser bare en melding om hvem de kan kontakte (eierens visningsnavn og administrator). Blokkeres en annen rolle, kan de andre jobbe videre. Administrator gir et låst prosjekt ny eier; tidligere eiere blir redaktører.

- **Kilde:** Beslutning DEC-0086 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** SECURITY, COLLAB
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En blokkert redaktør låser ikke prosjektet.
  - Ny eier åpner prosjektet igjen.
- **Tester:**
  - tests/db/run-db-tests.ts
  - tests/unit/account-admin.test.ts
  - tests/visual/account-admin-ui.mjs
- **Implementering:** db/migrations/0033_accounts_admin_privacy.sql, src/adapters/account/lock.server.ts, src/routes/prosjekt.$projectId.tsx

#### REQ-0653 – Personvernerklæring etter GDPR, før og etter innlogging, med versjoner
Personvernerklæringen kan leses fra forsiden før innlogging og fra kontosiden. Den sier at vi ikke selger data, hva som lagres og hvorfor, hvor det lagres, at AI-videresending med egne nøkler er brukerens ansvar og en risiko, hvor lenge data lagres og brukerens rettigheter. Administrator fyller ut behandlingsansvarlig, kontakt og lagringssted; hver lagring er en ny versjon som brukerne må bekrefte at de har lest. Ny konto krever avkrysning.

- **Kilde:** Beslutning DEC-0086 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** SECURITY
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Kan leses uten innlogging.
  - Ny versjon må bekreftes før man fortsetter.
- **Tester:**
  - tests/db/run-db-tests.ts
  - tests/unit/account-admin.test.ts
  - tests/visual/account-admin-ui.mjs
- **Implementering:** src/app/account/PrivacyStatement.tsx, src/app/account/use-account.tsx, src/routes/personvern.tsx, src/app/auth/AuthScreen.tsx

#### REQ-0654 – Kostnadsrapport for AI-bruk med eksport til PDF, Word og Excel
Alle med endringsrett ser sitt eget AI-forbruk i prosjektet; eieren ser også prosjektet totalt; på kontoen ser brukeren alt hen har bestilt. Kalendermåned eller hele perioden, i dollar eller kroner (Norges Banks kurs for dagen). Rapporten har prosjektnavnet øverst, sammendrag, fordeling per tjeneste og modell, per måned og per person, linjer med leverandørens jobb-ID og merknader (anslått pris, uten mva). Eksport til PDF, Word og Excel.

- **Kilde:** Beslutning DEC-0086 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** QUALITYCOST
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Feilede jobber og jobber i kø er ikke med.
  - Bare eieren ser prosjektet totalt.
- **Tester:**
  - tests/unit/cost-report.test.ts
  - tests/unit/account-admin.test.ts
  - tests/visual/account-admin-ui.mjs
- **Implementering:** src/core/generation/cost-report.ts, src/app/account/CostReportView.tsx, src/app/account/cost-export.ts, src/adapters/account/account.functions.ts

#### REQ-0655 – Min konto: profil, språk, passord og sist aktiv
Et klikk på brukernavnet i toppfeltet åpner «Min konto»: visningsnavn, e-post, når kontoen ble laget, rolle, språk (lagres på kontoen og gjelder ved neste innlogging), nytt passord, AI-forbruk, personvern og «Slett kontoen min». Administrator ser «Admin» i toppfeltet. Sist aktiv oppdateres høyst én gang i timen.

- **Kilde:** Beslutning DEC-0086 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Språket på kontoen gjelder ved innlogging.
  - Passordet må ha minst 8 tegn og gjentas likt.
  - Språkbytte blir stående (kontoens språk overstyrer ikke et nytt valg).
  - Klikk på brukernavnet igjen, eller «Lukk» nederst, lukker siden.
- **Tester:**
  - tests/db/run-db-tests.ts
  - tests/visual/account-admin-ui.mjs
- **Implementering:** src/app/account/AccountPage.tsx, src/app/shell/AppHeader.tsx, src/adapters/browser/account.ts, src/routes/konto.tsx

#### REQ-0656 – Bildeverktøy: delelinjer, navngitte deler, «Lag delingen», «Fjern luften rundt» og «Lag variasjoner»
I bildevisningen kan delelinjene dras hver for seg. Delene heter «1.», «2.» … i sidepanelet; delen i fokus får varmgul ramme (2 px) og fet varmgul nummer med mørk skygge. «Lag delingen» lager delene som nye bilder. «Fjern luften rundt» beskjærer bildet til innholdet. «Lag variasjoner» spør «Hva ønsker du forskjellig?» og bruker vanlig kostnadsgodkjenning.

- **Kilde:** Beslutning DEC-0088 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** LIBRARY, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Delelinjer kan flyttes uavhengig av hverandre.
  - Fokusert del har varmgul ramme og nummer.
  - «Fjern luften rundt» fjerner tom kant rundt innholdet.
- **Tester:**
  - tests/unit/image-tools.test.ts
  - tests/visual/image-tools-ui.mjs
- **Implementering:** src/app/library/ImageLightbox.tsx, src/app/library/ImagePartsPanel.tsx, src/app/library/ImageAiPanels.tsx, src/core/cutout/split.ts, src/core/cutout/trim.ts

#### REQ-0657 – Dørdeler: deler legges i scenen med ankerpunkt på hengselsiden
Deler av et bilde (f.eks. dørramme og dørblad) kan legges rett inn i 2D-scenen der de lå i originalen, i samme størrelse som originallaget. En del med ankerpunkt til venstre eller høyre legges i en egen gruppe med ankerpunktet midt på hengselkanten, så skalering i bredden skjer rundt hengselen. Er resten av originalen med som egen del, skjules originallaget. Ett angresteg.

- **Kilde:** Beslutning DEC-0088 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** COMPOSE
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Dørbladet får gruppe med ankerpunkt på valgt kant.
  - Originallaget skjules når resten er med.
- **Tester:**
  - tests/unit/dec0088-scene-plans.test.ts
  - tests/visual/image-tools-ui.mjs
- **Implementering:** src/core/composition/parts.ts, src/app/scene-editor/LayerImageDialog.tsx

#### REQ-0658 – «Legg til element i scenen …» med spørsmål om andre scener
Over «Dra inn på lerretet» i «I denne scenen» åpner «Legg til element i scenen …» et valg fra biblioteket eller et nytt element som ikke står i manuset. Deretter spør systemet om elementet også skal inn i andre scener, med hurtigvalg (alle scener med hver karakter/dyr i scenen, alle scener på samme sted, alle scener etter denne) og avkrysning per scene. Planen lagres på elementet (assets.scene_plans).

- **Kilde:** Beslutning DEC-0088 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** LIBRARY, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Hurtigvalget «Alle scener med Maja» krysser av scenene med Maja.
  - PlanAssetInScenes kan angres.
- **Tester:**
  - tests/unit/dec0088-scene-plans.test.ts
  - tests/db/run-db-tests.ts
  - tests/visual/dec0088-tasks-ui.mjs
- **Implementering:** src/app/scene-editor/AddElementDialog.tsx, src/core/library/scene-plans.ts, src/core/commands/apply.ts

#### REQ-0659 – Elementer som skal inn: varmgul ramme og melding i de andre scenene
I scenene elementet er planlagt for, legges det ikke inn automatisk. Det vises i «I denne scenen» med varmgul ramme, merket «Skal inn» og meldingen «Skal inn fordi det ble lagt til i scene N», til brukeren drar det inn på lerretet eller fjerner det med X (bare for den scenen).

- **Kilde:** Beslutning DEC-0088 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** COMPOSE, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Rammen forsvinner når elementet er dratt inn.
  - X fjerner planen bare for scenen.
- **Tester:**
  - tests/unit/dec0088-scene-plans.test.ts
  - tests/visual/dec0088-tasks-ui.mjs
- **Implementering:** src/app/scene-editor/SceneAssetsPanel.tsx, src/core/library/scene-plans.ts

#### REQ-0660 – Systemmerknader i manuset og i eksport
Ved planlegging kan en merknad legges i manuset i hver valgt scene (tekst kan endres). Den er merket «Systemmerknad» og lukkes med «Ferdig» eller slettes; manuset endres aldri automatisk. I PDF, Word og Fountain er den med som andre notater, med forfatter «Animatic Studio (systemmerknad)» (PDF: emne «Systemmerknad»). Lagres som script_annotations.source = 'system' med task_id.

- **Kilde:** Beslutning DEC-0088 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** SCRIPT
- **Status:** Verifisert
- **Akseptansekriterier:**
  - «Ferdig» lagrer merknaden som ferdig (kan angres).
  - Eksporten viser systemmerknaden med eget forfatternavn.
- **Tester:**
  - tests/unit/dec0088-scene-plans.test.ts
  - tests/db/run-db-tests.ts
  - tests/visual/dec0088-tasks-ui.mjs
- **Implementering:** src/app/script/NotesPanel.tsx, src/core/notes/transfer.ts, src/engine/export/screenplay-pdf.ts

#### REQ-0661 – Oppgaven i toppstripen med forrige og neste
Åpne oppgaver (et element som skal inn i flere scener) vises i toppstripen med navn og antall som gjenstår («Bestemor Anne: 2 av 3») og ‹ ›. Forrige/neste går til neste scene som ikke er ferdig, i manuset eller sceneeditoren der man står, ellers i sceneeditoren. En scene er ferdig når elementet er dratt inn og merknaden er lukket. Listen viser alle oppgaver og scenene deres. Systemet glemmer ikke scenene før de er ferdige.

- **Kilde:** Beslutning DEC-0088 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - ‹ › går rundt blant scenene som ikke er ferdige.
  - Oppgaven forsvinner når alle scenene er ferdige.
- **Tester:**
  - tests/unit/dec0088-scene-plans.test.ts
  - tests/visual/dec0088-tasks-ui.mjs
- **Implementering:** src/app/shell/TaskNav.tsx, src/app/shell/current-scene.ts, src/core/library/scene-plans.ts

#### REQ-0662 – TODO-boks på prosjektsiden
Prosjektsiden har boksen «TODO» med oversikt over hva som skal gjøres i valgt produksjon: oppgavene (med lenke til første scene), notater fra andre i manuset (nyeste først; ikke egne notater og ikke systemmerknader), scener med manusendringer etter 2D-scene eller film, arbeidslisten (eldre ressursversjoner) og AI-genereringer som feilet eller ble borte siste uke.

- **Kilde:** Beslutning DEC-0088 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Egne notater er ikke med.
  - Tom boks sier at ingenting venter.
- **Tester:**
  - tests/unit/dec0088-scene-plans.test.ts
  - tests/visual/dec0088-tasks-ui.mjs
- **Implementering:** src/app/projects/ProjectTodoBox.tsx, src/core/library/todo.ts

#### REQ-0663 – Sceneeditor: paneler side om side og grupper som lukkes
Panelene i sceneeditoren kan stå side om side (alle til høyre) i rekkefølgen brukeren velger med ‹ ›. Grupper i laglisten lukkes og åpnes med pil (Alt-klikk: alle). Valgene lagres på kontoen (profiles.ui_prefs via set_my_ui_prefs) og følger brukeren mellom maskiner, som språket.

- **Kilde:** Beslutning DEC-0088 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** COMPOSE, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Rekkefølgen huskes i en ny nettleser (kontoen).
  - Lukket gruppe skjuler lagene sine.
- **Tester:**
  - tests/unit/scene-panels.test.ts
  - tests/unit/layer-groups.test.ts
  - tests/db/run-db-tests.ts
  - tests/visual/scene-panels-ui.mjs
- **Implementering:** src/app/scene-editor/ScenePanels.tsx, src/app/scene-editor/LayersPanel.tsx, src/app/account/ui-prefs.ts

#### REQ-0664 – Adminside: AI-tilkoblinger og status for bakgrunnsjobben
Administrator kan slå leverandører og modeller av og på, legge til modeller hos kjente leverandører og registrere ønsker om nye leverandører. Valglistene viser bare det som er på, og serveren avviser modeller som er slått av. Adminsiden viser når bakgrunnsjobben (/api/public/cron/ai-jobs) sist kjørte og hva den gjorde.

- **Kilde:** Beslutning DEC-0088 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** PROVIDER
- **Status:** Verifisert
- **Akseptansekriterier:**
  - En modell som er slått av, vises ikke og avvises av serveren.
  - Cron-status vises med tidspunkt.
- **Tester:**
  - tests/unit/ai-model-settings.test.ts
  - tests/unit/ai-admin.test.ts
  - tests/db/run-db-tests.ts
  - tests/visual/ai-admin-ui.mjs
- **Implementering:** src/app/admin/AiConnectionsAdmin.tsx, src/core/generation/model-settings.ts, src/adapters/account/ai-models.server.ts, src/app/admin/cron-status.ts

#### REQ-0665 – Sceneeditor: panelet «Manus» med lesevisning av scenen
Sceneeditoren har et eget panel «Manus» som kan flyttes og lukkes som de andre. Det viser sceneoverskriften og teksten for valgt scene i manusform (innrykk per elementtype), følger scenen og markerer linjen som spilles av under avspilling (tider fra tidskobling, koblet lyd eller anslag). Notater er merket med et symbol.

- **Kilde:** Beslutning DEC-0089 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** COMPOSE, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Linjen som spilles av, er markert.
  - Panelet følger valgt scene.
- **Tester:**
  - tests/unit/dec0089-script-in-scene.test.ts
  - tests/visual/dec0089-script-panel-ui.mjs
- **Implementering:** src/app/scene-editor/SceneScriptPanel.tsx, src/core/assembly/film.ts

#### REQ-0666 – Sceneeditor: manuset redigeres i eget vindu, med forrige og neste scene til lesing
«Rediger manus …» i panelet «Manus», eller dobbeltklikk på en linje, åpner et stort vindu med samme lesevisning og inspektør som på Manus-siden: tekst, elementtype, ny og fjernet blokk, del scenen, sceneoverskrift, notater, systemmerknader og angre/gjør om. Bare denne scenen redigeres; forrige og neste scene kan vises over og under, bare til lesing. Endringer går gjennom de vanlige kommandoene og flagges i 2D-scenen som andre manusendringer.

- **Kilde:** Beslutning DEC-0089 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** SCRIPT, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Dobbeltklikk på en linje åpner vinduet med linjen valgt.
  - Forrige/neste scene kan ikke redigeres i vinduet.
- **Tester:**
  - tests/visual/dec0089-script-panel-ui.mjs
- **Implementering:** src/app/scene-editor/SceneScriptDialog.tsx, src/app/script/Inspector.tsx

#### REQ-0667 – Sceneeditor: alle panelene kan lukkes og åpnes
Hvert panel i sceneeditoren (I denne scenen, Lyd i scenene rundt, Lag, Egenskaper, Manus) kan lukkes og åpnes med en pil i overskriften. Stablet: et lukket panel er bare overskriften, og ˄ ˅ flytter panelet i kolonnen. Side om side: et lukket panel blir en smal stripe med navnet, og de andre panelene får plassen. Valget lagres på kontoen (profiles.ui_prefs) og følger brukeren. Forhåndsvisningen og tidslinjen kan ikke lukkes.

- **Kilde:** Beslutning DEC-0089 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** 5
- **Moduler:** COMPOSE, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Lukket panel huskes i en ny nettleser.
  - Lukket panel side om side blir en smal stripe.
- **Tester:**
  - tests/unit/scene-panels.test.ts
  - tests/visual/dec0089-script-panel-ui.mjs
  - tests/visual/scene-panels-ui.mjs
- **Implementering:** src/app/scene-editor/ScenePanels.tsx, src/app/scene-editor/panel-layout.ts, src/app/scene-editor/use-scene-panels.ts

#### REQ-0668 – Mobilimport fra prosjektsiden med QR-kode som vises med en gang
Prosjektsiden har «Importer fra mobil». Vinduet viser straks en QR-kode for prosjektet (ingen egen knapp for å vise den). Skanning med telefonens vanlige kamera åpner mobilsiden for prosjektet; ferdig opplastede filer blir tilgjengelige i prosjektet uten import på datamaskinen.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** LIBRARY, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - M1: QR-koden vises uten ekstra klikk.
  - M2: skanning åpner riktig mobilside.
- **Tester:**
  - tests/visual/dec0090-mobile-ui.mjs
- **Implementering:** src/app/projects/ProjectOverview.tsx, src/app/mobile/MobileImportDialog.tsx, src/app/mobile/QrCode.tsx

#### REQ-0669 – Mobilsiden: enkel, responsiv og bare det økten trenger
Mobilsiden er laget for iPhone og Android med store kontroller, og viser bare funksjonene som hører til økten (ta bilde, flere bilder, video, lyd, velge eksisterende bilder, video og lydfiler). Hele arbeidsgrensesnittet åpnes ikke på mobilen.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** ux · **Prioritet:** P1 · **Fase:** –
- **Moduler:** UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Bare relevante funksjoner vises for økten.
  - Siden virker på smal skjerm.
- **Tester:**
  - tests/visual/dec0090-mobile-ui.mjs
- **Implementering:** src/app/mobile/MobilePage.tsx, src/routes/m.$token.tsx

#### REQ-0670 – Kameraikon øverst til høyre i bilde- og videodialoger
Dialoger og paneler som arbeider med bilder eller video, har et kameraikon øverst til høyre (samme plass overalt). Klikk åpner en popup med QR-koden med en gang og forklarer hvor bildene havner (f.eks. «bildene legges til Maja»). Filene dukker opp i den åpne dialogen.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** LIBRARY, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - K1–K3: kameraikon hos Maja viser QR straks; bildet dukker opp i Majas dialog.
- **Tester:**
  - tests/visual/dec0090-mobile-ui.mjs
- **Implementering:** src/app/mobile/MobileImportDialog.tsx, src/app/library/AssetDetail.tsx, src/app/scene-editor/LayerImageDialog.tsx, src/app/scene-editor/SceneEditorWorkspace.tsx

#### REQ-0671 – Én QR-kode per kontekst – alt havner rett
Hver kontekst får sin egen QR-kode og opplastingsøkt: prosjekt, karakter, objekt, miljø/lokasjon, scene (hver scene sin kode), bildeplass i sceneeditoren, lydressurs og replikk. Systemet husker hvor importen ble startet og registrerer filen der; det gjør den ikke til aktiv hovedreferanse. Én fil kan ha flere koblinger uten å dupliseres.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** LIBRARY, SECURITY
- **Status:** Verifisert
- **Akseptansekriterier:**
  - K6: import til objekt, miljø eller scene havner i riktig kontekst.
  - K7: nytt materiale erstatter ikke godkjente ressurser.
  - Ulike scener gir ulike QR-koder.
- **Tester:**
  - tests/unit/mobile-import.test.ts
  - tests/unit/mobile-server.test.ts
  - tests/visual/dec0090-mobile-ui.mjs
- **Implementering:** src/core/mobile/index.ts, src/adapters/mobile/mobile.functions.ts, src/app/mobile/use-mobile-imports.ts

#### REQ-0672 – Import til en ressurs som ikke er lagret ennå
Fra en ny ressurs (f.eks. ny karakter) knyttes importen til en midlertidig kontekst. Når ressursen lagres, knyttes filene til den permanente ressursen. Avbrytes opprettelsen, blir filene liggende som uknyttede i mobilimportbiblioteket.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** LIBRARY
- **Status:** Verifisert
- **Akseptansekriterier:**
  - K4–K5: bilder tatt før lagring knyttes til karakteren ved lagring.
  - Avbrutt opprettelse: filene finnes i Mobilimport.
- **Tester:**
  - tests/db/run-db-tests.ts
  - tests/visual/dec0090-mobile-ui.mjs
- **Implementering:** src/app/library/LibraryWorkspace.tsx, db/migrations/0035_mobile_import.sql

#### REQ-0673 – Hurtigfotografering med automatisk opplasting og kø
Mobilsiden har en hurtigmodus: brukeren tar bilde etter bilde uten å velge fil, bekrefte eller starte på nytt. Hvert bilde legges i opplastingskøen og sendes mens brukeren fortsetter; status vises; ved ustabilt nett venter bildene i kø. Kameraet tar aldri bilder uten brukerens handling; tydelig «Ferdig».

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** LIBRARY, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - M3: flere bilder etter hverandre uten bekreftelse.
  - Bilder i kø sendes når nettet er tilbake.
- **Tester:**
  - tests/unit/mobile-import.test.ts
  - tests/visual/dec0090-mobile-ui.mjs
- **Implementering:** src/app/mobile/MobilePage.tsx, src/app/mobile/upload-queue.ts

#### REQ-0674 – Velge eksisterende bilder, video og lyd på telefonen
Mobilsiden lar brukeren velge filer som allerede finnes på telefonen, flere samtidig der plattformen støtter det.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** LIBRARY
- **Status:** Verifisert
- **Akseptansekriterier:**
  - M5: eksisterende bilde fra telefonens bibliotek importeres.
- **Tester:**
  - tests/visual/dec0090-mobile-ui.mjs
- **Implementering:** src/app/mobile/MobilePage.tsx

#### REQ-0675 – Videoimport fra mobilen
Brukeren kan ta opp eller velge video, forhåndsvise og laste opp. Videoen knyttes til konteksten (scene eller videodialog), originalfilen bevares, og programmet lager forhåndsvisning og leser metadata (varighet, størrelse).

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** LIBRARY
- **Status:** Verifisert
- **Akseptansekriterier:**
  - M6: video tatt opp eller valgt og lastet opp.
- **Tester:**
  - tests/unit/mobile-import.test.ts
  - tests/visual/dec0090-mobile-ui.mjs
- **Implementering:** src/app/mobile/MobilePage.tsx, src/app/mobile/mobile-actions.tsx, src/app/assembly/film-import.ts

#### REQ-0676 – Mobilimportbiblioteket
Alle filer fra mobilbroen registreres i ressursbiblioteket i en egen visning «Mobilimport» med filter for bilder, video, lyd, dato, importøkt, ressurskobling og bidragskilde. Bilder har miniatyr, video og lyd kan spilles av. Originalene bevares og ingenting godkjent overskrives.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** LIBRARY, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - M4: bildene står i Mobilimport.
  - Filtrene virker.
- **Tester:**
  - tests/visual/dec0090-mobile-ui.mjs
- **Implementering:** src/app/mobile/MobileImportLibrary.tsx, src/app/library/LibraryWorkspace.tsx

#### REQ-0677 – Sanntid mellom mobil og datamaskin
Når mobilen laster opp, oppdateres prosjektet på datamaskinen uten oppfriskning, også i åpne ressursdialoger. Importvinduet viser om mobilen er tilkoblet, antall mottatte filer, siste fil, pågående opplastinger og feil. En fil er ikke mottatt før serveren har bekreftet den.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** LIBRARY, COLLAB
- **Status:** Verifisert
- **Akseptansekriterier:**
  - M7: filer vises på datamaskinen uten oppfriskning.
- **Tester:**
  - tests/visual/dec0090-mobile-ui.mjs
- **Implementering:** src/adapters/browser/mobile-import.ts, src/app/mobile/use-mobile-imports.ts, src/app/mobile/MobileImportDialog.tsx

#### REQ-0678 – Sikre opplastingsøkter
Hver QR-kode og lenke er en opplastingsøkt med et langt tilfeldig token som bare gir rett til å laste opp i sin kontekst. Eier og redaktør kan lage økter. Egen QR-kode krever ikke innlogging på telefonen, gjelder 2 timer og merkes med brukerens navn. Utløp, tilbakekalling, kontroll av filtype og størrelse og begrensning av misbruk håndheves på serveren; mobilsiden får aldri skriverett til andre databaseobjekter, og alle filer registreres kontrollert.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** sikkerhet · **Prioritet:** P1 · **Fase:** –
- **Moduler:** SECURITY, COLLAB
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Utløpt eller tilbakekalt token avvises.
  - Feil filtype og for store filer avvises.
  - Token gir ingen lesing av manus eller andre data.
- **Tester:**
  - tests/db/run-db-tests.ts
  - tests/unit/mobile-server.test.ts
- **Implementering:** db/migrations/0035_mobile_import.sql, src/adapters/mobile/mobile.functions.ts

#### REQ-0679 – Størrelsesgrense for video (fjernes i desktopversjonen)
En videofil kan være inntil 500 MB i nettversjonen (lagringen i Lovable Cloud). Lengre opptak må deles opp. Den dagen en desktopversjon lages, fjernes grensen der uten nytt spørsmål til Mars.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** ikke-funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** SECURITY, LIBRARY
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Video over grensen avvises med forklaring.
  - Notat om desktopversjonen står i TODO og kildekoden.
- **Tester:**
  - tests/unit/mobile-import.test.ts
- **Implementering:** src/core/mobile/index.ts

#### REQ-0680 – Opplasting uten duplikater
Nye forsøk etter feil eller brutt forbindelse gir ikke duplikater (hver fil har en ID fra mobilen som serveren gjenkjenner). Flere samtidige opplastinger håndteres, og store filer lastes direkte til lagringen uten å gå gjennom appens server.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** ikke-funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** SECURITY, LIBRARY
- **Status:** Verifisert
- **Akseptansekriterier:**
  - M8: feil under opplasting gir ikke duplikater.
- **Tester:**
  - tests/db/run-db-tests.ts
  - tests/unit/mobile-import.test.ts
- **Implementering:** db/migrations/0035_mobile_import.sql, src/app/mobile/upload-queue.ts

#### REQ-0681 – «Del lenke» fra mobilsiden
Mobilsiden har «Del lenke» som bruker telefonens egen delingsfunksjon (Web Share). Uten den kan lenken kopieres. Ingen egne SMS-, WhatsApp-, Messenger- eller e-postintegrasjoner.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** COLLAB, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - D1–D3: delingsfunksjonen åpnes, ellers kopier lenke.
- **Tester:**
  - tests/visual/dec0090-mobile-ui.mjs
- **Implementering:** src/app/mobile/MobilePage.tsx

#### REQ-0682 – Delt bidragslenke med egne, begrensede rettigheter
En delt lenke beholder konteksten (f.eks. bilder av Maja), kan åpnes uten konto og gir bare opplasting. Den har egne rettigheter, atskilt fra den personlige QR-økten: gjelder 7 dager, kan tilbakekalles og har tak på antall filer og total størrelse. Manus, andre ressurser, prosjektinnstillinger og prosjektets AI-tjenester er utilgjengelige.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** sikkerhet · **Prioritet:** P1 · **Fase:** –
- **Moduler:** SECURITY, COLLAB
- **Status:** Verifisert
- **Akseptansekriterier:**
  - D4: åpnes uten konto.
  - D5: manus og innstillinger kan ikke åpnes.
  - D6: tilbakekalt lenke avvises.
- **Tester:**
  - tests/db/run-db-tests.ts
  - tests/unit/mobile-server.test.ts
  - tests/visual/dec0090-mobile-ui.mjs
- **Implementering:** src/adapters/mobile/mobile.functions.ts, db/migrations/0035_mobile_import.sql, src/app/mobile/MobileImportLibrary.tsx

#### REQ-0683 – Flere bidragsytere, sporbarhet og gjennomgang
Flere personer kan sende til samme kontekst. Filer spores til økt eller lenke, og bidragsyteren kan oppgi et frivillig navn. En bidragsyter ser ikke andres opplastinger, bare sine egne i samme økt. Eksterne bidrag erstatter aldri aktive ressurser; de kommer inn som nye versjoner som godkjennes som før.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** COLLAB, LIBRARY
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Bidragsyter ser bare egne opplastinger.
  - Filen viser hvem som sendte den.
- **Tester:**
  - tests/visual/dec0090-mobile-ui.mjs
  - tests/db/run-db-tests.ts
- **Implementering:** src/app/mobile/MobilePage.tsx, src/app/mobile/MobileImportLibrary.tsx, src/app/mobile/use-mobile-imports.ts

#### REQ-0684 – Mikrofonikon og lydpopup med PC-opptak og QR samtidig
Lydressursdialoger og dialogredigering har et mikrofonikon øverst til høyre. Det åpner en lydpopup der «Ta opp på denne datamaskinen» og QR-koden for mobilen vises samtidig fra første øyeblikk, for akkurat denne lydkonteksten.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** AUDIO, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - L1: PC-opptak og QR vises samtidig.
  - L2: PC-opptak startes uten ekstra valg.
- **Tester:**
  - tests/visual/dec0093-audio-ui.mjs
- **Implementering:** src/app/audio/AudioTakesDialog.tsx, src/app/library/AssetDetail.tsx, src/app/script/Inspector.tsx, src/app/assembly/AudioClipPanel.tsx

#### REQ-0685 – Hele dialogteksten vises under opptak
Fra en replikk viser lydpopupen hele replikken med karakter og scene, med det valgte ordet eller området fremhevet. Teksten vises også på mobilsiden, så man kan lese fra telefonen.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** AUDIO, SCRIPT
- **Status:** Implementert – ikke verifisert
- **Akseptansekriterier:**
  - L3: mobilen viser dialogteksten og opptakskontrollene.
- **Tester:**
  - tests/unit/audio-takes.test.ts
  - tests/unit/mobile-server.test.ts
  - tests/visual/dec0093-audio-ui.mjs
- **Implementering:** src/core/audio/takes.ts, src/core/mobile/index.ts, src/adapters/mobile/mobile.functions.ts, src/app/mobile/MobileAudio.tsx

#### REQ-0686 – Lydopptak på PC med flere takes
PC-opptak har start, stopp, spill av, ta opp på nytt, behold og velg. Mikrofontillatelse håndteres. Et nytt take overskriver aldri et tidligere.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** AUDIO
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Nytt take lagres ved siden av det forrige.
- **Tester:**
  - tests/unit/audio-takes.test.ts
  - tests/visual/dec0093-audio-ui.mjs
- **Implementering:** src/app/audio/use-recorder.ts, src/app/audio/AudioTakesDialog.tsx, src/app/audio/takes.ts

#### REQ-0687 – Lydopptak på mobil – brukeren velger hva som sendes
Mobilopptak: start, stopp, hør, nytt opptak, tilbake til tidligere, sammenligne, velge ett eller flere og laste opp bare de valgte. Lyd lastes aldri opp automatisk når opptaket stopper.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** AUDIO, UI
- **Status:** Implementert – ikke verifisert
- **Akseptansekriterier:**
  - L4–L7: Take 01 og 02 kan høres og lastes opp hver for seg eller sammen.
- **Tester:**
  - tests/unit/mobile-audio-queue.test.ts
  - tests/visual/dec0093-audio-ui.mjs
- **Implementering:** src/app/mobile/MobileAudio.tsx, src/app/mobile/upload-queue.ts

#### REQ-0688 – Flere takes bevares
Alle opptak bevares som egne takes med nummer og lengde. Et nytt take sletter aldri et tidligere. Et take kan velges som aktivt, eller deler brukes i en lydkomposisjon.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** AUDIO, VERSION
- **Status:** Verifisert
- **Akseptansekriterier:**
  - L8: nytt take sletter ikke tidligere takes.
- **Tester:**
  - tests/unit/audio-takes.test.ts
- **Implementering:** src/core/audio/takes.ts, src/app/audio/takes.ts, src/app/mobile/use-mobile-imports.ts

#### REQ-0689 – Opptaksstatus og lokal lagring på telefonen
Det vises om et opptak bare er lokalt, valgt, lastes opp, er lastet opp eller feilet. Opptak lagres lokalt i nettleseren så langt den tillater; brukeren advares før siden forlates om noe ikke er sendt, og en feilet opplasting kan prøves igjen uten nytt opptak.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** AUDIO, UI
- **Status:** Implementert – ikke verifisert
- **Akseptansekriterier:**
  - Feilet opplasting prøves igjen uten nytt opptak.
  - Advarsel ved å forlate siden med usendte opptak.
- **Tester:**
  - tests/unit/mobile-audio-queue.test.ts
  - tests/visual/dec0093-audio-ui.mjs
- **Implementering:** src/app/mobile/MobileAudio.tsx, src/app/mobile/upload-queue.ts, src/app/mobile/MobilePage.tsx

#### REQ-0690 – Opptak av ren romlyd
I opptaksvinduet (PC og mobil) kan brukeren ta opp noen sekunder ren romlyd, merket som romlyd, til bruk i dialogredigering og sammenklipping.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** AUDIO
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Romlydopptak merkes og kan velges som romlydressurs.
- **Tester:**
  - tests/unit/audio-takes.test.ts
  - tests/visual/dec0093-audio-ui.mjs
- **Implementering:** src/app/audio/takes.ts, src/app/mobile/MobileAudio.tsx, src/app/audio/AudioTakesDialog.tsx

#### REQ-0691 – Integrert lydeditor
Mikrofonikonet finnes også der eksisterende lyd redigeres. Editoren viser eksisterende lyd og nye takes med bølgeformer, tidslinje, avspillingshode, inn- og utpunkter, trim, flere spor ved behov og forhåndsavspilling av komposisjonen.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** AUDIO, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Eksisterende lyd og nytt take vises i samme vindu.
- **Tester:**
  - tests/visual/dec0094-audio-editor-ui.mjs
- **Implementering:** src/app/audio/AudioCompositionEditor.tsx, src/app/audio/AudioTakesDialog.tsx

#### REQ-0692 – Ny lyd: erstatte, før, oppå, etter eller et mindre område
Et nytt opptak kan erstatte hele lyden eller et markert område, settes inn før eller etter, legges oppå som eget spor, eller trimmes og erstatte bare et ord eller en frase. Resultatet kan forhåndshøres før det godkjennes.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** AUDIO
- **Status:** Verifisert
- **Akseptansekriterier:**
  - T10: ny lyd før, over eller etter eksisterende lyd.
- **Tester:**
  - tests/unit/audio-composition.test.ts
  - tests/visual/dec0094-audio-editor-ui.mjs
- **Implementering:** src/core/audio/composition.ts, src/app/audio/AudioCompositionEditor.tsx

#### REQ-0693 – Ikke-destruktiv lydkomposisjon
Et redigert lydresultat er en komposisjon som beskriver kildefiler, områder, plassering, pauser, romlyd, overlapp, fades/crossfades, volum og varighet. Originalfiler og takes endres aldri, og resultatet kan gjenskapes fra komposisjonsdataene.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** data · **Prioritet:** P1 · **Fase:** –
- **Moduler:** AUDIO, VERSION
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Komposisjonen gir samme lyd når den gjenskapes.
  - Originalfilene er uendret.
- **Tester:**
  - tests/unit/audio-composition.test.ts
  - tests/db/run-db-tests.ts
  - tests/visual/dec0094-audio-editor-ui.mjs
- **Implementering:** src/core/audio/composition.ts, src/core/commands/apply.ts, src/core/patch.ts, db/migrations/0036_audio_compositions.sql, src/app/audio/composition-actions.ts

#### REQ-0694 – Andre dialoger berøres aldri
Redigering av én dialog flytter, strekker, forkorter eller overskriver aldri andre replikker eller lydklipp, og endrer ikke ferdige filmklipp. Alle andre replikker regnes som låste: overlapper komposisjonen en annen replikk, vises en konflikt som håndteres senere. Et nytt opptak tvinges ikke inn i et gammelt tidsrom; hastighet og tonehøyde endres aldri automatisk.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** prinsipp · **Prioritet:** P1 · **Fase:** –
- **Moduler:** AUDIO, TIMELINE
- **Status:** Verifisert
- **Akseptansekriterier:**
  - P9: andre dialoger beholder lyd og tid.
  - T7–T8: opptaket kan være lengre eller kortere.
  - Overlapp vises som konflikt.
- **Tester:**
  - tests/unit/audio-composition.test.ts
  - tests/visual/dec0094-audio-editor-ui.mjs
- **Implementering:** src/core/audio/composition.ts, src/app/audio/AudioCompositionEditor.tsx

#### REQ-0695 – Angre og versjoner av lydkomposisjoner
Pauseendringer, innsetting, klippgrenser og bytte av take kan angres. Brukeren kan gå tilbake til opprinnelig lyd, sammenligne komposisjoner og lagre en ny variant. Nye komposisjoner er versjoner som godkjennes på samme måte som andre versjoner.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** AUDIO, VERSION
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Angre gjenoppretter forrige klippgrense.
  - Ny variant krever godkjenning.
- **Tester:**
  - tests/unit/audio-composition.test.ts
  - tests/visual/dec0094-audio-editor-ui.mjs
- **Implementering:** src/app/audio/AudioCompositionEditor.tsx, src/app/audio/composition-actions.ts

#### REQ-0696 – Lydeksport fra lydpopupen
Fra samme vindu kan hele komposisjonen, et valgt område eller ett take eksporteres, lokalt eller som ny lydvariant i biblioteket. Formater: WAV og MP3, med valg av samplingsfrekvens, kanaler, filnavn og område. Eksporten flater ikke ut komposisjonen; den kan fortsatt redigeres.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** AUDIO, EXPORT
- **Status:** Verifisert
- **Akseptansekriterier:**
  - E4–E6: hele, område og ett take.
  - E7: originaler og komposisjon bevares.
- **Tester:**
  - tests/visual/dec0094-audio-editor-ui.mjs
- **Implementering:** src/app/audio/composition-actions.ts, src/app/audio/AudioCompositionEditor.tsx, src/engine/audio/composition.ts

#### REQ-0697 – Lydmotor for komposisjoner
Forhåndsavspilling og eksport bruker samme komposisjonsbeskrivelse og samme beregning, så eksporten låter som det brukeren hørte: flere kilder, trim, innsetting, overlapp, volum, fades, crossfades, romlyd og pauser.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** arkitektur · **Prioritet:** P1 · **Fase:** –
- **Moduler:** AUDIO
- **Status:** Implementert – ikke verifisert
- **Akseptansekriterier:**
  - Eksportert lyd er lik forhåndsavspillingen (test på samples).
- **Tester:**
  - tests/unit/audio-composition.test.ts
  - tests/visual/dec0094-audio-editor-ui.mjs
- **Implementering:** src/engine/audio/composition.ts

#### REQ-0698 – Ord-til-lyd-kobling med utskiftbar analysetjeneste
Programmet kobler ordene i replikken til tidsrom i lyden (forced alignment) med manusteksten som utgangspunkt. Tjenesten er utskiftbar. Resultatet lagrer lyd-ID, replikk-ID, manusversjon, ord, start, slutt, usikkerhet, manuelle overstyringer og modell med versjon. Et nytt opptak analyseres uten å analysere alt på nytt; feiler analysen, virker manuell redigering.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** arkitektur · **Prioritet:** P1 · **Fase:** –
- **Moduler:** AUDIO, PROVIDER
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Resultatformatet er uavhengig av tjenesten.
  - Manuell redigering virker uten analyse.
- **Tester:**
  - tests/unit/word-alignment.test.ts
  - tests/db/run-db-tests.ts
  - tests/visual/dec0095-word-alignment-ui.mjs
- **Implementering:** src/core/audio/alignment.ts, src/core/commands/apply.ts, db/migrations/0037_word_alignment.sql, src/adapters/ai/alignment.functions.ts

#### REQ-0699 – Valg av analysetjeneste der brukeren er
Brukeren velger selv analysetjeneste (først ElevenLabs Forced Alignment, deretter f.eks. WhisperX via en vertstjeneste) eller manuell kobling, direkte i dialogeditoren uten å gå til en innstillingsside. Valget huskes. Analysen bruker brukerens egen nøkkel og krever kostnadsgodkjenning som annen AI. Norsk bokmål, nynorsk, dialekter og egennavn prøves før tjenesten anbefales.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** PROVIDER, QUALITYCOST
- **Status:** Implementert – ikke verifisert
- **Akseptansekriterier:**
  - Valget av tjeneste huskes.
  - Kostnaden vises og godkjennes før analysen.
- **Tester:**
  - tests/unit/word-alignment.test.ts
  - tests/visual/dec0095-word-alignment-ui.mjs
- **Implementering:** src/app/audio/LineWordsPanel.tsx, src/adapters/ai/alignment.functions.ts, src/adapters/ai/providers.server.ts, src/core/generation/providers.ts

#### REQ-0700 – Klikk og markér ord i teksten for å velge lyd
Dialogeditoren viser replikken som en aktiv del av redigeringen. Klikk på et ord markerer lyden for ordet; markering av flere ord, en setning eller hele replikken markerer det samlede tidsrommet. Grensene kan justeres manuelt, usikre koblinger vises tydelig, og markeringen brukes til avspilling, opptak, trim og erstatning.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** AUDIO, SCRIPT
- **Status:** Verifisert
- **Akseptansekriterier:**
  - T1: ett ord gir riktig lydområde.
  - T2: to ord gir samlet område.
- **Tester:**
  - tests/unit/word-alignment.test.ts
  - tests/visual/dec0095-word-alignment-ui.mjs
- **Implementering:** src/app/audio/LineWordsPanel.tsx, src/core/audio/alignment.ts

#### REQ-0701 – Avspilling med kontekst
Et markert område kan spilles med justerbar lyd før og etter, eller alene. Ny tekst uten lyd spiller omkringliggende dialoglyd der den finnes.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** AUDIO
- **Status:** Verifisert
- **Akseptansekriterier:**
  - T3: hel setning høres med kontekst.
- **Tester:**
  - tests/visual/dec0095-word-alignment-ui.mjs
- **Implementering:** src/app/audio/LineWordsPanel.tsx, src/app/audio/AudioCompositionEditor.tsx

#### REQ-0702 – Erstatte ett ord eller en frase
Et markert ord eller en frase kan tas opp på nytt, trimmes og plasseres i riktig tidsrom med finjusterbare klippgrenser og fades/crossfades. Originalen bevares og hele replikken trenger ikke tas opp igjen.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** AUDIO
- **Status:** Verifisert
- **Akseptansekriterier:**
  - T9: bare ett ord erstattes.
- **Tester:**
  - tests/unit/word-alignment.test.ts
  - tests/visual/dec0095-word-alignment-ui.mjs
  - tests/visual/dec0094-audio-editor-ui.mjs
- **Implementering:** src/app/audio/LineWordsPanel.tsx, src/core/audio/composition.ts, src/app/audio/AudioCompositionEditor.tsx

#### REQ-0703 – Status for tekst mot lyd
Endret dialog vises med status: synkronisert, ny tekst uten lyd, endret tekst med gammel lyd, nytt opptak til gjennomgang og godkjent oppdatert. Status vises med farge og et annet tegn (ikke bare farge) og påvirker ikke manuseksporten.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** SCRIPT, AUDIO, VERSION
- **Status:** Verifisert
- **Akseptansekriterier:**
  - T4: ny tekst uten lyd merkes.
  - T5: endret tekst med eldre lyd merkes.
- **Tester:**
  - tests/unit/word-alignment.test.ts
  - tests/visual/dec0095-word-alignment-ui.mjs
- **Implementering:** src/core/audio/alignment.ts, src/app/audio/AudioTakesDialog.tsx, src/app/script/Inspector.tsx

#### REQ-0704 – Ny eller endret setning: ta opp bare det som mangler
Systemet finner ny tekst uten lyd (f.eks. en ny setning) og endret frase. Brukeren markerer den, mikrofonikonet åpner opptak med teksten fremhevet, og opptaket foreslås plassert riktig (etter, før, i stedet for, eller oppå). Plasseringen kan endres, ny frase får naturlig lengde, den gamle lyden bevares, og komposisjonen godkjennes før den tas i bruk.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** AUDIO, SCRIPT
- **Status:** Implementert – ikke verifisert
- **Akseptansekriterier:**
  - T6: bare den nye setningen spilles inn og plasseres riktig.
- **Tester:**
  - tests/unit/word-alignment.test.ts
- **Implementering:** src/core/audio/alignment.ts, src/app/audio/LineWordsPanel.tsx

#### REQ-0705 – Endre pauser mellom ord
I en egen tidsredigeringsmodus kan avstanden mellom to ord økes eller reduseres ved å dra dem fra hverandre, uten nytt opptak og uten å endre ordenes lyd. Vanlig markering og redigering av tekst endrer aldri timingen.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** AUDIO, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - P1: pausen mellom to ord økes.
  - P2: ordenes lyd er uendret.
- **Tester:**
  - tests/unit/audio-pauses.test.ts
- **Implementering:** src/core/audio/pauses.ts, src/core/audio/composition.ts, src/app/audio/PauseTimingPanel.tsx, src/app/audio/LineWordsPanel.tsx

#### REQ-0706 – Pauser mellom flere ord
Når flere ord dras fra hverandre, fordeles den ekstra tiden likt mellom de indre mellomrommene (600 ms over tre ord gir 300 + 300 ms). Hver pause kan justeres for seg etterpå.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** AUDIO
- **Status:** Verifisert
- **Akseptansekriterier:**
  - P3–P5: tiden fordeles likt og kan justeres.
- **Tester:**
  - tests/unit/audio-pauses.test.ts
- **Implementering:** src/core/audio/pauses.ts, src/app/audio/PauseTimingPanel.tsx

#### REQ-0707 – Pausene vises bare i produksjonsvisningen
Lengre pauser vises som større avstand mellom ordene i tidsredigeringsmodus. Manusteksten og eksportert manus får aldri ekstra mellomrom eller tegn; tekst og tid holdes atskilt.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** prinsipp · **Prioritet:** P1 · **Fase:** –
- **Moduler:** AUDIO, SCRIPT
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Manuseksporten er uendret etter pauseendringer.
- **Tester:**
  - tests/unit/audio-pauses-script.test.ts
- **Implementering:** src/app/audio/PauseTimingPanel.tsx, src/core/audio/composition.ts

#### REQ-0708 – Naturlig romlyd i pauser
Forlengede pauser fylles som standard med romlyd fra samme opptak, fra partier uten tale, klikk, bevegelser, markerte hendelser eller upassende pust. Er romlyden for kort, settes flere biter sammen med crossfade og uten tydelig gjentakelse; finnes ingen egnet romlyd, varsles brukeren. Valg: naturlig romlyd (standard), digital stillhet, valgt romlydressurs eller manuelt redigert pause. Tale endres aldri i hastighet eller tonehøyde. Romlydfylling er en hjelp, ikke en garanti for sømløst resultat.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** AUDIO
- **Status:** Implementert – ikke verifisert
- **Akseptansekriterier:**
  - P6: nye pauser fylles med romlyd.
  - P7: digital stillhet kan velges.
- **Tester:**
  - tests/unit/roomtone.test.ts
  - tests/unit/audio-engine-room.test.ts
- **Implementering:** src/core/audio/roomtone.ts, src/app/audio/room-fill.ts, src/engine/audio/composition.ts

#### REQ-0709 – Romlyd i overganger mellom takes
Romlyd kan brukes til å myke opp overganger mellom ulike takes. Overgangene kan forhåndshøres og justeres; romlyd fra ulike opptak antas ikke å være lik.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** AUDIO
- **Status:** Implementert – ikke verifisert
- **Akseptansekriterier:**
  - Overgang mellom to takes kan justeres og høres.
- **Tester:**
  - tests/unit/audio-transitions.test.ts
- **Implementering:** src/core/audio/transitions.ts, src/app/audio/TransitionsPanel.tsx

#### REQ-0710 – «Spill av automatisk etter endring»
Dialogeditoren har avkrysningen «Spill av automatisk etter endring». Når den er på, spilles det endrede området med justerbar kontekst når en endring er fullført (ikke mens man drar), og nye avspillinger legges ikke oppå tidligere. Av: ingen automatisk avspilling.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** AUDIO, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - E1–E3: av/på virker.
  - P8: resultatet kan forhåndshøres.
- **Tester:**
  - tests/unit/audio-transitions.test.ts
- **Implementering:** src/core/audio/transitions.ts, src/app/audio/AudioCompositionEditor.tsx

#### REQ-0711 – Nettleserkompatibilitet for kamera, mikrofon og deling
Kamera, mikrofon (MediaDevices/MediaRecorder), filvalg, Web Share, store opplastinger, sanntid og lokal lagring verifiseres på iPhone (Safari) og Android (Chrome) over HTTPS. Tillatelser spørres alltid først og respekteres.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** ikke-funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** UI, SECURITY
- **Status:** Implementert – ikke verifisert
- **Akseptansekriterier:**
  - Kontrollert på iPhone og Android (dokumentert).
- **Tester:**
- **Implementering:** src/app/mobile/MobilePage.tsx

#### REQ-0712 – Ytelse og pålitelighet
Flere samtidige mobilopplastinger, store videofiler og responsive bølgeformer og tekstmarkering uten at appen blir ustabil; tydelige feil- og statusmeldinger.

- **Kilde:** Beslutning DEC-0090 · **Opprinnelse:** brukerbeslutning · **Type:** ikke-funksjonell · **Prioritet:** P1 · **Fase:** –
- **Moduler:** AUDIO, LIBRARY
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Flere samtidige opplastinger i test.
  - Bølgeform for lang replikk tegnes raskt.
- **Tester:**
  - tests/unit/audio-performance.test.ts
  - tests/unit/mobile-server.test.ts
- **Implementering:** src/engine/audio/mixer.ts, src/app/audio/room-fill.ts, src/adapters/mobile/mobile.functions.ts

#### REQ-0713 – Teknisk feilmelding på feilsiden
Når en side krasjer, kan brukeren åpne «Vis teknisk feilmelding» på feilsiden og kopiere den (tidspunkt, side, feiltype, melding og de første linjene av stakken) for å sende den videre. Adressen vises uten spørrestreng og uten tokenet i mobillenker.

- **Kilde:** Beslutning DEC-0091 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** –
- **Moduler:** UI, SECURITY
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Feilsiden har «Vis teknisk feilmelding» med kopiering.
  - Teksten inneholder aldri mobiltokenet eller spørrestrengen.
- **Tester:**
  - tests/unit/error-report.test.tsx
- **Implementering:** src/app/shell/error-report.ts, src/app/shell/ErrorDetails.tsx, src/routes/__root.tsx

#### REQ-0714 – Ressurser legges inn i halv størrelse
Når en ressurs legges inn i en scene, får laget 50 % av lerretets høyde eller bredde – det som nås først – så hele figuren synes og er lett å håndtere. Bakgrunner fyller lerretet. Lag som allerede finnes endres ikke.

- **Kilde:** Beslutning DEC-0092 · **Opprinnelse:** brukerbeslutning · **Type:** funksjonell · **Prioritet:** P2 · **Fase:** –
- **Moduler:** COMPOSE, UI
- **Status:** Verifisert
- **Akseptansekriterier:**
  - Et høyt bilde blir halve lerrethøyden, et bredt halve lerretbredden.
  - Bakgrunner fyller lerretet.
- **Tester:**
  - tests/unit/layer-fit.test.ts
- **Implementering:** src/core/composition/index.ts
